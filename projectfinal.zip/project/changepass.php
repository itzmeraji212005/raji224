<?php
session_start();
// Database credentials (replace with your actual values)
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Password Change Form Handling
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["change_password"])) {
    $old_password = $_POST["old_password"];
    $new_password = $_POST["new_password"];
    $confirm_password = $_POST["confirm_password"];

    // Input validation
    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $password_error = "All fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $password_error = "New password and confirm password do not match.";
    } elseif (strlen($new_password) < 8) {  // Add more password complexity checks
        $password_error = "Password must be at least 8 characters long.";
    } else {
        // Database connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $admin_id = $_SESSION["admin_id"];

        // Retrieve current password from the database
        $sql = "SELECT password FROM admins WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($db_password);
            $stmt->fetch();

            // Verify the old password  (Use password_verify() in production with a hashed password)
            if ($old_password == $db_password) { // Use password_verify($old_password, $db_password) in production if you have hashed password

                // Hash the new password (REQUIRED for security)
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update the password in the database using prepared statements
                $update_sql = "UPDATE admins SET password = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("si", $hashed_password, $admin_id);

                if ($update_stmt->execute()) {
                    $password_success = "Password changed successfully!";
                } else {
                    $password_error = "Error updating password: " . $update_stmt->error;
                }
                $update_stmt->close();

            } else {
                $password_error = "Incorrect old password.";
            }
        } else {
            $password_error = "Admin not found.";  // This should generally not happen if the session is valid
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f7f3ff; /* Light purple background */
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
            box-sizing: border-box;
        }

        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            width: 450px; /* Slightly wider */
            max-width: 100%;
            box-sizing: border-box;
        }

        h2 {
            color: #5e35b1; /* Darker purple */
            margin-bottom: 30px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 10px;
            color: #3700b3; /* Strong purple */
            font-weight: bold;
            font-size: 1.1em;
        }

        input[type="password"] {
            width: calc(100% - 24px);
            padding: 12px;
            margin-bottom: 25px;
            border: 1px solid #d1c4e9; /* Light purple border */
            border-radius: 6px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="password"]:focus {
            outline: none;
            border-color: #9575cd; /* Medium purple on focus */
            box-shadow: 0 0 8px rgba(94, 53, 177, 0.3); /* Purple focus shadow */
        }

        input[type="submit"] {
            background-color: #5e35b1; /* Darker purple button */
            color: white;
            padding: 14px 24px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 1.1em;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #4527a0; /* Even darker purple on hover */
        }

        .error-message {
            color: #d32f2f; /* Red error color */
            margin-top: 15px;
            text-align: center;
            font-size: 0.9em;
        }

        .success-message {
            color: #388e3c; /* Green success color */
            margin-top: 15px;
            text-align: center;
            font-size: 0.9em;
        }

        /* Optional: Add a subtle border to the container */
        .container {
            border: 1px solid #ede7f6; /* Very light purple border */
        }
    </style>
<body>

    <div class="container">
        <h2>Reset Password</h2>

        <?php if (isset($password_error)): ?>
            <p class="error-message"><?php echo $password_error; ?></p>
        <?php endif; ?>

        <?php if (isset($password_success)): ?>
            <p class="success-message"><?php echo $password_success; ?></p>
        <?php endif; ?>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="old_password">Old Password:</label>
            <input type="password" id="old_password" name="old_password" required><br>

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" required><br>

            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required><br>

            <input type="submit" name="change_password" value="Set Password">
        </form>
    </div>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online College Voting System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('img3.png') no-repeat center center fixed;
            background-size: cover;
            text-align: center;
            color: white;
        }
        .container {
            margin-top: 100px;
        }
        .button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60%;
            margin: 20px auto;
            padding: 15px;
            font-size: 20px;
            font-weight: bold;
            color: white;
            border-radius: 50px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            position: relative;
            transition: transform 0.3s ease-in-out;
        }
        .button:hover {
            transform: scale(1.05);
        }
        .student-button {
            background-color: #D81B60;
        }
        .staff-button {
            background-color: blue;
        }
        .icon {
            width: 40px;
            height: 40px;
            margin-right: 15px;
            transition: transform 0.3s ease-in-out;
        }
        .button:hover .icon {
            transform: translateX(-10px);
        }
    </style>
</head>
<body>
    <h1>Online College Voting System</h1>
    <div class="container">
        <a href="login.php" class="button student-button">
            <img src="student-icon.png" alt="Student Icon" class="icon">
            STUDENT LOGIN
        </a>
        <a href="index.php" class="button staff-button">
            <img src="staff-icon.png" alt="Staff Icon" class="icon">
            ADMIN LOGIN
        </a>
    </div>
</body>
</html>

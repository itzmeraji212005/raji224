<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Establish connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errorMessage = "";

$department_codes = [
    "Dept of Tamil" => "UTA",
    "Dept of English" => "UEN",
    "Dept of Maths" => "UMA",
    "Dept of Computer Application" => "UCA",
    "Dept of Computer Science" => "UCS",
    "Dept of Physics" => "UPY",
    "Dept of Chemistry" => "UCH",
    "Dept of Zoology" => "UZO",
    "Dept of Visual Communication" => "UVS",
    "Dept of Data Science" => "UDS"
];

$dept_patterns = [
    "UTA" => "/^(22|21|20)UTA50[1-9]$|^(22|21|20)UTA51[0-9]$/",
    "UEN" => "/^(22|21|20)UEN50[1-9]$|^(22|21|20)UEN51[0-9]$/",
    "uMA" => "/^(22|21|20)UMA50[1-9]$|^(22|21|20)UMA51[0-9]$/",
    "UCA" => "/^(22|21|20)UCA50[1-9]$|^(22|21|20)UCA52[0-9]$|^(22|21|20)UCA53[0-9]$/",
    "UCS" => "/^(22|21|20)UCS50[1-9]$|^(22|21|20)UCS51[0-9]$/",
    "UPY" => "/^(22|21|20)UPY50[1-9]$|^(22|21|20)UPY51[0-9]$/",
    "UCH" => "/^(22|21|20)UCH50[1-9]$|^(22|21|20)UCH51[0-9]$/",
    "UZO" => "/^(22|21|20)UZO50[1-9]$|^(22|21|20)UZO51[0-9]$/",
    "UVS" => "/^(22|21|20)UVS50[1-9]$|^(22|21|20)UVS51[0-9]$/",
    "UDS" => "/^(22|21|20)UDS50[1-9]$|^(22|21|20)UDS51[0-9]$/",
];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $regno = trim($_POST['regno']);
    $name = trim($_POST['name']);
    $dept_name = trim($_POST['dept_name']);

    if (!array_key_exists($dept_name, $department_codes)) {
        $errorMessage = "Invalid department selected.";
    } else {
        $dept_code = $department_codes[$dept_name];

        if (!isset($dept_patterns[$dept_code]) || !preg_match($dept_patterns[$dept_code], $regno)) {
            $errorMessage = "Invalid registration number for the selected department.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM register WHERE regno = ?");
            $stmt->bind_param("s", $regno);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $errorMessage = "This registration number already exists.";
            } else {
                $stmt = $conn->prepare("INSERT INTO register (regno, name, dept_name) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $regno, $name, $dept_name);
                if ($stmt->execute()) {
                    echo '<script>
                        alert("Registration Successful!");
                        window.location.href="demo.php";
                    </script>';
                    exit();
                } else {
                    $errorMessage = "Error: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        body {
            background: url('reg.jpg') no-repeat center center fixed;
            background-size: cover;
            font-family: Arial, sans-serif;
        }
        .container {
            width: 350px;
            margin: 100px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.2);
            text-align: center;
            color: white;
        }
        h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            font-size: 16px;
        }
        input {
            background: rgba(255, 255, 255, 0.9);
        }
        select {
            background: rgba(255, 255, 255, 0.9);
            cursor: pointer;
        }
        .btn {
            width: 100%;
            padding: 12px;
            background: green;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
        }
        .btn:hover {
            background: darkgreen;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Registration Form</h2>
        <form action="" method="POST">
            <label>Registration Number:</label>
            <input type="text" name="regno" required>

            <label>Name:</label>
            <input type="text" name="name" required>

            <label>Department:</label>
            <select name="dept_name" required>
                <option value="">Select Department</option>
                <?php
                foreach ($department_codes as $dept => $code) {
                    echo "<option value='$dept'>$dept</option>";
                }
                ?>
            </select>

            <button type="submit" class="btn">Register</button>
        </form>
    </div>

    <?php if (!empty($errorMessage)): ?>
        <script>
            alert("<?php echo htmlspecialchars($errorMessage); ?>");
        </script>
    <?php endif; ?>
</body>
</html>

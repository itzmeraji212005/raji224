<?php
if (isset($_GET['success'])) {
    $message = '';
    if ($_GET['success'] == 'update') {
        $message = "Votee <strong>" . htmlspecialchars($_GET['name']) . "</strong> updated successfully!";
    } elseif ($_GET['success'] == 'delete') {
        $message = "Votee <strong>" . htmlspecialchars($_GET['name']) . "</strong> deleted successfully!";
    }

    if ($message): ?>
        <div class="message success"><?= $message ?></div>
    <?php endif;
}
?>

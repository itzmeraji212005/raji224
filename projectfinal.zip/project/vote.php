<?php
$candidatesData = [
    ['position' => 'Chairman', 'name' => 'Tamil', 'year' => '3rd Year', 'picture' => 'person1.jpg'],
    ['position' => 'Chairman', 'name' => 'Gowsi', 'year' => '2nd Year', 'picture' => 'person3.jpg'],
    ['position' => 'Chairman', 'name' => 'Abdul', 'year' => '3rd Year', 'picture' => 'person2.png'],
    ['position' => 'Vice Chairman', 'name' => 'Jeeva', 'year' => '3rd Year', 'picture' => 'person5.jpg'],
    ['position' => 'Vice Chairman', 'name' => 'Kiruba', 'year' => '3rd Year', 'picture' => 'person4.jpg'],
    ['position' => 'Secretary', 'name' => 'Kumar', 'year' => '3rd Year', 'picture' => 'person7.jpg'],
    ['position' => 'Secretary', 'name' => 'Vikas', 'year' => '2nd Year', 'picture' => 'person6.jpg'],
    ['position' => 'Joint Secretary', 'name' => 'Raji', 'year' => '3rd Year', 'picture' => 'raji.png'],
    ['position' => 'Joint Secretary', 'name' => 'Anu', 'year' => '3rd Year', 'picture' => 'person9.jfif'],
    ['position' => 'President', 'name' => 'Arun', 'year' => '3rd Year', 'picture' => 'per10.jpg'],
    ['position' => 'President', 'name' => 'Kavin', 'year' => '2nd Year', 'picture' => 'person11.jpg'],
    ['position' => 'Vice President', 'name' => 'Manju', 'year' => '2nd Year', 'picture' => 'women.avif'],
    ['position' => 'Union Advisor', 'name' => 'Saravanan', 'year' => '3rd Year', 'picture' => 'person12.jpg'],
    ['position' => 'Sports Secretary', 'name' => 'Alex', 'year' => '3rd Year', 'picture' => 'person13.avif'],
    ['position' => 'Sports Secretary', 'name' => 'Siva', 'year' => '3rd Year', 'picture' => 'person14.jpg'],
    ['position' => 'Sports Secretary', 'name' => 'Abinash', 'year' => '2nd Year', 'picture' => 'person15.avif'],
];

$candidates = [];
foreach ($candidatesData as $candidate) {
    $candidates[$candidate['position']][] = $candidate;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote for Candidates</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0 auto;
            max-width: 900px;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .position-section {
            width: 100%;
            margin-bottom: 20px;
            text-align: center;
        }

        .candidates-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        .candidate {
            border: 1px solid #ddd;
            padding: 15px;
            background-color: #fff;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 200px;
            text-align: center;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .candidate:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .candidate img {
            max-width: 100%;
            height: 120px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        input[type="radio"] {
            margin-top: 10px;
            transform: scale(1.2);
        }

        button {
            margin: 20px auto;
            padding: 12px 25px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .candidate {
                width: 90%;
            }
        }
    </style>
</head>
<body>

    <h1>Vote for Your Candidates</h1>

    <form action="submit_vote.php" method="POST" class="form-container">
        <?php foreach ($candidates as $position => $candidatesList): ?>
            <div class="position-section">
                <h2><?= $position ?></h2>
                <div class="candidates-container">
                    <?php foreach ($candidatesList as $candidate): ?>
                        <label class="candidate">
                            <img src="<?= $candidate['picture'] ?>" alt="<?= $candidate['name'] ?>">
                            <p><?= $candidate['name'] ?> - <?= $candidate['year'] ?></p>
                            <input type="radio" name="<?= $candidate['position'] ?>" value="<?= $candidate['name'] ?>" required>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <button type="submit">Submit Vote</button>
    </form>

</body>
</html>

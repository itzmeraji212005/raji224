<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$database = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if name is provided in URL
if (!isset($_GET['name']) || empty($_GET['name'])) {
    die("Candidate name is missing.");
}

$name = $conn->real_escape_string($_GET['name']);

// Use prepared statement to prevent SQL injection
$stmt = $conn->prepare("SELECT * FROM votee WHERE name = ?");
$stmt->bind_param("s", $name);
$stmt->execute();
$result = $stmt->get_result();

// Check if a candidate is found
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
} else {
    die("Candidate not found.");
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($row['name']); ?> - Candidate Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9f9;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .candidate-details {
            background-color: white;
            max-width: 500px;
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .candidate-image {
            width: 100%;
            border-radius: 8px;
        }
        h2 {
            font-size: 22px;
            margin: 10px 0;
            color: #333;
        }
        p {
            color: #666;
            font-size: 16px;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 15px;
            background-color: #8A2BE2;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-link:hover {
            background-color:#8A2BE2;
        }
    </style>
</head>
<body>

    <div class="candidate-details">
        <img src="<?= htmlspecialchars($row['picture']); ?>" alt="<?= htmlspecialchars($row['name']); ?>" class="candidate-image">
        <h2><?= htmlspecialchars($row['name']); ?></h2>
        <p><strong>Position:</strong> <?= htmlspecialchars($row['position']); ?></p>
        <p><strong>Year:</strong> <?= htmlspecialchars($row['year']); ?></p>
        <p><strong>Description:</strong> <?= nl2br(htmlspecialchars($row['description'])); ?></p>
    </div>

    <a href="candi.php" class="back-link">Back to List</a>

</body>
</html>

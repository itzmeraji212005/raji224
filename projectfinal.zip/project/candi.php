<?php 
include('header.php');
?>

<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$database = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch candidates from the database and order by position
$sql = "SELECT name, position, year, picture FROM votee ORDER BY position ASC, name ASC";
$result = $conn->query($sql);

$candidates_by_position = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $candidates_by_position[$row['position']][] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidates</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: white;
            margin: 0;
            padding: 20px;
            text-align: center;
            color: white;
        }
        .container {
            max-width: 1200px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            color: black;
        }
        .position-title {
            font-size: 24px;
            margin-top: 20px;
            color: #8A2BE2; /* Updated color */
            text-align: left;
            border-bottom: 2px solid #8A2BE2; /* Updated line color */
            padding-bottom: 5px;
        }
        .candidates {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }
        .card {
            background: white;
            width: 250px;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .candidate-image {
            width: 100%;
            border-radius: 8px;
        }
        h2 {
            font-size: 18px;
            margin: 10px 0;
            color: #8A2BE2; /* Updated candidate name color */
        }
        p {
            color: #666;
            font-size: 14px;
        }
        .view-more {
            background-color: #8A2BE2; /* Updated button color */
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }
        .view-more:hover {
            background-color: #6A1BBE; /* Darker shade for hover effect */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Candidates List</h1>
        <?php foreach ($candidates_by_position as $position => $candidates): ?>
            <h2 class="position-title"><?= htmlspecialchars($position); ?></h2>
            <div class="candidates">
                <?php foreach ($candidates as $candidate): ?>
                    <div class="card">
                        <img src="<?= htmlspecialchars($candidate['picture']); ?>" alt="<?= htmlspecialchars($candidate['name']); ?>" class="candidate-image">
                        <h2><?= htmlspecialchars($candidate['name']); ?></h2>
                        <p><strong>Year:</strong> <?= htmlspecialchars($candidate['year']); ?></p>
                        <button class="view-more" onclick="viewMore('<?= urlencode($candidate['name']); ?>')">View More</button>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <script>
        function viewMore(name) {
            window.location.href = 'view_more_candidates.php?name=' + name;
        }
    </script>
</body>
</html>

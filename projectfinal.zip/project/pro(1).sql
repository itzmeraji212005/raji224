-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2025 at 02:04 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `year` varchar(20) NOT NULL,
  `picture` varchar(255) NOT NULL,
  `vote_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `position`, `name`, `year`, `picture`, `vote_count`) VALUES
(1, 'Chairman', 'Manik', '3rd Year', 'person1.jpg', 2),
(2, 'Chairman', 'Gowsi', '2nd Year', 'person3.jpg', 1),
(3, 'Chairman', 'Abdul', '3rd Year', 'person2.png', 0),
(4, 'Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg', 0),
(5, 'Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg', 0),
(6, 'Secretary', 'Kumar', '3rd Year', 'person7.jpg', 3),
(7, 'Secretary', 'Vikas', '2nd Year', 'person6.jpg', 0),
(8, 'Joint Secretary', 'Raji', '3rd Year', 'raji.jpeg', 0),
(9, 'Joint Secretary', 'Anu', '3rd Year', 'person9.jiff', 0),
(10, 'President', 'Arun', '3rd Year', 'per10.jpg', 3),
(11, 'President', 'Kavin', '2nd Year', 'person11.jpg', 0),
(12, 'Vice President', 'Manju', '3rd Year', 'women.avif', 0),
(13, 'Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg', 0),
(14, 'Sports Secretary', 'Alex', '3rd Year', 'person13.avif', 0),
(15, 'Sports Secretary', 'Siva', '3rd Year', 'person14.jpg', 0),
(16, 'Sports Secretary', 'Abinash', '2nd Year', 'person15.avif', 0);

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `position` varchar(55) NOT NULL,
  `name` varchar(25) NOT NULL,
  `year` varchar(25) NOT NULL,
  `picture` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `position`, `name`, `year`, `picture`) VALUES
(1, 'Chairman', 'Manik', '3rd Year', 'person1.jpg'),
(2, 'Chairman', 'Gowsi', '2nd Year', 'person3.jpg'),
(3, 'Chairman', 'Abdul', '3rd Year', 'person2.png'),
(4, 'Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg'),
(5, 'Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg'),
(6, 'Secretary', 'Kumar', '3rd Year', 'person7.jpg'),
(7, 'Secretary', 'Vikas', '2nd Year', 'person6.jpg'),
(8, 'Joint Secretary', 'Raji', '3rd Year', 'raji.jpeg'),
(9, 'Joint Secretary', 'Anu', '3rd Year', 'person9.jfif'),
(10, 'President', 'Arun', '3rd Year', 'per10.jpg'),
(11, 'President', 'Kavin', '2nd Year', 'person11.jpg'),
(12, 'Vice President', 'Manju', '2nd Year', 'women.avif'),
(13, 'Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg'),
(14, 'Sports Secretary', 'Alex', '3rd Year', 'person13.avif'),
(15, 'Sports Secretary', 'Siva', '3rd Year', 'person14.jpg'),
(16, 'Sports Secretary', 'Abinash', '2nd Year', 'person15.avif');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` int(11) NOT NULL,
  `position_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `position_name`) VALUES
(2, 'Union Advisior'),
(1, 'Union Advisor');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `position_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_name`) VALUES
('Chairman'),
('Vice Chairman'),
('Secretary'),
('Joint Secretary'),
('President'),
('Vice President'),
('Union Advisor'),
('Sports Secretary');

-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE `pro` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `profile_pic` varchar(25) DEFAULT 'profile.jpeg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pro`
--

INSERT INTO `pro` (`id`, `name`, `email`, `profile_pic`) VALUES
(1, 'manju', 'manju@gmail.com', 'person3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `regno` varchar(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dept_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `vote`
--

CREATE TABLE `vote` (
  `id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `vote_count` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vote`
--

INSERT INTO `vote` (`id`, `position`, `name`, `year`, `picture`, `vote_count`) VALUES
(24, 'Chairman', 'Gowsi', 0, NULL, 0),
(25, 'Vice_Chairman', 'Kiruba', 0, NULL, 0),
(26, 'Secretary', 'Vikas', 0, NULL, 0),
(27, 'Joint_Secretary', 'Raji', 0, NULL, 0),
(28, 'President', 'Arun', 0, NULL, 0),
(29, 'Vice_President', 'Manju', 0, NULL, 0),
(30, 'Union_Advisor', 'Saravanan', 0, NULL, 0),
(31, 'Sports_Secretary', 'Siva', 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `votee`
--

CREATE TABLE `votee` (
  `id` int(11) NOT NULL,
  `position` varchar(20) NOT NULL,
  `name` varchar(10) NOT NULL,
  `year` int(10) NOT NULL,
  `picture` varchar(25) DEFAULT NULL,
  `vote_count` int(11) DEFAULT 0,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votee`
--

INSERT INTO `votee` (`id`, `position`, `name`, `year`, `picture`, `vote_count`, `description`) VALUES
(1, 'Chairman', 'Manik', 3, 'person1.jpg', 0, 'I am committed to fostering transparency, inclusivity, and innovation within our organization as your chairman. Together, we can build a brighter future by listening to each voice and driving impactful change.'),
(2, 'Chairman', 'Gowsi', 3, 'person3.jpg', 0, '\"As your chairman, I pledge to promote openness, collaboration, and creativity throughout our organization. Let’s work together to create a thriving environment where everyone’s opinions matter and meaningful progress is achieved.\"'),
(3, 'Chairman', 'Abdul', 3, 'person2.png', 0, '\"I am dedicated to ensuring transparency, teamwork, and forward-thinking strategies as your chairman. Together, we can cultivate a dynamic community that embraces diverse perspectives and drives positive change.\"'),
(4, 'Vice Chairman', 'Tamil', 3, 'person5.jpg', 0, '\"I am committed to fostering collaboration, promoting innovation, and ensuring that every voice is heard, making me a strong candidate for Vice Chairman.\"'),
(5, 'Vice Chairman', 'Kiruba', 3, 'prof3.avif', 0, '\"I am dedicated to enhancing teamwork, driving new ideas, and ensuring inclusivity, which makes me an ideal candidate for Vice Chairman.\"'),
(6, 'Secretary', 'Kumar', 3, 'person7.jpg', 0, '\"As your candidate for Secretary, I pledge to bring organization, transparency, and effective communication to our team, ensuring that all voices are heard and valued.\"'),
(7, 'Secretary', 'Vikas', 2, 'person6.jpg', 0, '\"I am committed to fostering organization, clarity, and open communication as your Secretary, making sure every member\'s perspective is acknowledged and respected.\"'),
(8, 'Joint Secretary', 'Raji', 3, 'person15.jpeg', 0, 'As a dedicated and proactive candidate for the position of Joint Secretary, I will work tirelessly to enhance communication and collaboration within our organization. My commitment to fostering a supportive environment and implementing innovative solutions will ensure that every voice is heard and valued.'),
(9, 'Joint Secretary', 'Anu', 3, 'person14.jpeg', 0, 'I am eager to serve as your Joint Secretary, bringing enthusiasm and a collaborative spirit to our organization. My goal is to promote open communication and implement creative solutions that empower everyone and strengthen our community.'),
(10, 'President', 'Arun', 3, 'per10.jpg', 0, 'As a candidate for President, I am committed to fostering unity and empowering our community through transparent leadership. Together, we will tackle the challenges we face and build a brighter future for all.'),
(11, 'President', 'Kavin', 2, 'person11.jpg', 0, 'Running for President, I pledge to promote collaboration and inspire our community with honest leadership. Together, we can overcome our challenges and create a more promising future for everyone.'),
(12, 'Vice President', 'Manju', 2, 'women.avif', 0, '\"As a dedicated and passionate leader, I stand for the position of Vice President, committed to fostering collaboration, driving meaningful change, and advocating for the needs of our community while ensuring that every voice is heard.\"'),
(13, 'Union Advisor', 'Mohamad', 3, 'person12.jpg', 0, '\"As a candidate for Union Advisor, I am committed to advocating for student voices, fostering collaboration, and ensuring that every member\'s concerns are addressed while promoting a vibrant and inclusive campus culture.\"'),
(18, 'Union Advisor', 'Maria', 2, ' person4.jpg', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `position_name` (`position_name`);

--
-- Indexes for table `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vote`
--
ALTER TABLE `vote`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votee`
--
ALTER TABLE `votee`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pro`
--
ALTER TABLE `pro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vote`
--
ALTER TABLE `vote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `votee`
--
ALTER TABLE `votee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

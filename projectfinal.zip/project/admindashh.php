<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>                  
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background-image: url('dash.avif');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            color: white;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: rgba(30, 30, 30, 0.8);
            padding: 20px;
        }
        .profile {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #444;
        }
        .nav-item a {
            text-decoration: none;
            color: white;
            display: flex;
            align-items: center;
            padding: 10px;
            transition: 0.3s;
        }
        .nav-item a:hover, .nav-item a.active {
            background-color: white !important;
            color: black !important;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .nav-item i {
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="d-flex">
    <div class="sidebar">
        <div class="profile">
            <p><strong>Admin</strong></p>
            <span style="color: limegreen; font-size: 12px;">● Online</span>
        </div>

        <ul class="nav flex-column mt-3">
            <li class="nav-item"><a href="votersvoted.php"><i class="bi bi-speedometer2"></i> Dashboard</a></li>
            <li class="nav-item"><a href="buttongraph.php"><i class="bi bi-lock"></i> Votes</a></li>
            <li class="nav-item"><a href="buttoncrud.php"><i class="bi bi-person-lines-fill"></i> Manage Candidates</a></li>
            <hr>
            <li class="nav-item"><a href="cartpositions.php"><i class="bi bi-list-task"></i> Positions</a></li>
            <li class="nav-item"><a href="cartaddcandi.php"><i class="bi bi-person"></i> Candidates</a></li>
            <hr>
            <li class="nav-item"><a href="buttonregister.php"><i class="bi bi-people"></i> Voters</a></li>
            <li class="nav-item"><a href="profile.php"><i class="bi bi-person-circle"></i> Admin Profile</a></li>
            <li class="nav-item"><a href="change-password.php"><i class="bi bi-key"></i> Change Password</a></li>
            <li class="nav-item"><a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>

    <div class="p-4 flex-grow-1">
        <h2>Welcome to the Admin Dashboard</h2>
        <p>Manage voters, candidates, and elections from here.</p>
    </div>
</div>

</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Department codes mapping
$deptCodes = [
    "Dept of Tamil" => "UTA",
    "Dept of English" => "UEN",
    "Dept of Maths" => "UMA",
    "Dept of Computer Application" => "UCA",
    "Dept of Computer Science" => "UCS",
    "Dept of Physics" => "UPY",
    "Dept of Chemistry" => "UCH",
    "Dept of Zoology" => "UZO",
    "Dept of Visual Communication" => "UVS",
    "Dept of Data Science" => "UDS"
];

// Generate all possible registration numbers
$allStudents = [];
foreach ($deptCodes as $deptName => $deptCode) {
    $endRange = ($deptCode === "UCA") ? 540 : 520; // UCA goes up to 540, others to 520
    for ($batch = 22; $batch >= 20; $batch--) { // Years: 22, 21, 20
        for ($i = 501; $i <= $endRange; $i++) {
            $regno = "{$batch}{$deptCode}{$i}";
            $allStudents[$regno] = ["regno" => $regno, "dept_name" => $deptName, "name" => "N/A", "status" => "Not Voted"];
        }
    }
}

$sql = "SELECT regno, name, dept_name FROM register";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $regno = $row['regno'];
        if (isset($allStudents[$regno])) {
            $allStudents[$regno]['name'] = $row['name'];
            $allStudents[$regno]['status'] = "Voted";
        }
    }
}
$voters = [];
$nonVoters = [];

foreach ($allStudents as $student) {
    if ($student['status'] === "Voted") {
        $voters[] = $student;
    } elseif ($student['status'] === "Not Voted") {
        $nonVoters[] = $student;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Status</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            text-align: center;
        }
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #007bff;
            color: white;
        }
        .voted {
            background: #d4edda; /* Green */
        }
        .not-voted {
            background: #f8d7da; /* Red */
        }
    </style>
</head>
<body>
     <!-- Back to Admin Dashboard Button -->
    <a href="admindashh.php" class="back-btn">← Back to Admin Dashboard</a>

    <h2>Voters List</h2>
    <table>
        <tr>
            <th>Reg No</th>
            <th>Name</th>
            <th>Department</th>
            <th>Status</th>
        </tr>
        <?php foreach ($voters as $student) { ?>
            <tr class="voted">
                <td><?php echo $student["regno"]; ?></td>
                <td><?php echo $student["name"]; ?></td>
                <td><?php echo $student["dept_name"]; ?></td>
                <td><?php echo $student["status"]; ?></td>
            </tr>
        <?php } ?>
    </table>

    <h2>Non-Voters List</h2>
    <table>
        <tr>
            <th>Reg No</th>
            <th>Name</th>
            <th>Department</th>
            <th>Status</th>
        </tr>
        <?php foreach ($nonVoters as $student) { ?>
            <tr class="not-voted">
                <td><?php echo $student["regno"]; ?></td>
                <td><?php echo $student["name"]; ?></td>
                <td><?php echo $student["dept_name"]; ?></td>
                <td><?php echo $student["status"]; ?></td>
            </tr>
        <?php } ?>
    </table>

</body>
</html>

<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";
$voted = false;

// Check if user is already logged in
if (isset($_SESSION['regno'])) {
    $regno = $_SESSION['regno'];

    // Verify regno exists in the register table
    $stmt = $conn->prepare("SELECT name FROM register WHERE regno = ?");
    $stmt->bind_param("s", $regno);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        session_unset();
        session_destroy();
        header("Location: index.php"); // Redirect to login
        exit();
    }

    $user = $result->fetch_assoc();
    $_SESSION['user_name'] = $user['name'];

    // Check if the user has already voted
    $voteCheck = $conn->prepare("SELECT * FROM register WHERE regno = ?");
    $voteCheck->bind_param("s", $regno);
    $voteCheck->execute();
    $voteResult = $voteCheck->get_result();

    if ($voteResult->num_rows > 0) {
        $voted = true;  // User has already voted
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['regno'])) {
    $regno = trim($_POST['regno']);

    if (!empty($regno)) {
        // Verify regno exists in the register table
        $stmt = $conn->prepare("SELECT name FROM register WHERE regno = ?");
        $stmt->bind_param("s", $regno);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $_SESSION['regno'] = $regno;
            $_SESSION['user_name'] = $user['name'];

            // Check if the user has already voted
            $voteCheck = $conn->prepare("SELECT * FROM register WHERE regno = ?");
            $voteCheck->bind_param("s", $regno);
            $voteCheck->execute();
            $voteResult = $voteCheck->get_result();

            if ($voteResult->num_rows > 0) {
                $voted = true;  // User has already voted
            }
        } else {
            $error = "Register number not found. Please try again.";
        }
    } else {
        $error = "Please enter your register number.";
    }
}

$Positions = [
    'Chairman', 'Vice Chairman', 'Secretary',
    'Joint Secretary', 'President', 'Vice President',
    'Union Advisor', 'Sports Secretary'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting System</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container, .vote-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 20px auto;
        }
        .candidate-list {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .candidate-card {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin: 10px;
            text-align: center;
            transition: transform 0.2s;
        }
        .candidate-card:hover {
            transform: scale(1.05);
        }
        .candidate-card img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }
        input[type="submit"] {
            background: #007BFF;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background: #0056b3;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <?php if (!isset($_SESSION['regno'])) { ?>
        <div class="container">
            <h2>Enter Your Register Number</h2>
            <form method="POST">
                <input type="text" name="regno" placeholder="Enter Register Number" required>
                <input type="submit" value="Proceed to Vote">
            </form>
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        </div> 

    <?php } else { ?>
        <div class="vote-container">
            <h1>Vote for Your Candidates</h1>
            <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <form action="vote_process.php" method="post">
                <?php foreach ($Positions as $position) { ?>
                    <h3><?php echo $position; ?>:</h3>
                    <div class="candidate-list">
                        <?php
                        $sql = "SELECT name, picture FROM votee WHERE position = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $position);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<div class='candidate-card'>";
                                echo "<img src='" . htmlspecialchars($row['picture']) . "' alt='" . htmlspecialchars($row['name']) . "'>";
                                echo "<label>" . htmlspecialchars($row['name']) ."</label>";
                                echo "<div class='radio-container'>";
                                echo "<input type='radio' name='$position' value='" . htmlspecialchars($row['name']) . "' required>";
                                echo "</div>";
                                echo "</div>";
                            }
                        } else {
                            echo "<p>No candidates available for $position.</p>";
                        }
                        ?>
                    </div>
                <?php } ?>
                <input type="submit" value="Submit Votes">
            </form>
        </div>
    <?php } ?>
</body>
</html>

<?php $conn->close(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Positions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            text-align: center;
        }
        .container {
            background: rgba(0, 0, 0, 0.7);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.3);
        }
        .btn-add {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            border: none;
            color: white;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            text-decoration: none;
            transition: 0.3s;
            display: inline-block;
        }
        .btn-add:hover {
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
            transform: scale(1.05);
            box-shadow: 0px 4px 10px rgba(255, 75, 43, 0.5);
        }
        .sidebar {
    height: 100vh;
    width: 250px;
    background-color: rgba(30, 30, 30, 0.9); /* Increased opacity */
    padding: 20px;
}

.nav-item a.active {
    background-color: white !important;
    color: black !important;
}


    </style>
</head>
<body>

    <div class="container">
        <h2>Manage Candidate</h2>
        <p>Here you can add, update, and manage election Candidates</p>
        
        <!-- Add Position Button -->
        <a href="addcandi.php" class="btn-add">+ Add candidate</a>
    </div>

</body>
</html>

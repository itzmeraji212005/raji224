
<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update Profile Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';

    $sql = "UPDATE pro SET name=IF(? != '', ?, name), email=IF(? != '', ?, email) WHERE id=1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $name, $name, $email, $email);
    $stmt->execute();

    // Redirect to the profile update page to show updated data
    header("Location: profile.php");
    exit();
}

// Fetch User Data
$sql = "SELECT name, email, profile_pic FROM pro WHERE id=1";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
$conn->close();
?>
<?php include('admindashh.php')?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <style>
       body {
    background: white;
    font-family: 'Arial', sans-serif;
    display: flex;
    min-height: 100vh;
    margin: 0;
    padding: 0; /* Remove default body padding */
    justify-content: flex-start; /* Align sidebar to the left */
}

.sidebar {
    width: 250px;
    background-color: #343a40; /* Dark background for sidebar */
    color: #ffffff;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    align-items: flex-start; /* Align items to the left */
    flex-shrink: 0; /* Prevent sidebar from shrinking */
}

.sidebar a {
    color: #adb5bd;
    text-decoration: none;
    padding: 10px 0;
    display: block;
    width: 100%;
    transition: background-color 0.3s ease;
}

.sidebar a:hover {
    background-color: #495057;
}

.sidebar .admin-info {
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #6c757d;
    width: 100%;
}

.sidebar .admin-info strong {
    display: block;
    font-size: 1.2em;
    margin-bottom: 5px;
}

.sidebar .navigation {
    list-style: none;
    padding: 0;
    margin: 0;
    width: 100%;
}

.main-content {
    flex-grow: 1;
    display: flex;
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    padding: 30px; /* Ensure some padding around the content */
    background-color: #ffffff;
    min-height: 100vh; /* Take up the full height of the page */
}

.container {
    width: 400px;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 20px;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.profile-image-container {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    overflow: hidden;
    margin-bottom: 20px;
}

.profile-image-container img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* Ensure the image fills the circle */
}

label {
    display: block;
    text-align: left;
    margin-bottom: 10px;
    color: #333;
    font-weight: 600;
    width: 100%; /* Make label take full width */
}

input[type=text],
input[type=email] {
    width: calc(100% - 24px);
    padding: 12px;
    margin-bottom: 20px;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s ease;
}

input[type=text]:focus,
input[type=email]:focus {
    border-color: #007bff;
    outline: none;
}

.btn {
    display: inline-block;
    width: calc(100% - 24px);
    padding: 14px;
    background-color: #007bff;
    color: #ffffff;
    text-decoration: none;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
    box-sizing: border-box;
    margin-bottom: 15px;
}

.btn:hover {
    background-color: #0056b3;
}

.update-profile {
    margin-top: 30px;
    width: 100%; /* Make the button container full width */
}

.update-profile a {
    background-color: #28a745;
    display: block; /* Make the button a block element */
    text-align: center; /* Center the text inside the button */
}

.update-profile a:hover {
    background-color: #218838;
}

    </style>
</head>
<body>

    
    <div class="main-content">
        <div class="container">
            <div class="profile-image-container">
                <img src="<?php echo htmlspecialchars($user['profile_pic'] ?? ''); ?>" alt="Profile Picture">
            </div>
            <form method="POST">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email'] ?? ''); ?>" required>
                <label for="name">Name:</label>
                <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user['name'] ?? ''); ?>" required>
               <a href="admindashh.php" class="btn">OK</a>
            </form>
            <div class="update-profile">
                <a href="update-profile.php" class="btn">Update ProfilE</a>
            </div>
        </div>
    </div>
</body>
</html>
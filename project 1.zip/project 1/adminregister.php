<?php
$servername = "localhost"; // Change if your database server is different
$username = "root";         // Change as per your database login
$password = "";             // Change as per your database login
$dbname = "project";        // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching registered users
$sql = "SELECT regno, name, dept_name FROM register";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" integrity="sha384-k6RqeWeci5ZR/Lv4MR0sA0FfDOMqUA1uBBp25M2hV+Y3F8Z9lH6qC1q+KZSDEYo" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .user-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            justify-items: center;
        }
        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 300px;
            text-align: center;
        }
        .card h3 {
            margin: 0 0 10px;
            font-size: 1.5em;
        }
        .card p {
            margin: 5px 0;
            font-size: 1em;
            color: #555;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            color: #28a745;
            text-decoration: underline;
            text-align: center;
        }
    </style>
</head>
<body>

<h2>Registered Users</h2>
<div class="user-cards">
    <?php
    if ($result->num_rows > 0) {
        // Loop through and output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<div class='card'>
                    <h3>" . htmlspecialchars($row["name"]) . "</h3>
                    <p><strong>Registration Number:</strong> " . htmlspecialchars($row["regno"]) . "</p>
                    <p><strong>Department:</strong> " . htmlspecialchars($row["dept_name"]) . "</p>
                  </div>";
        }
    } else {
        echo "<div class='card'><p>No registrations found</p></div>";
    }
    $conn->close();
    ?>
</div>



</body>
</html>
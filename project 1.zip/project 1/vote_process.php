<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['regno'])) {
        die("Session expired. Please login again.");
    }

    $regno = $_SESSION['regno'];
    $votedCandidates = []; // Store voted candidates

    // Loop through submitted votes
    foreach ($_POST as $position => $name) {
        $stmt = $conn->prepare("UPDATE votee SET vote_count = vote_count + 1 WHERE name = ?");
        $stmt->bind_param("s", $name);

        if ($stmt->execute()) {
            $votedCandidates[$position] = $name; // Store voted candidate
        } else {
            die("Error updating votes: " . $stmt->error);
        }
    }

    // Destroy session after voting
    session_destroy();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f9f9f9;
            text-align: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            margin: auto;
        }
        h2 {
            color: #2c3e50;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            font-size: 18px;
            margin: 10px 0;
            color: #8A2BE2;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            text-decoration: none;
            background: #8A2BE2;
            color: white;
            border-radius: 8px;
        }
        a:hover {
            background: #6A1BBE;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Vote Recorded Successfully!</h2>
        <p>You have voted for:</p>
        <ul>
            <?php foreach ($votedCandidates as $position => $name) { ?>
                <li><strong><?php echo $position; ?>:</strong> <?php echo htmlspecialchars($name); ?></li>
            <?php } ?>
        </ul>
        <a href="demo.php">Back to Home</a>
    </div>
</body>
</html>

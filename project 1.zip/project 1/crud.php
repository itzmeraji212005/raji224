<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// File Upload Directory
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Insert or Update Candidate
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'] ?? '';
    $name = $_POST['name'];
    $position = $_POST['position'];
    $year = $_POST['year'];

    $targetFilePath = $_POST['existing_picture'] ?? ''; // Keep old picture as default

    // Handle image upload
    if (!empty($_FILES['picture']['name'])) {
        $fileName = basename($_FILES['picture']['name']);
        $targetFilePath = $uploadDir . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

        // Allow only specific image formats
        $allowedTypes = ['jpg', 'jpeg', 'png', 'avif'];
        if (in_array($fileType, $allowedTypes)) {
            // Delete the old picture if a new one is uploaded and it exists
            if ($id && !empty($_POST['existing_picture']) && file_exists($_POST['existing_picture'])) {
                unlink($_POST['existing_picture']);
            }
            if (!move_uploaded_file($_FILES['picture']['tmp_name'], $targetFilePath)) {
                die("Error uploading file.");
            }
        } else {
            die("Invalid file type! Only JPG, JPEG, PNG, and AVIF files are allowed.");
        }
    }

    if ($id) {
        // Update
        $sql = "UPDATE votee SET name=?, position=?, year=?, picture=? WHERE id=?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $position, $year, $targetFilePath, $id]);
    } else {
        // Insert
        $sql = "INSERT INTO votee (name, position, year, picture) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $position, $year, $targetFilePath]);
    }

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Delete Candidate
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    // Get the picture filename to delete from the server
    $stmt = $pdo->prepare("SELECT picture FROM votee WHERE id=?");
    $stmt->execute([$delete_id]);
    $picture = $stmt->fetchColumn();

    // Delete the file if it exists and is not empty
    if (!empty($picture) && file_exists($picture)) {
        unlink($picture);
    }

    // Delete from database
    $sql = "DELETE FROM votee WHERE id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$delete_id]);

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch all candidates
$sql = "SELECT * FROM votee";
$stmt = $pdo->query($sql);
$votees = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f3f3f3;
            text-align: center;
            padding: 20px;
        }
        .dashboard-button-container {
            text-align: left; /* Align the button to the left */
            margin-bottom: 20px; /* Add some space below the button */
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }
        .dashboard-button {
            display: inline-block;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            background-color: #007bff; /* Example blue color */
            border: none;
            cursor: pointer;
        }
        .dashboard-button:hover {
            background-color: #0056b3;
        }
        .form-container, table {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #6a0dad;
            text-align: center; /* Center the main headings */
        }
        .form-container h2 {
            text-align: left; /* Align the form sub-heading to the left */
        }
        input[type="text"], input[type="file"], button[type="submit"] {
            width: calc(100% - 22px); /* Adjust for padding and border */
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
            box-sizing: border-box; /* Ensure padding and border are inside the element's width */
        }
        input[type="file"] {
            padding-top: 5px; /* Adjust vertical alignment */
        }
        button[type="submit"] {
            background: #6a0dad;
            color: white;
            cursor: pointer;
            font-weight: bold;
            border: none;
        }
        button[type="submit"]:hover {
            background: #4e0a9b;
        }
        .file-label {
            display: block;
            margin-top: 10px;
            font-size: 14px;
            color: #555;
        }
        table {
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid black;
        }
        th {
            background-color: #6a0dad;
            color: white;
        }
        img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: block; /* Prevent extra space below image */
            margin: 0 auto; /* Center the image in the cell */
        }
        .btn {
            padding: 8px 12px; /* Increased padding for better touch targets */
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin: 5px; /* Increased margin */
            color: white;
            display: inline-block;
            font-size: 14px; /* Slightly smaller font for buttons */
            border: none; /* Remove default button border */
            cursor: pointer;
        }
        .btn-update {
            background: #007bff;
        }
        .btn-update:hover {
            background: #0056b3;
        }
        .btn-delete {
            background: #dc3545;
        }
        .btn-delete:hover {
            background: #c82333;
        }
        .form-container h2, .form-container input, .form-container button[type="submit"] {
            margin-left: auto;
            margin-right: auto;
            display: block; /* Make form elements take full width of their container */
            max-width: 400px; /* Limit the width of form elements */
        }
        .form-container input[type="file"], .form-container .file-label {
            max-width: 400px;
            text-align: left; /* Align file input and label to the left */
        }
    </style>
</head>
<body>

    <div class="dashboard-button-container">
        <a href="admindashh.php" class="dashboard-button">Go Back to Admin Dashboard</a>
    </div>

    <h1>Candidate Management</h1>

    <div class="form-container">
        <h2>Add/Update Candidate</h2>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id" id="id">
            <input type="text" name="name" id="name" placeholder="Name" required>
            <input type="text" name="position" id="position" placeholder="Position" required>
            <input type="text" name="year" id="year" placeholder="Year" required>

            <label for="picture" class="file-label">Upload Candidate Picture (JPG, JPEG, PNG, AVIF)</label>
            <input type="file" name="picture" id="picture" accept=".jpeg,.jpg,.png,.avif">
            <input type="hidden" name="existing_picture" id="existing_picture">

            <button type="submit">Save Candidate</button>
        </form>
    </div>

    <h2>Candidate List</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Position</th>
                <th>Year</th>
                <th>Picture</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($votees as $votee): ?>
                <tr>
                    <td><?= $votee['id'] ?></td>
                    <td><?= htmlspecialchars($votee['name']) ?></td>
                    <td><?= htmlspecialchars($votee['position']) ?></td>
                    <td><?= htmlspecialchars($votee['year']) ?></td>
                    <td><img src="<?= htmlspecialchars($votee['picture']) ?>" alt="<?= htmlspecialchars($votee['name']) ?>"></td>
                    <td>
                        <button class="btn btn-update" onclick="editCandidate(<?= $votee['id'] ?>, '<?= htmlspecialchars($votee['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($votee['position'], ENT_QUOTES) ?>', '<?= htmlspecialchars($votee['year'], ENT_QUOTES) ?>', '<?= htmlspecialchars($votee['picture'], ENT_QUOTES) ?>')">Edit</button>
                        <a href="?delete_id=<?= $votee['id'] ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this candidate?');">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        function editCandidate(id, name, position, year, picture) {
            document.getElementById('id').value = id;
            document.getElementById('name').value = name;
            document.getElementById('position').value = position;
            document.getElementById('year').value = year;
            document.getElementById('existing_picture').value = picture;
        }
    </script>

</body>
</html>
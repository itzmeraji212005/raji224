<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Add Candidate
$successMessage = "";
$errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_candidate'])) {
    $candidate_name = trim($_POST['name']);
    $position = $_POST['position'];
    $year = $_POST['year'];

    // Handle file upload OR existing image selection
    if (!empty($_FILES["picture"]["name"])) {
        $targetDir = " ";
        $fileName = basename($_FILES["picture"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

        $allowedTypes = array("jpg", "jpeg", "png", "gif");
        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($_FILES["picture"]["tmp_name"], $targetFilePath)) {
                $picturePath = $targetFilePath;
            } else {
                $errorMessage = "File upload failed!";
            }
        } else {
            $errorMessage = "Only JPG, JPEG, PNG & GIF files are allowed.";
        }
    } else {
        // Use existing picture
        $picturePath = $_POST['existing_picture'];
    }

    // Insert into database
    if (!empty($picturePath)) {
        try {
            $sql = "INSERT INTO votee (name, position, year, picture) VALUES (:name, :position, :year, :picture)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':name' => $candidate_name,
                ':position' => $position,
                ':year' => $year,
                ':picture' => $picturePath
            ]);
            $successMessage = "Candidate added successfully!";
            
            // Redirect to admin dashboard after success
            header("Location: admindashh.php");
            exit();  // Always call exit after header redirection to stop further execution
        } catch (PDOException $e) {
            $errorMessage = "Error adding candidate: " . $e->getMessage();
        }
    } else {
        $errorMessage = "Please select or upload a picture.";
    }
}

// Fetch Positions from the 'position' table
$sql = "SELECT position_name FROM position";
$stmt = $pdo->query($sql);
$positions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidates List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<style>
    body {
        background: white;
    }
</style>
<body>
<div class="container mt-4">
    <h2>Candidates List</h2>

    <!-- Success & Error Messages -->
    <?php if (!empty($successMessage)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addCandidateModal">+ New</button>

    <!-- Candidates Table -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Picture</th>
                <th>Candidate Name</th>
                <th>Position</th>
                <th>Year</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT name, position, year, picture FROM votee";
            $stmt = $pdo->query($sql);
            $candidates = $stmt->fetchAll();
            ?>
            <?php if (count($candidates) > 0): ?>
                <?php foreach ($candidates as $candidate): ?>
                    <tr>
                        <td><img src="<?= htmlspecialchars($candidate['picture']) ?>" width="50" height="50"></td>
                        <td><?= htmlspecialchars($candidate['name']) ?></td>
                        <td><?= htmlspecialchars($candidate['position']) ?></td>
                        <td><?= htmlspecialchars($candidate['year']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center">No data available in table</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Add Candidate Modal -->
    <div class="modal fade" id="addCandidateModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Candidate</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">Candidate Name</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Position</label>
                            <select name="position" class="form-control" required>
                                <option value="">Select Position</option>
                                <?php foreach ($positions as $position): ?>
                                    <option value="<?= htmlspecialchars($position['position_name']) ?>"><?= htmlspecialchars($position['position_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Year</label>
                            <select name="year" class="form-control" required>
                                <option value="">Select Year</option>
                                <option value="2">2nd Year</option>
                                <option value="3">3rd Year</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Upload Picture</label>
                            <input type="file" name="picture" class="form-control" required accept="image/*">
                        </div>
                        <button type="submit" name="add_candidate" class="btn btn-success">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

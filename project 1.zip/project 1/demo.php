
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online College Voting</title>
    <link rel="stylesheet" href="demo1.css">  <!-- Link to your CSS file -->
      <!-- Correct Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<style>
      .navbar {
            background-color:#8A2BE2;
            padding: 30px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            color: white;
            margin: 0;
            font-size: 30px;
            display: flex;
            align-items: center;
        }
        .navbar h1 i {
            margin-right: 18px;
        }
        .nav-links {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            margin: 0 20px;
        }
        .nav-links li a {
            text-decoration: none;
            color: white;
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            padding: 8px 10px;
            border-radius: 7px;
            transition: background 0.5s;
        }
        .nav-links li a i {
            margin-right: 8px;
        }
        .nav-links li a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
</style>
<body>
 <div class="navbar">
        <h1><i class="fa-solid fa-vote-yea"></i> Online College Voting System</h1>
        <ul class="nav-links">
            <li><a href="demo.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="about.php"><i class="fa-solid fa-circle-info"></i> About</a></li>
            <li><a href="candi.php"><i class="fa-solid fa-users"></i> Candidates</a></li>
            <li><a href="voteeuh.php"><i class="fa-solid fa-check"></i> Voting</a></li>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>
    <section class="hero">
        <div class="hero-body">
            <div class="container">
                <h1 class="title">
                    Welcome to Online College Voting!
                </h1>
                <p class="subtitle">
                    Your voice, your vote, our future.
                </p>
                <div class="quotes">
                    <?php
                    $quotes = [
                        "“The ballot is stronger than the bullet.” - Abraham Lincoln",
                        "“Democracy cannot succeed unless those who express their choice vote. ” - James Bryce",
                        "“Voting is the most basic right and responsibility of a citizen.” -  George W. Bush",
                        "“Elections belong to the people. It’s their decision. If they decide to turn their back on the fire and burn their behinds, then they will just have to sit on their blisters.” - Abraham Lincoln"
                    ];
                    $randomQuote = $quotes[array_rand($quotes)];
                    echo "<p class='quote'>\"" . $randomQuote . "\"</p>";
                    ?>
                </div>

                <div class="visual">
                    <img src="v.png" alt="Voting Image" style="width: 120%; max-width: 1000px; border-radius: 8px;">  <!-- Replace with your image -->
                </div>
            </div>
        </div>
    </section>
    <?php include('textoverimage.php')
    ?>
   <div class="vote-container">
    <h1>Let's Vote!</h1>
    <p>Your voice matters. Click the button below to cast your vote.</p>
    <a href="vote1.php" class="vote-button">Vote Now</a>
</div>


    <footer class="footer">
        <div class="content has-text-centered">
            <p>
                &copy; <?php echo date("Y"); ?> Online College Voting. All rights reserved.
            </p>
        </div>
    </footer>

</body>
</html>
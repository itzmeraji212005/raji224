document.getElementById('viewMoreBtn').addEventListener('click', function() {
    // Redirect to a different page
    window.location.href = 'view_more_candidates.php';
});
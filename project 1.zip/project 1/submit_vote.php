<?php
session_start();

// Database credentials
$host = 'localhost';  // Hostname
$db_user = 'root'; // Your database username
$db_pass = 'raji'; // Your database password
$db_name = 'project'; // Your database name

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize votes
    if (!isset($_SESSION['votes'])) {
        $_SESSION['votes'] = [];
    }

    // Clear previous votes if required - Uncomment if you want to allow only one vote per position
    // $_SESSION['votes'] = [];

    foreach ($_POST as $position => $name) {
        // Ensure that the name is not empty and the position is a valid category
        if (!empty($name)) {
            // Sanitize the user input
            $name = $mysqli->real_escape_string(htmlspecialchars($name));
            $_SESSION['votes'][$position] = $name;

            // Prepare and execute the SQL statement
            $sql = "INSERT INTO votes (position, name) 
                    VALUES ('$position', '$name')";

            if (!$mysqli->query($sql)) {
                echo "Error: " . $mysqli->error; // Handle SQL error
            }
        }
    }

    // Redirect to results page
    header('Location: results.php');
    exit;
} else {
    // Redirect to vote page if accessed without a post request
    header('Location: vote.php');
    exit;
}

// Close the database connection
$mysqli->close();
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch candidates who have received at least one vote
$sql = "SELECT
            v.name AS candidate_name,
            v.position AS candidate_position
        FROM
            votee v
        WHERE
            v.vote_count > 0
        ORDER BY
            v.position";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Report - Candidates with Votes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 20px;
        }
        .back-button-container {
            text-align: left; /* Align the button to the left */
            margin-bottom: 20px; /* Add some space below the button */
        }
        .back-button {
            display: inline-block;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            color: white;
            background-color: #007bff; /* Example blue color */
            border: none;
            cursor: pointer;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        table {
            width: 60%; /* Adjust width as needed */
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-left: auto;
            margin-right: auto;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        h2 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        p.no-votes {
            text-align: center;
            font-style: italic;
            color: #777;
        }
    </style>
</head>
<body>

    <div class="back-button-container">
        <a href="firstreport.php" class="back-button">Go Back</a>
    </div>

    <h2>Voting Report - Candidates with Votes</h2>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Candidate Name</th>";
        echo "<th>Position</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["candidate_name"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["candidate_position"]) . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p class='no-votes'>No candidates have received any votes yet.</p>";
    }

    $conn->close();
    ?>

</body>
</html>
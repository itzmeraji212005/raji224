<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get candidate ID from URL
$candidateId = $_GET['id'];

// SQL to select candidate details
$sql_select = "SELECT * FROM candidates WHERE id = " . $candidateId;
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .candidate-details {
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            padding: 20px;
            max-width: 600px;
            margin: 20px auto;
        }
        .candidate-details img{
            max-width: 300px;
            max-height: 300px;
            border-radius: 50%;
            margin-bottom: 20px;
        }
    </style>";

    echo "<div class='candidate-details'>";
    echo "<img src='" . $row["picture"] . "' alt='" . $row["name"] . "'>";
    echo "<h2>" . $row["name"] . "</h2>";
    echo "<p><strong>Position:</strong> " . $row["position"] . "</p>";
    echo "<p><strong>Year:</strong> " . $row["year"] . "</p>";
    echo "<p><strong>Position Description:</strong> " . getPositionDescription($row["position"]) . "</p>";
    echo "</div>";

} else {
    echo "Candidate not found.";
}

$conn->close();

function getPositionDescription($position) {
    // Brief descriptions for each candidate position
    $descriptions = [
        'Chairman' => 'Leads the organization, ensures smooth operations, and represents the group.',
        'Vice Chairman' => 'Supports the Chairman, fills in during absences, and manages specific tasks.',
        'Secretary' => 'Manages records, handles correspondence, and organizes meetings.',
        'Joint Secretary' => 'Assists the Secretary with administrative duties and record-keeping.',
        'President' => 'The highest authority, sets the vision, and represents the organization.',
        'Vice President' => 'Supports the President and takes on leadership roles as needed.',
        'Union Advisor' => 'Provides guidance, advice, and ensures compliance with regulations.',
        'Sports Secretary' => 'Organizes sports events, manages teams, and promotes sports participation.'
    ];

    return isset($descriptions[$position]) ? $descriptions[$position] : 'Description not available.';
}
   
?>
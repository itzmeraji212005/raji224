<?php
// Database connection details (replace with your values)
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = "";
$email = "";
$image = "";
$message = "";

// Fetch existing profile data
$result = $conn->query("SELECT * FROM admin_profile LIMIT 1");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row["name"];
    $email = $row["email"];
    $image = $row["image"];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];

    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $file_tmp = $_FILES["image"]["tmp_name"];
        $file_type = mime_content_type($file_tmp);
        $allowed_types = ["image/jpeg", "image/png", "image/gif"];

        if (in_array($file_type, $allowed_types)) {
            $file_name = "raji." . pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
            $target_file = "C:\\xampp\\htdocs\\raji\\" . $file_name; // Changed to full path

            if (move_uploaded_file($file_tmp, $target_file)) {
                $image = $file_name;
            } else {
                $message = "Upload failed.";
            }
        } else {
            $message = "Invalid image type.";
        }
    }

    $sql = "UPDATE admin_profile SET name='$name', email='$email'";
    if (!empty($image)) {
        $sql .= ", image='$image'";
    }
    $sql .= " LIMIT 1";

    if (empty($message) && $conn->query($sql) === TRUE) {
        $message = "Profile updated.";
        $row = $conn->query("SELECT * FROM admin_profile LIMIT 1")->fetch_assoc();
        $name = $row["name"];
        $email = $row["email"];
        $image = $row["image"];
    } else if (empty($message)) {
        $message = "Update error: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }

        input[type="text"], input[type="email"], input[type="file"], button {
            display: block;
            margin-bottom: 10px;
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }

        a {
            display: block;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            background-color: #6c757d;
            color: white;
            padding: 10px;
            border-radius: 4px;
        }

        p {
            margin-top: 10px;
            padding: 10px;
            border-radius: 4px;
        }

        p.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        p.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        <input type="text" name="name" value="<?php echo $name; ?>" required><br>
        <input type="email" name="email" value="<?php echo $email; ?>" required><br>
        <input type="file" name="image" accept="image/*"><br>
        <button type="submit">Update</button>
        <a href="profile.php">Back</a>
        <?php if (!empty($message)) {
            $class = (strpos($message, "Profile updated.") !== false) ? "success" : "error";
            echo "<p class='$class'>$message</p>";
        } ?>
    </form>
</body>
</html>
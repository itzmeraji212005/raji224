<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the admin profile exists. If not, create a default one.
$sql = "SELECT * FROM admin_profile LIMIT 1";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    $defaultName = "Admin User";
    $defaultEmail = "admin@example.com";
    $defaultImage = "default.png"; // Place default.png in the same directory

    $sql = "INSERT INTO admin_profile (name, email, image) VALUES ('$defaultName', '$defaultEmail', '$defaultImage')";

    if ($conn->query($sql) === TRUE) {
        // Profile created successfully
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $result = $conn->query("SELECT * FROM admin_profile LIMIT 1"); // re-fetch the new record
}

// Fetch admin profile data
$row = $result->fetch_assoc();
$adminName = $row["name"];
$adminEmail = $row["email"];
$adminImage = $row["image"];


$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Profile</title>
    <style>
        body {
            font-family: sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .profile-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
        }

        .profile-name {
            font-size: 24px;
            margin-bottom: 8px;
        }

        .profile-email {
            color: #666;
            margin-bottom: 15px;
        }

        .profile-edit-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <img src="<?php echo $adminImage; ?>" alt="Admin Profile" class="profile-image">
        <h2 class="profile-name"><?php echo $adminName; ?></h2>
        <p class="profile-email"><?php echo $adminEmail; ?></p>
        <a href="update-profile.php" class="profile-edit-button">Edit Profile</a>
    </div>
</body>
</html>

<?php
// edit_profile.php (example of an edit profile page, you will need to complete this)
// Database connection details (same as above)
// ... database connection code...
// ... fetch existing profile data...
// ... form to edit data...
// ... update query...
?>
<?php
$servername = "localhost";
$username = "root"; // Change as needed
$password = "raji";
$dbname = "project"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve vote counts
$sql = "SELECT position, candidate_name, vote_count FROM vote ORDER BY position, vote_count DESC";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }

        th {
            background-color: #28a745;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h1>Election Results</h1>

<table>
    <tr>
        <th>Position</th>
        <th>Candidate Name</th>
        <th>Votes</th>
    </tr>

    <?php
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row['position']) . "</td>";
            echo "<td>" . htmlspecialchars($row['candidate_name']) . "</td>";
            echo "<td>" . htmlspecialchars($row['vote_count']) . "</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='3'>No votes have been cast yet.</td></tr>";
    }
    ?>

</table>

</body>
</html>

<?php
$conn->close();
?>

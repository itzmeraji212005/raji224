<?php
// Database connection details (replace with your values)
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// CRUD operations for 'candidates' table (position, year, picture)

// Initialize variables
$id = isset($_GET['id']) ? $_GET['id'] : null;
$position = "";
$name="";
$year = "";
$picture = "";
$message = "";

// Fetch candidate data for editing
if ($id && isset($_GET['action']) && $_GET['action'] == 'edit') {
    $sql = "SELECT * FROM candidates WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $position = $row['position'];
        $name=$row['name'];
        $year = $row['year'];
        $picture = $row['picture'];
    } else {
        $message = "Candidate not found.";
    }
    $stmt->close();
}

// Handle form submission (edit/add)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $position = $_POST['position'];
    $name=$_POST['name'];
    $year = $_POST['year'];

    if (isset($_FILES["picture"]) && $_FILES["picture"]["error"] == 0) {
        $file_tmp = $_FILES["picture"]["tmp_name"];
        $file_type = mime_content_type($file_tmp);
        $allowed_types = ["image/jpeg", "image/png", "image/gif"];

        if (in_array($file_type, $allowed_types)) {
            $file_name = uniqid() . "." . pathinfo($_FILES["picture"]["name"], PATHINFO_EXTENSION);
            $target_file = "uploads/" . $file_name;

            if (move_uploaded_file($file_tmp, $target_file)) {
                $picture = $file_name;
            } else {
                $message = "Upload failed.";
            }
        } else {
            $message = "Invalid image type.";
        }
    }

    if ($id) { // Edit operation
        $sql = "UPDATE candidates SET position = ?, year = ?";
        if (!empty($picture)) {
            $sql .= ", picture = '$picture'";
        }
        $sql .= " WHERE id = ?";
        $stmt = $conn->prepare($sql);
        if (!empty($picture)) {
            $stmt->bind_param("sssi", $position,$name, $year, $id);
        } else {
            $stmt->bind_param("sssi", $position,$name, $year, $id);
        }

        if ($stmt->execute()) {
            $message = "Candidate updated successfully.";
        } else {
            $message = "Error updating candidate: " . $stmt->error;
        }
        $stmt->close();
    } else { // Add operation(if you want add operation, add the add html part too)
        $sql = "INSERT INTO candidates (position,name, year, picture) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $position,$name,$year, $picture);
        if ($stmt->execute()) {
            $message = "Candidate added successfully.";
        } else {
            $message = "Error adding candidate: " . $stmt->error;
        }
        $stmt->close();
    }
}

// Handle delete operation
if ($id && isset($_GET['action']) && $_GET['action'] == 'delete') {
    $sql = "DELETE FROM candidates WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = "Candidate deleted successfully.";
    } else {
        $message = "Error deleting candidate: " . $stmt->error;
    }
    $stmt->close();
    //Clear the ID so edit form wont show
    $id = null;
}

// Fetch all candidates for display
$sql = "SELECT * FROM candidates";
$result = $conn->query($sql);
$candidates = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $candidates[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Candidates CRUD</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        h3 {
            margin-top: 30px;
            color: #007bff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f0f0f0;
        }

        img {
            max-width: 100px;
            height: auto;
            display: block;
            margin: 0 auto;
            border-radius: 5px;
        }

        form {
            max-width: 500px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        input[type="text"], input[type="number"], input[type="file"], button {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .edit-btn {
            background-color: #ffc107;
            color: #333;
            border: none;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .edit-btn:hover {
            background-color: #e0a800;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .success, .error {
            padding: 15px;
            margin: 20px auto;
            max-width: 500px;
            border-radius: 4px;
            text-align: center;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <h2>Candidates CRUD</h2>

    <?php if (!empty($message)) echo "<p class='" . (strpos($message, "successfully") !== false ? "success" : "error") . "'>$message</p>"; ?>

    <?php if ($id && isset($_GET['action']) && $_GET['action'] == 'edit'): ?>
        <form method="post" enctype="multipart/form-data">
            <input type="text" name="position" value="<?php echo $position; ?>" placeholder="Position" required><br>
            <input type="number" name="year" value="<?php echo $year; ?>" placeholder="Year" required><br>
            <input type="file" name="picture" accept="image/*"><br>
            <button type="submit">Update Candidate</button>
        </form>
    <?php endif; ?>

    <h3>Candidates List</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Position</th>
                <th>Year</th>
                <th>Picture</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($candidates as $candidate): ?>
                <tr>
                    <td><?php echo $candidate['id']; ?></td>
                    <td><?php echo $candidate['position']; ?></td>
                    <td><?php echo $candidate['year']; ?></td>
                    <td><img src="uploads/<?php echo $candidate['picture']; ?>" alt="Candidate Picture" style="max-width: 100px;"></td>
                    <td>
                        <a href="?action=edit&id=<?php echo $candidate['id']; ?>">Edit</a>
                        <a href="?action=delete&id=<?php echo $candidate['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
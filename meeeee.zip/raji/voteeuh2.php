<?php
session_start();

// Database credentials
$host = 'localhost'; 
$db_user = 'root';
$db_pass = 'suba'; 
$db_name = 'project'; 

// Database Connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch votes
$results = [];
$sql = "SELECT position, candidate_name, COUNT(*) as vote_count FROM votes GROUP BY position, candidate_name";
$result = $mysqli->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $results[$row['position']][$row['candidate_name']] = $row['vote_count'];
    }
}

// Check for voters
$voter_count = $mysqli->query("SELECT COUNT(*) as total FROM voters")->fetch_assoc()['total'];
$has_voted_count = $mysqli->query("SELECT COUNT(*) as total FROM voters WHERE has_voted = TRUE")->fetch_assoc()['total'];
$not_voted_count = $voter_count - $has_voted_count;

$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
        }
        .results-container {
            max-width: 600px;
            margin: auto;
        }
        .result {
            background: #fff;
            padding: 15px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn {
            display: inline-block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Voting Results</h1>
    <div class="results-container">
        <?php foreach ($results as $position => $candidates): ?>
            <div class="result">
                <h2><?php echo $position; ?> Results</h2>
                <?php foreach ($candidates as $name => $vote_count): ?>
                    <p><?php echo htmlspecialchars($name) ?>: <?php echo $vote_count; ?> votes</p>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
        <div class="result">
            <h2>Total Participation</h2>
            <p>Voters who have cast votes: <?php echo $has_voted_count; ?></p>
            <p>Voters who have not voted: <?php echo $not_voted_count; ?></p>
        </div>
    </div>
    <a href="demo.php" class="btn">Back</a>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Status</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f9;
            color: #333;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
        }

        h2 {
            text-align: center;
            color: #007bff;
            margin-bottom: 20px;
        }

        table {
            width: 90%; /* Increased width for better readability */
            border-collapse: collapse;
            margin: 20px auto;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden; /* Ensures rounded corners work */
        }

        th, td {
            border: 1px solid #e0e0e0;
            padding: 12px 15px; /* Increased padding */
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #e8f0fe;
        }

        td:last-child {
            text-align: center;
            font-weight: 500;
            color: #28a745; /* Green for "Voted" */
        }

        @media screen and (max-width: 600px) {
            table {
                width: 100%; /* Full width on smaller screens */
            }
            th, td {
                padding: 8px 10px;
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>

    <h2>Voting Status</h2>

    <table>
        <thead>
            <tr>
                <th>User Name</th>
                <th>Chairman</th>
                <th>Vice Chairman</th>
                <th>Secretary</th>
                <th>Joint Secretary</th>
                <th>President</th>
                <th>Vice President</th>
                <th>Union Advisor</th>
                <th>Sports Secretary</th>
                <th>Voting Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Raji</td>
                <td>Abdul</td>
                <td>Jeeva</td>
                <td>Kathir</td>
                <td>Manoj</td>
                <td>Ravi</td>
                <td>Kavin</td>
                <td>Harish</td>
                <td>Xavier</td>
                <td>Voted</td>
            </tr>
        </tbody>
    </table>

</body>
</html>
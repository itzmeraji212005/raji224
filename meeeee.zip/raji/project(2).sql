-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 24, 2025 at 01:46 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_profile`
--

CREATE TABLE `admin_profile` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `image` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_profile`
--

INSERT INTO `admin_profile` (`id`, `name`, `email`, `image`) VALUES
(0, 'mani', 'mani@gmail.com', 'raji.jpg'),
(0, 'mukil', 'mukil@gmail.com', 'profile.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(11) NOT NULL,
  `position` varchar(55) NOT NULL,
  `name` varchar(25) NOT NULL,
  `year` varchar(25) NOT NULL,
  `picture` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `position`, `name`, `year`, `picture`) VALUES
(1, 'Chairman', 'Manik', '3rd Year', 'person1.jpg'),
(2, 'Chairman', 'Gowsi', '2nd Year', 'person3.jpg'),
(3, 'Chairman', 'Abdul', '3rd Year', 'person2.png'),
(4, 'Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg'),
(5, 'Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg'),
(6, 'Secretary', 'Kumar', '3rd Year', 'person7.jpg'),
(7, 'Secretary', 'Vikas', '2nd Year', 'person6.jpg'),
(8, 'Joint Secretary', 'Raji', '3rd Year', 'raji.jpeg'),
(9, 'Joint Secretary', 'Anu', '3rd Year', 'person9.jfif'),
(10, 'President', 'Arun', '3rd Year', 'per10.jpg'),
(11, 'President', 'Kavin', '2nd Year', 'person11.jpg'),
(12, 'Vice President', 'Manju', '2nd Year', 'women.avif'),
(13, 'Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg'),
(14, 'Sports Secretary', 'Alex', '3rd Year', 'person13.avif'),
(15, 'Sports Secretary', 'Siva', '3rd Year', 'person14.jpg'),
(16, 'Sports Secretary', 'Abinash', '2nd Year', 'person15.avif');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('raji', 'raji'),
('divya', 'divya');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `position_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_name`) VALUES
('Chairman'),
('Vice Chairman'),
('Secretary'),
('Joint Secretary'),
('President'),
('Vice President'),
('Union Advisor'),
('Sports Secretary');

-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE `pro` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `profile_pic` varchar(25) DEFAULT 'profile.jpeg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pro`
--

INSERT INTO `pro` (`id`, `name`, `email`, `description`, `profile_pic`) VALUES
(1, 'Mukil', 'Mukil@gmail.com', 'An online college voting system administrator manages the digital platform that facilitates student participation in elections, ensuring secure and user-friendly access for all voters. Responsibilities include configuring voting software, troubleshooting technical issues, and overseeing the integrity of the election process. The admin also collects and analyzes voting data to provide insights and reports on election outcomes.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `regno` varchar(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dept_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`regno`, `name`, `dept_name`) VALUES
('22UCA531', 'raji', 'Dept of Computer application'),
('22UCA531', 'raji', 'Dept of Computer application'),
('21UVCA31', 'Mariya', 'Dept of Visual Communication'),
('20UTA534', 'geetha', 'Dept of Tamil'),
('22UCA531', 'keerthana', 'Dept of Computer application');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `voter_id` int(11) DEFAULT NULL,
  `position` varchar(25) DEFAULT NULL,
  `candidate_name` varchar(25) DEFAULT NULL,
  `vote_count` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `voter_id`, `position`, `candidate_name`, `vote_count`) VALUES
(1, 0, 'Chairman', 'Gowsi', 1),
(2, 0, 'Vice_Chairman', 'Kiruba', 1),
(3, 0, 'Secretary', 'Vikas', 1),
(4, 0, 'Joint_Secretary', 'Anu', 1),
(5, 0, 'President', 'Kavin', 1),
(6, 0, 'Vice_President', 'Manju', 1),
(7, 0, 'Union_Advisor', 'Saravanan', 1),
(8, 0, 'Sports_Secretary', 'Abinash', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `voter_id` (`voter_id`,`position`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `pro`
--
ALTER TABLE `pro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

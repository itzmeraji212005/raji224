<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "raji";  // Replace with your actual password
$dbname = "project"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the vote is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the candidate ID from the form submission
    $candidate_id = $_POST['candidate_id'];

    // Update the vote count for the selected candidate
    $sql = "UPDATE vote SET vote_count = vote_count + 1 WHERE candidate_id = '$candidate_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Vote counted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Fetch candidates for displaying the voting options
$sql_select = "SELECT c.id, c.name, c.position, c.picture FROM candidates c";
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    echo "<h2>Select a Candidate to Vote</h2>";
    echo "<form method='POST' action='vote.php'>";
    echo "<div style='display: flex; flex-wrap: wrap; justify-content: space-around;'>";

    // Display all candidates with a vote button
    while ($row = $result->fetch_assoc()) {
        echo "<div style='text-align: center; width: 200px; margin-bottom: 20px;'>";
        echo "<img src='" . $row['picture'] . "' alt='" . $row['name'] . "' style='width: 120px; height: 120px; border-radius: 50%;'>";
        echo "<h3>" . $row['name'] . "</h3>";
        echo "<p>" . $row['position'] . "</p>";
        echo "<button type='submit' name='candidate_id' value='" . $row['id'] . "' style='background-color: #4CAF50; color: white; padding: 10px 15px; border: none; border-radius: 5px;'>Vote</button>";
        echo "</div>";
    }

    echo "</div>";
    echo "</form>";
} else {
    echo "No candidates found.";
}

$conn->close();
?>

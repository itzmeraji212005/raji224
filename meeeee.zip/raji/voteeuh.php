<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote for Candidates</title>
</head>
<body>

<h1>Vote for Your Candidate</h1>

<form action="submit_vote.php" method="post">
    <label for="candidate_id">Select Candidate:</label>
    <select name="candidate_id" required>
        <!-- Dynamic options will be populated from the database -->
        <?php
            // Assuming you have a database connection already here
            $pdo = new PDO("mysql:host=localhost;project;charset=utf8", "root", " ");

            $stmt = $pdo->query("SELECT id, name FROM viewvotes");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<option value=\"" . $row['id'] . "\">" . htmlspecialchars($row['name']) . "</option>";
            }
        ?>
    </select>
    <button type="submit">Vote</button>
</form>

</body>
</html>
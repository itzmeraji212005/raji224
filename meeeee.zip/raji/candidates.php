<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to select all data, grouped by position
$sql_select = "SELECT * FROM candidates ORDER BY position";
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    // Output data in a table
    echo "<style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .candidate-group {
            margin-bottom: 30px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .candidate-group h2 {
            background-color: #007bff;
            color: white;
            padding: 15px;
            margin: 0;
            text-align: center;
        }

        .candidate-list {
            display: flex;
            justify-content: space-around;
            padding: 20px;
        }

        .candidate-item {
            text-align: center;
            width: 30%;
        }

        .candidate-item img {
            max-width: 120px;
            max-height: 120px;
            border-radius: 50%;
            margin-bottom: 10px;
        }

        .candidate-item button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .candidate-item button:hover {
            background-color: #45a049;
        }
    </style>";

    $currentPosition = '';
    while ($row = $result->fetch_assoc()) {
        if ($currentPosition != $row["position"]) {
            if ($currentPosition != '') {
                echo "</div></div>"; // Close previous group
            }
            $currentPosition = $row["position"];
            echo "<div class='candidate-group'>";
            echo "<h2>" . $currentPosition . "</h2>";
            echo "<div class='candidate-list'>";
        }
        echo "<div class='candidate-item'>";
        echo "<img src='" . $row["picture"] . "' alt='" . $row["name"] . "'>";
        echo "<h3>" . $row["name"] . "</h3>";
        echo "<p>" . $row["year"] . "</p>";
        echo "<button onclick='viewDetails(\"" . $row["id"] . "\")'>View Details</button>";
        echo "</div>";
    }
    echo "</div></div>"; // Close last group

    echo "<script>
        function viewDetails(id) {
            window.location.href = 'candidate_details.php?id=' + id;
        }
    </script>";
} else {
    echo "0 results";
}

$conn->close();
?>
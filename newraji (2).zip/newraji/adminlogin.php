<?php
$host = 'localhost';
$db = 'project';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = ""; // Initialize an empty error message variable

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);
    
    // Check against hardcoded credentials (for demonstration purposes only; use a database in production)
    if ($username == "admin" && $password == "admin123") {
        echo '<script>
        alert("Admin Login Successfully");
        window.location.href="admindash.php";
        </script>';
        exit();
    } else {
        $error = "Invalid credentials!"; // Set the error message
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="styles.css"> <!-- External CSS file -->
</head>
<style>
    body {
    background: url('img1.jpg') no-repeat center center fixed;
    background-size: cover;
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.login-container {
    background: rgba(0, 0, 0, 0.5);
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
    text-align: center;
    width: 400px;
    backdrop-filter: blur(5px);
    position: relative;
}

.login-container h1 {
    color: #fff;
    font-size: 24px;
    margin-bottom: 20px;
}

.input-group {
    position: relative;
    margin-bottom: 20px;
}

.input-group input {
    width: 90%;
    padding: 12px;
    padding-left: 35px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    background: rgba(255, 255, 255, 0.8);
}

.input-group i {
    position: absolute;
    left: 15px;
    top: 50%;
    transform: translateY(-50%);
    color: #333;
}

button {
    width: 100%;
    padding: 12px;
    background:blue;
    border: none;
    color: #fff;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: 0.3s;
}

button:hover {
    background: #c9302c;
}

</style>
<body>
    <div class="login-container">
        <h1><i class="fas fa-user-circle"></i> Admin Login</h1>
        <form method="POST" action="">
            <div class="input-group">
                <i class="fas fa-user"></i>
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <i class="fas fa-lock"></i>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit">Log in</button>
        </form>
    </div>
</body>
</html>

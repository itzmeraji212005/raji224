<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chairman & Vice Chairman Vote Tally</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }

        .tally-container {
            background-color: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            width: 350px;
            transition: box-shadow 0.3s ease;
            margin-bottom: 20px;
        }

        .tally-container:hover {
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #2c3e50;
            font-weight: 600;
        }

        .candidate-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            border-bottom: 1px solid #e0e0e0;
            transition: background-color 0.3s ease;
        }

        .candidate-row:last-child {
            border-bottom: none;
        }

        .candidate-row:hover {
            background-color: #f9f9f9;
        }

        .candidate-name {
            font-weight: 500;
            color: #34495e;
        }

        .vote-count {
            font-weight: 600;
            color: #1abc9c;
            padding: 8px 15px;
            border-radius: 20px;
            background-color: #e0f7fa;
            text-align: center;
            min-width: 50px;
        }

        .total-votes {
            margin-top: 30px;
            text-align: center;
            font-weight: 600;
            color: #2c3e50;
            padding: 15px;
            background-color: #ecf0f1;
            border-radius: 8px;
        }

        .tally-group {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .tally-group .tally-container {
          margin: 10px;
        }
    </style>
</head>
<body>
    <div class="tally-group">
        <div class="tally-container">
            <h2>Chairman Vote Tally</h2>
            <div class="candidate-row">
                <span class="candidate-name">Tamil</span>
                <span class="vote-count" id="tamil-votes">1</span>
            </div>
            <div class="candidate-row">
                <span class="candidate-name">Gowsi</span>
                <span class="vote-count" id="gowsi-votes">0</span>
            </div>
            <div class="candidate-row">
                <span class="candidate-name">Abdul</span>
                <span class="vote-count" id="abdul-votes">0</span>
            </div>
           
        </div>

        <div class="tally-container">
            <h2>Vice Chairman Vote Tally</h2>
            <div class="candidate-row">
                <span class="candidate-name">Pooja</span>
                <span class="vote-count" id="pooja-votes">0</span>
            </div>
            <div class="candidate-row">
                <span class="candidate-name">John</span>
                <span class="vote-count" id="john-votes">1</span>
            </div>
           
        </div>
    </div>

    <script>
        function updateTally(tamilVotes, gowsiVotes, abdulVotes, poojaVotes, johnVotes) {
            document.getElementById('tamil-votes').textContent = tamilVotes;
            document.getElementById('gowsi-votes').textContent = gowsiVotes;
            document.getElementById('abdul-votes').textContent = abdulVotes;
            document.getElementById('total-votes').textContent = tamilVotes + gowsiVotes + abdulVotes;

            document.getElementById('pooja-votes').textContent = poojaVotes;
            document.getElementById('john-votes').textContent = johnVotes;
            document.getElementById('vice-total-votes').textContent = poojaVotes + johnVotes;
        }

        updateTally(15, 20, 10, 25, 12);
    </script>
</body>
</html>
<?php
$servername = "localhost"; // Change if your database server is different
$username = "root";         // Change as per your database login
$password = "";             // Change as per your database login
$dbname = "project";        // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errorMessage = ""; // Initialize an empty error message variable

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $regno = $_POST['regno'];
    $name = $_POST['name'];
    $dept_name = $_POST['dept_name'];
    
    // Check if registration number starts with 22, 21, or 20
    if (!preg_match('/^(22|21|20)\d*/', $regno)) {
        $errorMessage = "It is not a valid register number.";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO register (regno, name, dept_name) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $regno, $name, $dept_name); // 'sss' means all three are strings

        if ($stmt->execute()) {
            // Redirect to main.php
            echo '<script>
                alert("Registration Successful!");
                window.location.href="main.php";
            </script>';
            exit();
        } else {
            $errorMessage = "Error: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: url('reg.jpg') no-repeat center center fixed;
            background-size: cover;
            margin: 0;
            padding: 20px;
            color: #fff;
        }
        form {
            max-width: 400px;
            margin: auto;
            padding: 25px;
            background: rgba(0, 0, 0, 0.7);
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            position: relative; /* To provide positioning context for icons */
        }
        h2 {
            text-align: center;
            color: #fff;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 15px 0 5px; /* Added margin for spacing */
            font-size: 14px;
            color: #f7f7f7; /* Light color for labels */
        }
        input[type="text"], select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s;
            background-color: rgba(255, 255, 255, 0.9); /* Light background */
            font-size: 16px; /* Increased font size for better readability */
        }
        input[type="text"]:focus, select:focus {
            border-color: #4CAF50;
            outline: none;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s, transform 0.3s;
            width: 100%; /* Full width */
            margin-top: 10px; /* Added margin on top */
        }
        input[type="submit"]:hover {
            background-color: #218838;
            transform: translateY(-1px);
        }
        .alert {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-top: 10px; /* Added margin for spacing */
        }
    </style>
</head>
<body>

<h2>Registration Form</h2>
<?php if (!empty($errorMessage)) : ?>
    <div class="alert"><?php echo $errorMessage; ?></div>
<?php endif; ?>
<form method="post" action="" onsubmit="return validateForm();">
    <label for="regno">Registration Number:</label>
    <input type="text" id="regno" name="regno" required maxlength="8">

    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>

    <label for="dept_name">Department:</label>
    <select id="dept_name" name="dept_name" required>
        <option value="">Select Department</option>
        <option value="Dept of Tamil">Dept of Tamil</option>
        <option value="Dept of English">Dept of English</option>
        <option value="Dept of Maths">Dept of Maths</option>
        <option value="Dept of Computer application">Dept of Computer Application</option>
        <option value="Dept of Computer Science">Dept of Computer Science</option>
        <option value="Dept of Physics">Dept of Physics</option>
        <option value="Dept of Chemistry">Dept of Chemistry</option>
        <option value="Dept of Zoology">Dept of Zoology</option>
        <option value="Dept of Visual Communication">Dept of Visual Communication</option>
        <option value="Dept of Data Science">Dept of Data Science</option>
    </select>

    <input type="submit" value="Register">
</form>

<script>
    function validateForm() {
        const regno = document.getElementById("regno").value;
        if (!/^(22|21|20)\d*/.test(regno)) {
            alert("It is not a valid registration number.");
            return false;
        }
        return true;
    }
</script>
</body>
</html>
<?php
// Database credentials
$host = 'localhost'; 
$db_user = 'root';   
$db_pass = '';   
$db_name = 'project';    

// Database Connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetching the votes count per candidate based on their position
$sql = "SELECT position, candidate_name, COUNT(*) as vote_count FROM votes GROUP BY position, candidate_name";
$result = $mysqli->query($sql);

$data = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $data[$row['position']][$row['candidate_name']] = $row['vote_count'];
    }
}

$mysqli->close();
header('Content-Type: application/json');
echo json_encode($data);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Results Graph</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: auto;
        }

        canvas {
            background-color: white;
            border: 1px solid #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Voting Results by Candidate</h1>
        <canvas id="votingChart"></canvas>
    </div>
    <script>
        // Function to fetch the voting data from the server
        async function fetchVotingResults() {
            const response = await fetch('fetch_results.php');
            const data = await response.json();
            return data;
        }

        // Function to create the chart
        async function createChart() {
            const votingData = await fetchVotingResults();
            const ctx = document.getElementById('votingChart').getContext('2d');
        
            // Prepare chart data
            const labels = [];
            const datasets = [];
            const positions = Object.keys(votingData);

            positions.forEach(position => {
                const candidates = votingData[position];
                labels.push(...Object.keys(candidates));
                const voteCounts = Object.values(candidates);
                
                datasets.push({
                    label: position,
                    data: voteCounts,
                    backgroundColor: `rgba(${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, ${Math.floor(Math.random() * 255)}, 0.5)`,
                    borderColor: `rgba(0, 0, 0, 1)`,
                    borderWidth: 1,
                });
            });

            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: datasets
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Votes'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Candidates'
                            }
                        }
                    },
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top'
                        },
                        title: {
                            display: true,
                            text: 'Voting Results'
                        }
                    }
                }
            });
        }

        document.addEventListener('DOMContentLoaded', createChart);
    </script>
</body>
</html>
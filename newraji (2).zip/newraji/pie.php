<?php
session_start();

// Database credentials
$host = 'localhost';  // Hostname
$db_user = 'root'; // Your database username
$db_pass = 'suba'; // Your database password
$db_name = 'project'; // Your database name

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch voting results
$sql = "SELECT position, name, COUNT(*) AS votes FROM viewvotes GROUP BY position, name ORDER BY position";
$result = $mysqli->query($sql);

if (!$result) {
    die("Error fetching results: " . $mysqli->error);
}

// Prepare data for the chart
$positions = [];
$votes = [];

while ($row = $result->fetch_assoc()) {
    $positions[] = $row['name'];
    $votes[] = (int) $row['votes'];
}

$positions_json = json_encode($positions);
$votes_json = json_encode($votes);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Results</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    /* General page styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    /* Styling for individual candidate boxes */
    .candidate-box {
        display: flex;
        flex-direction: column;
        padding: 15px;
        margin: 10px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .candidate-box:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    /* Styling for each section (Position, Name, Votes) */
    .candidate-box h3 {
        margin: 0;
        color: #333;
        font-size: 1.2em;
    }

    .candidate-box p {
        margin: 5px 0;
        font-size: 1em;
        color: #555;
    }

    /* Styling for the pie chart container */
    .chart-container {
        width: 60%;
        margin: 30px auto;
    }

    /* Add some spacing for the container */
    .container {
        margin-top: 50px;
    }
</style>
<body>
    <div class="container">
        <h1>Voting Results</h1>
        
        <div class="candidate-results">
            <?php
            if ($result->num_rows > 0) {
                // Loop through the results and display them in individual boxes
                while ($row = $result->fetch_assoc()) {
                    // Add CSS class based on the position
                    $positionClass = strtolower(str_replace(' ', '-', $row['position']));
                    echo "<div class='candidate-box $positionClass'>
                            <h3>{$row['position']}</h3>
                            <p class='candidate-name'>{$row['name']}</p>
                            <p>Votes: {$row['votes']}</p>
                          </div>";
                }
            } else {
                echo "<p>No results found</p>";
            }
            ?>
        </div>

        <!-- Pie Chart Container -->
        <div class="chart-container">
            <canvas id="pieChart"></canvas>
        </div>
    </div>

    <script>
        // Fetch the data from PHP and pass it to JavaScript
        var positions = <?php echo $positions_json; ?>;
        var votes = <?php echo $votes_json; ?>;

        // Create the pie chart using Chart.js
        var ctx = document.getElementById('pieChart').getContext('2d');
        var pieChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: positions,  // Candidate names
                datasets: [{
                    data: votes,  // Votes data
                    backgroundColor: ['#FF5733', '#33FF57', '#3357FF', '#F1C40F', '#9B59B6', '#1F77B4'],
                    borderColor: '#fff',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return tooltipItem.label + ': ' + tooltipItem.raw + ' votes';
                            }
                        }
                    }
                }
            }
        });
    </script>

    <?php
    // Close the database connection
    $mysqli->close();
    ?>
</body>
</html>

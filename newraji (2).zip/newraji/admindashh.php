<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>               
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('.jpg'); /* Add your image URL */
            background-size: cover; /* Ensures the image covers the entire background */
            background-repeat: no-repeat; /* Prevents repeating the image */
            background-position: center; /* Centers the image */
            color: white;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            background-color: rgba(30, 30, 30, 0.8); /* Slightly transparent for visual effect */
            padding: 20px;
        }
        .profile {
            text-align: center;
            padding-bottom: 20px;
            border-bottom: 1px solid #444;
        }
        .profile img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .profile p {
            margin: 0;
            font-size: 14px;
        }
        .online-status {
            color: limegreen;
            font-size: 12px;
        }
        .nav-item a {
            text-decoration: none;
            color: white;
            display: flex;
            align-items: center;
            padding: 10px;
            transition: 0.3s;
            cursor: pointer;
        }
        .nav-item a:hover {
            background-color: #333;
            border-radius: 5px;
        }
        .nav-item i {
            margin-right: 10px;
        }
        #main-content {
            transition: opacity 0.3s ease-in-out;
        }
        .nav-item a.active {
            background-color: #444;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<div class="d-flex">
    <div class="sidebar">
        <div class="profile">
            <p><strong>Admin</strong></p>
            <span class="online-status">● Online</span>
        </div>

        <ul class="nav flex-column mt-3">
            <li class="nav-item">
                <a onclick="loadContent('dashboard')"><i class="bi bi-speedometer2"></i> Dashboard</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('votes')"><i class="bi bi-lock"></i> Votes</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('manage_candidates')"><i class="bi bi-person-lines-fill"></i> Manage Candidates</a>
            </li>
            <hr>
            <li class="nav-item">
                <a onclick="loadContent('voters')"><i class="bi bi-people"></i> Voters</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('positions')"><i class="bi bi-list-task"></i> Positions</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('candidates')"><i class="bi bi-person"></i> Candidates</a>
            </li>
            <hr>
            <li class="nav-item">
                <a onclick="loadContent('profile')"><i class="bi bi-person-circle"></i> Admin Profile</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('password')"><i class="bi bi-key"></i> Change Password</a>
            </li>
             <li class="nav-item">
                <a onclick="loadContent('report')"><i class="bi bi-file-earmark-bar-graph"></i> Report</a>
            </li>
            <li class="nav-item">
                <a onclick="loadContent('logout')"><i class="bi bi-box-arrow-right"></i> Logout</a>
            </li>
           
        </ul>
    </div>

    <div class="p-4 flex-grow-1">
        <div id="main-content">
            <h2>Welcome to the Admin Dashboard</h2>
            <p>Manage voters, candidates, and elections from here.</p>
        </div>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">

<script>
    async function loadContent(section) {
        let pages = {
            "dashboard": "votersvoted.php",
            "votes": "votes.php",
            "manage_candidates": "manage_candidates.php",
            "voters": "voters.php",
            "positions": "positions.php",
            "candidates": "candidates.php",
            "ballot": "ballot.php",
            "profile": "profile.php",
            "password": "change-password.php",
            "report" : "report.php"
        };

        let contentDiv = document.getElementById("main-content");
        contentDiv.style.opacity = "0";
        
        setTimeout(async () => {
            if (pages[section].endsWith(".php")) {
                try {
                    let response = await fetch(pages[section]);
                    let data = await response.text();
                    contentDiv.innerHTML = data;
                } catch (error) {
                    console.error("Error loading content:", error);
                    contentDiv.innerHTML = `<h2>Error loading page. Please try again.</h2>`;
                }
            } else {
                contentDiv.innerHTML = `<h2>${section.replace(/_/g, " ")}</h2><p>Feature under development.</p>`;
            }

            contentDiv.style.opacity = "1";
        }, 300);

        document.querySelectorAll(".nav-item a").forEach(link => link.classList.remove("active"));
        document.querySelector(`[onclick="loadContent('${section}')"]`).classList.add("active");
    }
</script>

</body>
</html>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2025 at 10:03 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `id` int(11) NOT NULL,
  `position` varchar(25) DEFAULT NULL,
  `name` varchar(25) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `picture` varchar(25) DEFAULT NULL,
  `votes` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`id`, `position`, `name`, `year`, `picture`, `votes`) VALUES
(1, 'Chairman', 'Tamil', '3rd Year', 'person1.jpg', 1),
(2, 'Chairman', 'Gowsi', '2nd Year', 'person3.jpg', 1),
(3, 'Chairman', 'Abdul', '3rd Year', 'person2.png', 3),
(4, 'Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg', 0),
(5, 'Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg', 0),
(6, 'Secretary', 'Kumar', '3rd Year', 'person7.jpg', 1),
(7, 'Secretary', 'Vikas', '2nd Year', 'person6.jpg', 4),
(8, 'Joint Secretary', 'Raji', '3rd Year', 'raji.png', 0),
(9, 'Joint Secretary', 'Anu', '3rd Year', 'person9.jfif', 0),
(10, 'President', 'Arun', '3rd Year', 'per10.jpg', 2),
(11, 'President', 'Kavin', '2nd Year', 'person11.jpg', 3),
(12, 'Vice President', 'Manju', '2nd Year', 'women.avif', 0),
(13, 'Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg', 0),
(14, 'Sports Secretary', 'Alex', '3rd Year', 'person13.avif', 0),
(15, 'Sports Secretary', 'Siva', '3rd Year', 'person14.jpg', 0),
(16, 'Sports Secretary', 'Abinash', '2nd Year', 'person15.avif', 0);

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `year` varchar(10) DEFAULT NULL,
  `picture` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`position`, `name`, `year`, `picture`) VALUES
('Chairman', 'Tamil', '3rd Year', 0x706572736f6e312e6a7067),
('Chairman', 'Gowsi', '2nd Year', 0x706572736f6e332e6a7067),
('Chairman', 'Abdul', '3rd Year', 0x706572736f6e322e706e67),
('Vice Chairman', 'Jeeva', '3rd Year', 0x706572736f6e352e6a7067),
('Vice Chairman', 'Kiruba', '3rd Year', 0x706572736f6e342e6a7067),
('Secretary', 'Kumar', '3rd Year', 0x706572736f6e372e6a7067),
('Secretary', 'Vikas', '2nd Year', 0x706572736f6e362e6a7067),
('Joint Secretary', 'Raji', '3rd Year', 0x72616a692e706e67),
('Joint Secretary', 'Anu', '3rd Year', 0x706572736f6e392e6a666966),
('President', 'Arun', '3rd Year', 0x70657231302e6a7067),
('President', 'Kavin', '2nd Year', 0x706572736f6e31312e6a7067),
('Vice President', 'Manju', '2nd Year', 0x776f6d656e2e61766966),
('Union Advisor', 'Saravanan', '3rd Year', 0x706572736f6e31322e6a7067),
('Sports Secretary', 'Alex', '3rd Year', 0x706572736f6e31332e61766966),
('Sports Secretary', 'Siva', '3rd Year', 0x706572736f6e31342e6a7067),
('Sports Secretary', 'Abinash', '2nd Year', 0x706572736f6e31352e61766966),
('Chairman', 'Tamil', '3rd Year', 0x706572736f6e312e6a7067),
('Chairman', 'Gowsi', '2nd Year', 0x706572736f6e332e6a7067),
('Chairman', 'Abdul', '3rd Year', 0x706572736f6e322e706e67),
('Vice Chairman', 'Jeeva', '3rd Year', 0x706572736f6e352e6a7067),
('Vice Chairman', 'Kiruba', '3rd Year', 0x706572736f6e342e6a7067),
('Secretary', 'Kumar', '3rd Year', 0x706572736f6e372e6a7067),
('Secretary', 'Vikas', '2nd Year', 0x706572736f6e362e6a7067),
('Joint Secretary', 'Raji', '3rd Year', 0x72616a692e706e67),
('Joint Secretary', 'Anu', '3rd Year', 0x706572736f6e392e6a666966),
('President', 'Arun', '3rd Year', 0x70657231302e6a7067),
('President', 'Kavin', '2nd Year', 0x706572736f6e31312e6a7067),
('Vice President', 'Manju', '2nd Year', 0x776f6d656e2e61766966),
('Union Advisor', 'Saravanan', '3rd Year', 0x706572736f6e31322e6a7067),
('Sports Secretary', 'Alex', '3rd Year', 0x706572736f6e31332e61766966),
('Sports Secretary', 'Siva', '3rd Year', 0x706572736f6e31342e6a7067),
('Sports Secretary', 'Abinash', '2nd Year', 0x706572736f6e31352e61766966),
('Chairman', 'Tamil', '3rd Year', 0x706572736f6e312e6a7067),
('Chairman', 'Gowsi', '2nd Year', 0x706572736f6e332e6a7067),
('Chairman', 'Abdul', '3rd Year', 0x706572736f6e322e706e67),
('Vice Chairman', 'Jeeva', '3rd Year', 0x706572736f6e352e6a7067),
('Vice Chairman', 'Kiruba', '3rd Year', 0x706572736f6e342e6a7067),
('Secretary', 'Kumar', '3rd Year', 0x706572736f6e372e6a7067),
('Secretary', 'Vikas', '2nd Year', 0x706572736f6e362e6a7067),
('Joint Secretary', 'Raji', '3rd Year', 0x72616a692e706e67),
('Joint Secretary', 'Anu', '3rd Year', 0x706572736f6e392e6a666966),
('President', 'Arun', '3rd Year', 0x70657231302e6a7067),
('President', 'Kavin', '2nd Year', 0x706572736f6e31312e6a7067),
('Vice President', 'Manju', '2nd Year', 0x776f6d656e2e61766966),
('Union Advisor', 'Saravanan', '3rd Year', 0x706572736f6e31322e6a7067),
('Sports Secretary', 'Alex', '3rd Year', 0x706572736f6e31332e61766966),
('Sports Secretary', 'Siva', '3rd Year', 0x706572736f6e31342e6a7067),
('Sports Secretary', 'Abinash', '2nd Year', 0x706572736f6e31352e61766966),
('Chairman', 'Tamil', '3rd Year', 0x706572736f6e312e6a7067),
('Chairman', 'Gowsi', '2nd Year', 0x706572736f6e332e6a7067),
('Chairman', 'Abdul', '3rd Year', 0x706572736f6e322e706e67),
('Vice Chairman', 'Jeeva', '3rd Year', 0x706572736f6e352e6a7067),
('Vice Chairman', 'Kiruba', '3rd Year', 0x706572736f6e342e6a7067),
('Secretary', 'Kumar', '3rd Year', 0x706572736f6e372e6a7067),
('Secretary', 'Vikas', '2nd Year', 0x706572736f6e362e6a7067),
('Joint Secretary', 'Raji', '3rd Year', 0x72616a692e706e67),
('Joint Secretary', 'Anu', '3rd Year', 0x706572736f6e392e6a666966),
('President', 'Arun', '3rd Year', 0x70657231302e6a7067),
('President', 'Kavin', '2nd Year', 0x706572736f6e31312e6a7067),
('Vice President', 'Manju', '2nd Year', 0x776f6d656e2e61766966),
('Union Advisor', 'Saravanan', '3rd Year', 0x706572736f6e31322e6a7067),
('Sports Secretary', 'Alex', '3rd Year', 0x706572736f6e31332e61766966),
('Sports Secretary', 'Siva', '3rd Year', 0x706572736f6e31342e6a7067),
('Sports Secretary', 'Abinash', '2nd Year', 0x706572736f6e31352e61766966);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('raji', 'raji'),
('divya', 'divya');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `position_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_name`) VALUES
('Chairman'),
('Vice Chairman'),
('Secretary'),
('Joint Secretary'),
('President'),
('Vice President'),
('Union Advisor'),
('Sports Secretary');

-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE `pro` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `profile_pic` varchar(25) DEFAULT 'profile.jpeg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pro`
--

INSERT INTO `pro` (`id`, `name`, `email`, `description`, `profile_pic`) VALUES
(1, 'Mukil', 'Mukil@gmail.com', 'An online college voting system administrator manages the digital platform that facilitates student participation in elections, ensuring secure and user-friendly access for all voters. Responsibilities include configuring voting software, troubleshooting technical issues, and overseeing the integrity of the election process. The admin also collects and analyzes voting data to provide insights and reports on election outcomes.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `regno` varchar(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dept_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`regno`, `name`, `dept_name`) VALUES
('22UCA531', 'raji', 'Dept of Computer application'),
('22UCA531', 'raji', 'Dept of Computer application'),
('21UVCA31', 'Mariya', 'Dept of Visual Communication'),
('20UTA534', 'geetha', 'Dept of Tamil'),
('22UCA531', 'keerthana', 'Dept of Computer application');

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `voter_id` int(11) DEFAULT NULL,
  `position` varchar(25) DEFAULT NULL,
  `candidate_name` varchar(25) DEFAULT NULL,
  `vote_count` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `votes`
--

INSERT INTO `votes` (`id`, `voter_id`, `position`, `candidate_name`, `vote_count`) VALUES
(1, 0, 'Chairman', 'Gowsi', 1),
(2, 0, 'Vice_Chairman', 'Kiruba', 1),
(3, 0, 'Secretary', 'Vikas', 1),
(4, 0, 'Joint_Secretary', 'Anu', 1),
(5, 0, 'President', 'Kavin', 1),
(6, 0, 'Vice_President', 'Manju', 1),
(7, 0, 'Union_Advisor', 'Saravanan', 1),
(8, 0, 'Sports_Secretary', 'Abinash', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `voter_id` (`voter_id`,`position`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `pro`
--
ALTER TABLE `pro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - College Voting System</title>
</head>
<style>
    /* Reset & General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Arial', sans-serif;
}

body {
    background-color: #E6E6FA;
    color: #333;
}

/* Navigation Bar */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20px 50px;
    background: #9370DB;
    color: white;
}

.logo {
    font-size: 22px;
    font-weight: bold;
}

nav ul {
    display: flex;
    list-style: none;
}

nav ul li {
    margin: 0 15px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
    padding: 8px 12px;
}

nav ul li a:hover, .active {
    background: #BA55D3;
    border-radius: 5px;
}

/* About Section */
.about-section {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 60px;
    background: white;
    border-radius: 10px;
    margin: 50px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
}

.about-content {
    max-width: 50%;
    padding-right: 40px;
}

.about-content h1 {
    color: #6A5ACD;
    font-size: 2.5rem;
}

.about-content p {
    margin-top: 10px;
    font-size: 1.1rem;
    color: #555;
}

.about-content h2 {
    margin-top: 20px;
    color: #8A2BE2;
}

.about-content ul {
    margin-top: 10px;
    list-style: none;
}

.about-content ul li {
    font-size: 1rem;
    margin-bottom: 5px;
}

.about-image img {
    width: 350px;
    border-radius: 10px;
}

/* Footer */
footer {
    text-align: center;
    padding: 20px;
    background: #9370DB;
    color: white;
    margin-top: 50px;
}

</style>
<body>

    <!-- Navigation Bar -->
   

    <!-- About Us Section -->
    <section class="about-section">
        <div class="about-content">
            <h1>About Our College Voting System</h1>
            <p>
                Welcome to the Online College Voting System, a secure and transparent platform designed to facilitate student elections with ease. 
                Our system ensures fairness, security, and accessibility, allowing students to cast their votes seamlessly.
            </p>
            <h2>Why Choose Our System?</h2>
            <ul>
                <li>🗳️ Secure & Transparent Voting</li>
                <li>📊 Real-Time Election Results</li>
                <li>📢 Easy Candidate Registration</li>
                <li>🎓 Designed for College Elections</li>
            </ul>
        </div>
        <div class="about-image">
            <img src="illu.jpeg" alt="Voting Illustration">
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2025 College Voting System. All Rights Reserved.</p>
    </footer>

</body>
</html>

<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch candidates data from the database (for displaying the form)
$sql = "SELECT position, name, year, picture FROM candidates";
$result = $conn->query($sql);

$candidates = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $candidates[$row['position']][] = $row;
    }
} else {
    echo "No candidates found in the database.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vote for Candidates</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .form-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 0 auto;
            max-width: 900px;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .position-section {
            width: 100%;
            margin-bottom: 20px;
            text-align: center;
        }

        .candidates-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 15px;
        }

        .candidate {
            border: 1px solid #ddd;
            padding: 15px;
            background-color: #fff;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 200px;
            text-align: center;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .candidate:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .candidate img {
            max-width: 100%;
            height: 120px;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        input[type="radio"] {
            margin-top: 10px;
            transform: scale(1.2);
        }

        button {
            margin: 20px auto;
            padding: 12px 25px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .candidate {
                width: 90%;
            }
        }
    </style>
</head>
<body>

    <h1>Vote for Your Candidates</h1>

    <form action="process_vote.php" method="POST" class="form-container">
        <?php if (!empty($candidates)): ?>
            <?php foreach ($candidates as $position => $candidatesList): ?>
                <div class="position-section">
                    <h2><?= $position ?></h2>
                    <div class="candidates-container">
                        <?php foreach ($candidatesList as $candidate): ?>
                            <label class="candidate">
                                <img src="<?= $candidate['picture'] ?>" alt="<?= $candidate['name'] ?>">
                                <p><?= $candidate['name'] ?> - <?= $candidate['year'] ?></p>
                                <input type="radio" name="<?= $position ?>" value="<?= $candidate['name'] ?>" required>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>

            <button type="submit" name="submit">Submit Vote</button>
        <?php else: ?>
            <p>No candidates available for voting.</p>
        <?php endif; ?>
    </form>

</body>
</html>
<?php
// Database connection details (replace with your values)
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro"; // Changed database name to 'pro'

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// CRUD operations for 'votee' table (position, name, year, picture)

// Initialize variables
$id = isset($_GET['id']) ? $_GET['id'] : null;
$position = "";
$name = "";
$year = "";
$picture = "";
$message = "";

// Fetch votee data for editing
if ($id && isset($_GET['action']) && $_GET['action'] == 'edit') {
    $sql = "SELECT * FROM votee WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $position = $row['position'];
        $name = $row['name'];
        $year = $row['year'];
        $picture = $row['picture'];
    } else {
        $message = "Votee not found.";
    }
    $stmt->close();
}

// Handle form submission (edit)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_candidate'])) {
    $id = $_POST['id'];
    $position = $_POST['position'];
    $name = $_POST['name'];
    $year = $_POST['year'];
    $existing_picture = $_POST['existing_picture'];
    $picture = $existing_picture; // Default to existing picture

    if (isset($_FILES["picture"]) && $_FILES["picture"]["error"] == 0) {
        $file_tmp = $_FILES["picture"]["tmp_name"];
        $file_type = mime_content_type($file_tmp);
        $allowed_types = ["image/jpeg", "image/png", "image/gif"];

        if (in_array($file_type, $allowed_types)) {
            $file_name = uniqid() . "." . pathinfo($_FILES["picture"]["name"], PATHINFO_EXTENSION);
            $target_file = "uploads/" . $file_name;

            if (move_uploaded_file($file_tmp, $target_file)) {
                // Delete the old picture if a new one was uploaded
                if (!empty($existing_picture) && file_exists("uploads/" . $existing_picture)) {
                    unlink("uploads/" . $existing_picture);
                }
                $picture = $file_name;
            } else {
                $message = "Upload failed.";
            }
        } else {
            $message = "Invalid image type.";
        }
    }

    $sql = "UPDATE votee SET position = ?, name = ?, year = ?, picture = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $position, $name, $year, $picture, $id);

    if ($stmt->execute()) {
        $message = "Candidate updated successfully.";
    } else {
        $message = "Error updating candidate: " . $stmt->error;
    }
    $stmt->close();
    // Clear the ID to hide the edit form after submission
    $id = null;
}

// Handle delete operation
if ($id && isset($_GET['action']) && $_GET['action'] == 'delete') {
    $sql_select_picture = "SELECT picture FROM votee WHERE id = ?";
    $stmt_select = $conn->prepare($sql_select_picture);
    $stmt_select->bind_param("i", $id);
    $stmt_select->execute();
    $result_picture = $stmt_select->get_result();
    if ($row_picture = $result_picture->fetch_assoc()) {
        $picture_to_delete = $row_picture['picture'];
    }
    $stmt_select->close();

    $sql_delete = "DELETE FROM votee WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $id);
    if ($stmt_delete->execute()) {
        $message = "Candidate deleted successfully.";
        // Delete the picture file
        if (!empty($picture_to_delete) && file_exists("uploads/" . $picture_to_delete)) {
            unlink("uploads/" . $picture_to_delete);
        }
    } else {
        $message = "Error deleting candidate: " . $stmt_delete->error;
    }
    $stmt_delete->close();
    //Clear the ID so edit form wont show
    $id = null;
}

// Fetch all votees for display
$sql = "SELECT * FROM votee";
$result = $conn->query($sql);
$votees = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $votees[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Candidate Management</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f4f4f4;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h2 {
            text-align: center;
            color: #555;
            margin-bottom: 20px;
        }

        h3 {
            margin-top: 30px;
            color: #555;
        }

        table {
            width: 80%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #563d7c;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f0f0f0;
        }

        img {
            max-width: 50px;
            height: auto;
            display: block;
            margin: 0 auto;
            border-radius: 50%;
            object-fit: cover;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="text"], input[type="number"], input[type="file"], button {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0056b3;
        }

        .edit-btn {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }

        .edit-btn:hover {
            background-color: #0056b3;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        .actions {
            display: flex;
            gap: 5px;
            justify-content: center;
        }

        .header {
            background-color: #563d7c;
            color: white;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 8px 8px 0 0;
            width: 80%;
        }

        .header h2 {
            margin: 0;
            color: white;
        }

        .container {
            width: 80%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
            text-align: center;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .edit-form {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            margin-bottom: 20px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.05);
            text-align: center;
            width: 80%;
        }

        .edit-form h3 {
            margin-top: 0;
            color: #555;
        }

        .add-new-button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 1em;
            margin-bottom: 15px;
            transition: background-color 0.3s ease;
        }

        .add-new-button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>CANDIDATE MANAGEMENT</h2>
        </div>

        <?php if (!empty($message)) echo "<p class='message " . (strpos($message, "successfully") !== false ? "success" : "error") . "'>$message</p>"; ?>

    

        <h3>Candidate List</h3>
        <table>
            <thead>
                <tr>
                    <th>Position</th>
                    <th>Name</th>
                    <th>Year</th>
                    <th>Picture</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($votees as $votee): ?>
                    <tr>
                        <td><?php echo $votee['position']; ?></td>
                        <td><?php echo $votee['name']; ?></td>
                        <td><?php echo $votee['year']; ?></td>
                        <td><img src="uploads/<?php echo $votee['picture']; ?>" alt="<?php echo $votee['name']; ?>"></td>
                        <td class="actions">
                            <a href="?action=edit&id=<?php echo $votee['id']; ?>" class="edit-btn">Edit</a>
                            <a href="?action=delete&id=<?php echo $votee['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($votees)): ?>
                    <tr><td colspan="5" style="text-align: center;">No candidates found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <?php if ($id && isset($_GET['action']) && $_GET['action'] == 'edit'): ?>
            <div class="edit-form">
                <h3>Edit Candidate</h3>
                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="existing_picture" value="<?php echo $picture; ?>">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="text" name="position" value="<?php echo $position; ?>" placeholder="Position" required><br>
                    <input type="text" name="name" value="<?php echo $name; ?>" placeholder="Name" required><br>
                    <input type="number" name="year" value="<?php echo $year; ?>" placeholder="Year" required><br>
                    <img src="uploads/<?php echo $picture; ?>" alt="<?php echo $name; ?>" style="max-width: 100px; margin-bottom: 10px; border-radius: 50%; object-fit: cover;"><br>
                    <label for="picture">Upload New Picture (optional):</label>
                    <input type="file" name="picture" id="picture" accept="image/*"><br>
                    <button type="submit" name="update_candidate">Update Candidate</button>
                    <a href="<?php echo $_SERVER['PHP_SELF']; ?>" style="display: block; margin-top: 10px; text-decoration: none; background-color: #f44336; color: white; padding: 10px; border-radius: 4px; text-align: center;">Cancel Edit</a>
                </form>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
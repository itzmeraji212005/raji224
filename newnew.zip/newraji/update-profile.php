<?php
// Database Connection
$host = 'localhost';
$dbname = 'project';
$username = 'root';
$password = 'raji';

$conn = new mysqli($host, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch Admin Data
$sql = "SELECT name, email, description, profile_pic FROM pro WHERE id=1";
$result = $conn->query($sql);

// Error Handling: Check if query succeeded
if (!$result) {
    die("Error in SQL query: " . $conn->error);
}

// Fetch Data Safely
$admin = $result->fetch_assoc();

// Ensure $admin is not null
if (!$admin) {
    $admin = [
        'name' => '',
        'email' => '',
        'description' => '',
        'profile_pic' => ''
    ];
}

// Update Profile Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $desc = $_POST['description'] ?? '';
    $profile_picture = $admin['profile_pic'];

    // Handle Profile Picture Upload
    if (!empty($_FILES['profile_pic']['name'])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Ensure the upload directory exists
        }
        $target_file = $target_dir . basename($_FILES['profile_pic']['name']);
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file);
        $profile_picture = $target_file;
    }

    // Update Query
    $sql = "UPDATE pro SET 
        name = ?, email = ?, description = ?, profile_pic = ? 
        WHERE id = 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ssss", $name, $email, $desc, $profile_pic);
    $stmt->execute();

    // Refresh Data
    header("Location: update-profile.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Admin Profile</title>
    <style>
        body {
            background: #4A148C;
            text-align: center;
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        h2 {
            color: #4A148C;
        }
        .profile-pic {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #4A148C;
            margin-bottom: 15px;
        }
        input, textarea {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #4A148C;
            border-radius: 5px;
            background: #F3E5F5;
            color: #4A148C;
        }
        textarea {
            height: 80px;
            resize: none;
        }
        .btn {
            background: #7B1FA2;
            color: white;
            padding: 12px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: 0.3s;
            text-decoration: none;
        }
        .btn:hover {
            background: #9C27B0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Admin Profile</h2>
        <img src="<?php echo !empty($admin['profile_pic']) ? $admin['profile_pic'] : ' '; ?>" class="profile-pic">
        <form method="POST" enctype="multipart/form-data">
            <label>Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>

            <label>Description:</label>
            <textarea name="description" required><?php echo htmlspecialchars($admin['description']); ?></textarea>

            <label>Profile Picture:</label>
            <input type="file" name="profile_picture">

            <button type="submit" class="btn">Submit</button>
        </form>
    </div>
</body>
</html>

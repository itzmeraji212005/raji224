<?php
    // about.php
    $title = "About Us - Online College Voting System"; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <style>
        /* style.css */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
            margin: 0;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        h2 {
            color: #0056b3;
            margin-top: 20px;
        }

        p, ul {
            font-size: 1.1em;
            color: #555;
        }

        ul {
            list-style: disc;
            padding-left: 20px;  
        }

        ul li {
            margin: 10px 0;
        }

        a {
            color: #0056b3;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .container {
                padding: 10px;
            }
            
            h1, h2 {
                font-size: 1.5em;
            }
        }

        /* Grid layout for contact details */
        .contact-details {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px; /* Space between items */
            margin-top: 20px;
        }

        .team-member {
            background: #ffffff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s, box-shadow 0.3s; /* Animation on hover */
        }

        .team-member:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }

        .team-member img {
            width: 100px; /* Fixed width for images */
            height: 100px; /* Fixed height for images */
            border-radius: 50%;
            margin-bottom: 15px; /* Space between image and text */
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>About Us</h1>
        <p>Welcome to our Online College Voting System. We are committed to making the voting process simple, transparent, and accessible for all students.</p>
        <p>
            We understand the importance of every voice in shaping school policies and decisions. Therefore, our team has created a system that guarantees the security, accessibility, and integrity of each vote cast.
        </p>
                
        <h3>Our Goals</h3>
        <ul>
            <li>To enhance student participation in college governance.</li>
            <li>To ensure the security of the voting process.</li>
            <li>To provide a user-friendly platform for voters.</li>
            <li>To promote transparency and trust in the college election processes.</li>
        </ul>
                
        <h3>Get Involved</h3>
        <p>If you're interested in learning more about our system or have any suggestions to improve our platform, please <a href="contact.php">contact us</a>.</p>

        <h2>Our Mission</h2>
        <p>Our mission is to empower students by providing them a convenient platform to express their opinions and votes on matters affecting their college life.</p>

        <h2>Our Values</h2>
        <ul>
            <li>Transparency</li>
            <li>Integrity</li>
            <li>Engagement</li>
        </ul>

        <h2>Contact Details</h2>
        <div class="contact-details">
            <div class="team-member">
                <img src="images/member1.jpg" alt="John Doe">
                <h3>John Doe</h3>
                <h2>Developer</h2>
                <p>Email: john.doe@example.com</p>
                <p>Phone: (123) 456-7890</p>
            </div>
            <div class="team-member">
                <img src="images/member2.jpg" alt="Jane Smith">
                <h3>Jane Smith</h3>
                <h2>Leader</h2>
                <p>Email: jane.smith@example.com</p>
                <p>Phone: (098) 765-4321</p>
            </div>
            <div class="team-member">
                <img src="images/member3.jpg" alt="Bob Johnson">
                <h3>Bob Johnson</h3>
                <h2>Manager</h2>
                <p>Email: bob.johnson@example.com</p>
                <p>Phone: (555) 555-5555</p>
            </div>
        </div>
    </div>
</body>
</html>
<?php
session_start();

// Database credentials
$host = 'localhost';  // Hostname
$db_user = 'root'; // Your database username
$db_pass = 'suba'; // Your database password
$db_name = 'project'; // Your database name

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch voting results for Vice-Chairman position
$sql = "SELECT position, name, COUNT(*) AS votes FROM viewvotes WHERE position = 'Vice-Chairman' GROUP BY name ORDER BY votes DESC";
$result = $mysqli->query($sql);

if (!$result) {
    die("Error fetching results: " . $mysqli->error);
}

// Prepare data for the chart
$positions = [];
$votes = [];

while ($row = $result->fetch_assoc()) {
    $positions[] = $row['name'];
    $votes[] = (int) $row['votes'];
}

$positions_json = json_encode($positions);
$votes_json = json_encode($votes);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Voting Results</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard - Vice-Chairman Voting Results</h1>

        <!-- Display candidate results -->
        <div class="candidate-results">
            <?php
            if ($result->num_rows > 0) {
                // Loop through the results and display them in individual boxes
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='candidate-box'>
                            <h3>{$row['position']}</h3>
                            <p class='candidate-name'>{$row['name']}</p>
                            <p>Votes: {$row['votes']}</p>
                          </div>";
                }
            } else {
                echo "<p>No results found for Vice-Chairman</p>";
            }
            ?>
        </div>

        <!-- Chart container -->
        <div class="chart-container">
            <canvas id="votesChart"></canvas>
        </div>
    </div>

    <script>
        // Fetch the data from PHP and pass it to JavaScript
        var positions = <?php echo $positions_json; ?>;
        var votes = <?php echo $votes_json; ?>;

        // Create the bar chart using Chart.js
        var ctx = document.getElementById('votesChart').getContext('2d');
        var votesChart = new Chart(ctx, {
            type: 'bar',  // Type of chart (bar chart)
            data: {
                labels: positions,  // Candidate names
                datasets: [{
                    label: 'Votes',
                    data: votes,  // Votes data
                    backgroundColor: '#4CAF50',  // Bar color
                    borderColor: '#388E3C',  // Bar border color
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return 'Votes: ' + tooltipItem.raw;
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>

<?php
// Close the database connection
$mysqli->close();
?>

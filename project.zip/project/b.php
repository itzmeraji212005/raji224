<?php
session_start();

// Database credentials
$host = 'localhost';
$db_user = 'root';
$db_pass = 'raji';
$db_name = 'project';

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Process the vote
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST as $position => $name) {
        if (!empty($name)) {
            // Prepare an update statement to increase vote count
            $stmt = $mysqli->prepare("UPDATE candidate SET votes = votes + 1 WHERE position = ? AND name = ?");
            $stmt->bind_param('ss', $position, $name);
            $stmt->execute();
            $stmt->close();
        }
    }

    header('Location: results.php'); // Redirect to results
    exit;
}

// Close database connection
$mysqli->close();
?>
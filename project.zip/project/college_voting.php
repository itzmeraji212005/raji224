<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "raji";
$database = "project";

$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch voter details
$voters = $conn->query("SELECT name, dob, YEAR(CURDATE()) - YEAR(dob) AS age, has_voted FROM votes");

// Count total voters and those who voted
$total_voters = $conn->query("SELECT COUNT(*) AS total FROM votes")->fetch_assoc()['total'];
$voted_voters = $conn->query("SELECT COUNT(*) AS voted FROM votes WHERE has_voted = 1")->fetch_assoc()['voted'];
$participation_rate = ($total_voters > 0) ? round(($voted_voters / $total_voters) * 100, 2) : 0;

// Fetch candidate votes
$candidates = $conn->query("SELECT name, votes FROM candidates ORDER BY votes DESC");

// Fetch election winner
$winner = $conn->query("SELECT name FROM candidates ORDER BY votes DESC LIMIT 1")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Report - College Voting</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: auto;
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .stats {
            font-size: 18px;
            margin-top: 20px;
            padding: 10px;
            background: #28a745;
            color: white;
            border-radius: 5px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Report - Online College Voting</h2>

        <h3>Voting Statistics</h3>
        <p class="stats">Total Voters: <?php echo $total_voters; ?> | Voted: <?php echo $voted_voters; ?> | Participation: <?php echo $participation_rate; ?>%</p>

        <h3>Voter Report</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Date of Birth</th>
                <th>Age</th>
                <th>Voted</th>
            </tr>
            <?php while ($row = $voters->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['dob']; ?></td>
                    <td><?php echo $row['age']; ?></td>
                    <td><?php echo ($row['has_voted']) ? 'Yes' : 'No'; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h3>Candidate Report</h3>
        <table>
            <tr>
                <th>Candidate Name</th>
                <th>Votes Received</th>
            </tr>
            <?php while ($row = $candidates->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['votes']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h3>Election Results</h3>
        <p class="stats">Winner: <?php echo $winner ? $winner['name'] : 'No votes yet'; ?></p>
    </div>
</body>
</html>

<?php
$conn->close();
?>

<?php
    include('header.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Voting System</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            width: 80%;
            margin: auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 50px 20px;
        }
        .text-content {
            width: 40%;
        }
        h1 {
            color: #6a0dad;
        }
        h2 {
            color: #6a0dad;
            margin-top: 30px;
        }
        p {
            font-size: 18px;
            line-height: 1.6;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        li {
            font-size: 18px;
            margin: 10px 0;
            display: flex;
            align-items: center;
        }
        li::before {
            content: '\1F4DD';
            margin-right: 10px;
        }
        .image-container {
            width: 60%;
            text-align: right;
        }
        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            width: 100%;
        }
        .reference-section {
            margin-top: 50px;
            text-align: center;
        }
        .reference-list {
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        .reference-card {
            width: 200px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 10px;
            text-align: center;
            background-color: #fff;
        }
        .reference-card img {
            width: 100%;
            border-radius: 50%;
            height: 100px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="text-content">
            <h1>About Our College Voting System</h1>
            <p>Welcome to the Online College Voting System, a secure and transparent platform designed to facilitate student elections with ease. Our system ensures fairness, security, and accessibility, allowing students to cast their votes seamlessly.</p>
            <h2>Why Choose Our System?</h2>
            <ul>
                <li>🗳️ Secure & Transparent Voting</li>
                <li>📊 Real-Time Election Results</li>
                <li>📢 Easy Candidate Registration</li>
                <li>🎓 Designed for College Elections</li>
            </ul>
        </div>
        <div class="image-container">
            <img src="illuu.jpeg" alt="College Voting System Illustration">
        </div>
    </div>
  <div class="reference-section">
    <h2>Professional References</h2>
    <div class="reference-list">
        <div class="reference-card">
            <img src="prof1.avif" alt="Professional 1">
            <h3>Kathir</h3>
            <p>Election Officer</p>
            <p>📞 123-456-7890</p>
        </div>
        <div class="reference-card">
            <img src="prof2.jpg" alt="Professional 2">
            <h3>Leo</h3>
            <p>System Administrator</p>
            <p>📞 987-654-3210</p>
        </div>
        <div class="reference-card">
            <img src="person13.avif" alt="Professional 3">
            <h3>Priyanka</h3>
            <p>Voting System Analyst</p>
            <p>📞 789-123-4567</p>
        </div>
    </div>
</div>

</body>
</html>

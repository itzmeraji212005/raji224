<?php
session_start();

// Database credentials
$host = 'localhost';
$db_user = 'root';
$db_pass = 'raji';
$db_name = 'pro';

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Initialize votes if session not set
    if (!isset($_SESSION['votes'])) {
        $_SESSION['votes'] = [];
    }

    // Uncomment below line to allow only one vote per position
    // $_SESSION['votes'] = [];

    foreach ($_POST as $position => $name) {
        // Validate input
        if (!empty($name)) {
            // Sanitize user input
            $name = $mysqli->real_escape_string(htmlspecialchars($name));
            $_SESSION['votes'][$position] = $name;

            // Update vote count in the database
            $sql = "UPDATE votee SET vote_count = vote_count + 1 WHERE position = '$position' AND name = '$name'";

            if (!$mysqli->query($sql)) {
                echo "Error updating record: " . $mysqli->error;  // Handle SQL error
            }
        }
    }

    // Redirect to results page
    header('Location: voteeuh2.php');
    exit;
} else {
    // Redirect to voting form if accessed without POST request
    header('Location: voteeuh3.php');
    exit;
}

$mysqli->close(); // Close the database connection
?>
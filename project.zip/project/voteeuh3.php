<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h1 style='text-align: center;'>Voting Confirmation</h1>";
echo "<div style='text-align: center; margin: 20px;'>";

// Fetch only position and candidate name
$sql = "SELECT position, name FROM votee ORDER BY position";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1' style='margin: auto; border-collapse: collapse; width: 50%;'>";
    echo "<tr style='background-color: #4CAF50; color: white;'>
            <th style='padding: 10px; border: 1px solid black;'>Position</th>
            <th style='padding: 10px; border: 1px solid black;'>Candidate</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr style='background-color: #f2f2f2;'>
                <td style='padding: 10px; border: 1px solid black;'>" . htmlspecialchars($row['position']) . "</td>
                <td style='padding: 10px; border: 1px solid black;'>" . htmlspecialchars($row['name']) . "</td>
              </tr>";
    }
    echo "</table>";
} else {
    echo "<p>No votes found.</p>";
}

echo "</div>";

// Provide a link to go back
echo '<p style="text-align: center;"><a href="demo.php">Back</a></p>';

$conn->close(); // Close the connection
?>

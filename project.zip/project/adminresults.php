<?php
session_start();

// Database credentials
$host = 'localhost';  // Hostname
$db_user = 'root'; // Your database username
$db_pass = 'suba'; // Your database password
$db_name = 'project'; // Your database name

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch voting results
$sql = "SELECT position, name, COUNT(*) AS votes FROM viewvotes GROUP BY position, name ORDER BY position";
$result = $mysqli->query($sql);

if (!$result) {
    die("Error fetching results: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Results</title>
    <link rel="stylesheet" href="style.css">
</head>
<style>
    /* General page styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 80%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    /* Styling for individual candidate boxes */
    .candidate-box {
        display: flex;
        flex-direction: column;
        padding: 15px;
        margin: 10px;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease;
    }

    .candidate-box:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }

    /* Styling for each section (Position, Name, Votes) */
    .candidate-box h3 {
        margin: 0;
        color: #333;
        font-size: 1.2em;
    }

    .candidate-box p {
        margin: 5px 0;
        font-size: 1em;
        color: #555;
    }

    /* Colorful box styling for each position */
    .chairman {
        background-color: #f9c74f;
        border: 2px solid #f1b700;
    }

    .vice-chairman {
        background-color: #90be6d;
        border: 2px solid #78b65b;
    }

    .secretary {
        background-color: #f7a8b8;
        border: 2px solid #f03e6f;
    }

    .president {
        background-color: #f94144;
        border: 2px solid #e61f2b;
    }

    .sports-secretary {
        background-color: #277da1;
        border: 2px solid #0d5e79;
    }

    .candidate-name {
        font-weight: bold;
    }

    /* Add some spacing for the container */
    .container {
        margin-top: 50px;
    }
</style>
<body>
    <div class="container">
        <h1>Voting Results</h1>
        
        <div class="candidate-results">
            <?php
            if ($result->num_rows > 0) {
                // Loop through the results and display them in individual boxes
                while ($row = $result->fetch_assoc()) {
                    // Add CSS class based on the position
                    $positionClass = strtolower(str_replace(' ', '-', $row['position']));
                    echo "<div class='candidate-box $positionClass'>
                            <h3>{$row['position']}</h3>
                            <p class='candidate-name'>{$row['name']}</p>
                            <p>Votes: {$row['votes']}</p>
                          </div>";
                }
            } else {
                echo "<p>No results found</p>";
            }
            ?>
        </div>
    </div>

    <?php
    // Close the database connection
    $mysqli->close();
    ?>
</body>
</html>

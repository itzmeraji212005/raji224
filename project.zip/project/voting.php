<?php
$host = "localhost";
$username = "root";
$password = "raji";
$database = "pro";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to create the "voted" table
$sql = "CREATE TABLE voted (
    id INT AUTO_INCREMENT PRIMARY KEY,
    regno VARCHAR(20),
    position VARCHAR(100),
    voted_candidate VARCHAR(100)
)";

if ($conn->query($sql) === TRUE) {
    echo "Table 'voted' created successfully.";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

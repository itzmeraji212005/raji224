<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Fetch all candidates
$sql = "SELECT * FROM votee";
$stmt = $pdo->query($sql);
$votees = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: white;
            text-align: center;
            padding: 20px;
        }

        h1 {
            color: #6a0dad;
            text-transform: uppercase;
            margin-bottom: 20px;
        }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-back {
            background: white;
            color: #6a0dad;
            border: 2px solid #6a0dad;
            margin-bottom: 20px;
        }

        .btn-back:hover {
            background: #6a0dad;
            color: white;
        }

        .btn-view {
            background: #6a0dad;
            color: white;
        }

        .btn-view:hover {
            background: #8a2be2;
        }

        table {
            width: 80%;
            margin: auto;
            border-collapse: collapse;
            background: white;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: center;
            border: 1px solid black;
        }

        th {
            background-color: #6a0dad;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f3e5f5;
        }

        tr:hover {
            background-color: #e1bee7;
        }

        img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid #6a0dad;
        }
    </style>
</head>
<body>

    <!-- Back to Admin Page Button -->
    <a href="admindashh.php" class="btn btn-back">Back to Admin Page</a>

    

    <h2>All Votes</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Position</th>
                <th>Year</th>
                <th>Picture</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($votees as $votee): ?>
                <tr>
                    <td><?= $votee['id'] ?></td>
                    <td><?= $votee['name'] ?></td>
                    <td><?= $votee['position'] ?></td>
                    <td><?= $votee['year'] ?></td>
                    <td><img src="<?= $votee['picture'] ?>" alt="Picture"></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>

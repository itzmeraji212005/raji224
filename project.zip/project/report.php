<?php
// Database connection
$conn = new mysqli("localhost", "root", "raji", "pro");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM voted ORDER BY regno, position");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Voting Report</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        .report-container {
            max-width: 900px;
            margin: auto;
            background: #ffffff;
            padding: 25px 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-radius: 12px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }
        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }
        th {
            background-color: #007BFF;
            color: #fff;
            font-weight: bold;
        }
        tr:hover {
            background-color: #f1f9ff;
        }
        .no-data {
            text-align: center;
            padding: 20px;
            color: #888;
        }
            .back-btn {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background-color: #4a148c;
            color: white;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: #7e57c2;
        }
    </style>
</head>
<body>
     <a href="admindashh.php" class="back-btn">← Back to Admin Dashboard</a>
    <div class="report-container">
        <h2>Voting Report</h2>

        <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Register Number</th>
                    <th>Position</th>
                    <th>Voted Candidate</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['regno']); ?></td>
                    <td><?php echo htmlspecialchars($row['position']); ?></td>
                    <td><?php echo htmlspecialchars($row['voted_candidate']); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
            <p class="no-data">No voting records found.</p>
        <?php endif; ?>

    </div>
</body>
</html>

<?php
$conn->close();
?>

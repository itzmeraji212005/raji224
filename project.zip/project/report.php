<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to join register and votee tables
// This assumes there might be a way to link voters to their votes (e.g., through a 'votes' table)
// Since your current voting script doesn't have a direct link, this example will perform a CROSS JOIN
// to show all possible combinations of voters and candidates with their vote counts.
// In a real reporting scenario, you would likely join based on a 'votes' table.
$sql = "SELECT
            r.regno AS voter_regno,
            r.name AS voter_name,
            v.name AS candidate_name,
            v.position AS candidate_position,
            v.vote_count AS candidate_vote_count
        FROM
            register r
        CROSS JOIN
            votee v
        ORDER BY
            r.regno, v.position";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        h2 {
            color: #333;
        }
    </style>
</head>
<body>
    <h2>Voting Report</h2>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Voter Regno</th>";
        echo "<th>Voter Name</th>";
        echo "<th>Candidate Name</th>";
        echo "<th>Position</th>";
        echo "<th>Vote Count</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($row["voter_regno"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["voter_name"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["candidate_name"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["candidate_position"]) . "</td>";
            echo "<td>" . htmlspecialchars($row["candidate_vote_count"]) . "</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No data found in the tables.</p>";
    }

    $conn->close();
    ?>

</body>
</html>
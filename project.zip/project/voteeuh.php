<?php 
session_start();
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error = "";
$voted = false; // Flag to check if user has voted

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['regno'])) {
    $regno = trim($_POST['regno']);

    if (!empty($regno)) {
        // Check if regno exists
        $stmt = $conn->prepare("SELECT name FROM register WHERE regno = ?");
        $stmt->bind_param("s", $regno);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $_SESSION['regno'] = $regno;
            $_SESSION['user_name'] = $user['name'];

            // Check if the user has already voted
            $voteCheck = $conn->prepare("SELECT * FROM register WHERE regno = ?");
            $voteCheck->bind_param("s", $regno);
            $voteCheck->execute();
            $voteResult = $voteCheck->get_result();

            if ($voteResult->num_rows > 0) {
                $voted = true; // User has already voted
            }
        } else {
            $error = "Register number not found. Please try again.";
        }
    } else {
        $error = "Please enter your register number.";
    }
}

$Positions = [
    'Chairman', 'Vice Chairman', 'Secretary',
    'Joint Secretary', 'President', 'Vice President',
    'Union Advisor', 'Sports Secretary'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting System</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            background: #f9f9f9;
            color: #333;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        .container, .vote-container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.20);
            max-width: 800px;
            width: 90%;
            margin: auto;
        }
        h2, h1 {
            color: #2c3e50;
        }
        h3 {
            color: #8A2BE2;
            margin-top: 20px;
            font-size: 22px;
            border-bottom: 2px solid #8A2BE2;
            display: inline-block;
            padding-bottom: 5px;
        }

        /* Candidate Section */
        .vote-container {
            max-width: 900px;
            margin: 30px auto;
        }
        .candidate-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 10px;
            justify-content: center;
        }

        /* Candidate Card */
        .candidate-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: 0.3s ease-in-out;
            cursor: pointer;
            border: 2px solid transparent;
        }
        .candidate-card:hover {
            transform: scale(1.05);
            border-color: #8A2BE2;
        }
        .candidate-card img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
            margin-bottom: 10px;
            border: 3px solid #8A2BE2;
        }
        .candidate-card label {
            display: block;
            font-weight: bold;
            margin-top: 5px;
        }
        .radio-container {
            margin-top: 10px;
        }
        .radio-container input[type="radio"] {
            transform: scale(1.3);
        }

        /* Submit Button */
        input[type="submit"] {
            width: 100%;
            background: #8A2BE2;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s ease-in-out;
            margin-top: 20px;
        }
        input[type="submit"]:hover {
            background: #6A1BBE;
        }
    </style>
</head>
<body>
    <?php if (!isset($_SESSION['regno'])) { ?>
        <div class="container">
            <h2>Enter Your Register Number</h2>
            <form method="POST">
                <input type="text" name="regno" placeholder="Enter Register Number" required>
                <input type="submit" value="Proceed to Vote">
            </form>
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
        </div>
    <?php } elseif ($voted) { ?>
        <div class="container">
            <h2>Voting Not Allowed</h2>
            <p>You have already voted and cannot vote again.</p>
        </div>
    <?php } else { ?>
        <div class="vote-container">
            <h1>Vote for Your Candidates</h1>
            <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></p>
            <form action="vote_process.php" method="post">
                <?php foreach ($Positions as $position) { ?>
                    <h3><?php echo $position; ?>:</h3>
                    <div class="candidate-list">
                        <?php
                        $sql = "SELECT name, picture FROM votee WHERE position = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("s", $position);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<div class='candidate-card'>";
                                echo "<img src='" . htmlspecialchars($row['picture']) . "' alt='" . htmlspecialchars($row['name']) . "'>";
                                echo "<label>" . htmlspecialchars($row['name']) ."</label>";
                                echo "<div class='radio-container'>";
                                echo "<input type='radio' name='$position' value='" . htmlspecialchars($row['name']) . "' required>";
                                echo "</div>";
                                echo "</div>";
                            }
                        } else {
                            echo "<p>No candidates available for $position.</p>";
                        }
                        ?>
                    </div>
                <?php } ?>
                <input type="submit" value="Submit Votes">
            </form>
        </div>
    <?php } ?>
</body>
</html>
<?php $conn->close(); ?>

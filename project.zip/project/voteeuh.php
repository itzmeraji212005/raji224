<?php
session_start();
$conn = new mysqli("localhost", "root", "raji", "pro");

// Define positions
$Positions = [
    'Chairman', 'Vice Chairman', 'Secretary',
    'Joint Secretary', 'President', 'Vice President',
    'Union Advisor', 'Sports Secretary'
];

// Reset session
if (isset($_POST['reset'])) {
    session_unset();
    session_destroy();
    exit();
}

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['regno']) && !isset($_POST['submit_vote'])) {
    $regno = $_POST['regno'];

    $stmt = $conn->prepare("SELECT name FROM register WHERE regno = ?");
    $stmt->bind_param("s", $regno);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $voteCheck = $conn->prepare("SELECT * FROM voted WHERE regno = ?");
        $voteCheck->bind_param("s", $regno);
        $voteCheck->execute();
        $voteCheck->store_result();

        if ($voteCheck->num_rows > 0) {
            $_SESSION['already_voted'] = true;
        } else {
            $stmt->bind_result($name);
            $stmt->fetch();
            $_SESSION['regno'] = $regno;
            $_SESSION['user_name'] = $name;
            $_SESSION['voting'] = true;
        }
    } else {
        $_SESSION['error'] = "You are not authorized to vote.";
    }
}

// Handle vote submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_vote'])) {
    if (!isset($_SESSION['regno'])) {
        $_SESSION['error'] = "Session expired. Please login again.";
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    }

    $regno = $_SESSION['regno'];

    foreach ($Positions as $position) {
        $postKey = str_replace(' ', '_', $position);
        if (isset($_POST[$postKey])) {
            $candidate = $_POST[$postKey];

            // Insert into voted
            $stmt = $conn->prepare("INSERT INTO voted (regno, position, voted_candidate) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $regno, $position, $candidate);
            $stmt->execute();

            // Update vote count
            $update = $conn->prepare("UPDATE votee SET vote_count = vote_count + 1 WHERE name = ? AND position = ?");
            $update->bind_param("ss", $candidate, $position);
            $update->execute();
        }
    }

    $_SESSION['voting'] = false;
    $_SESSION['voted'] = true;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Voting System</title>
    <style>
        body { font-family: Arial; background: #f9f9f9; text-align: center; }
        .container { background: white; padding: 30px; border-radius: 10px; width: 90%; max-width: 600px; margin: auto; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .candidate-list { display: flex; flex-wrap: wrap; justify-content: center; }
        .candidate-card { margin: 10px; padding: 15px; background: #fff; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center; width: 120px; }
        .candidate-card img { width: 80px; height: 80px; border-radius: 50%; object-fit: cover; }
        input[type="submit"], button, .home-btn {
            padding: 10px 20px; background: #007BFF;
            color: white; border: none; border-radius: 5px;
            cursor: pointer; font-size: 16px; text-decoration: none;
        }
        input[type="submit"]:hover, button:hover, .home-btn:hover { background: #0056b3; }
        .error { color: red; margin-top: 10px; }
        h3 { margin-top: 20px; }
        ul { text-align: left; }
    </style>
</head>
<body>
<div class="container">

<?php if (!isset($_SESSION['voting']) && !isset($_SESSION['voted'])): ?>
    <h2>Enter Register Number to Vote</h2>
    <form method="post">
        <input type="text" name="regno" placeholder="Enter your Reg No" required>
        <input type="submit" value="Start Voting">
    </form>
    <?php if (isset($_SESSION['error'])): ?>
        <p class='error'><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></p>
    <?php endif; ?>
    <?php if (isset($_SESSION['already_voted'])): ?>
        <p class='error'>You have already voted!</p>
        <?php unset($_SESSION['already_voted']); ?>
    <?php endif; ?>

<?php elseif (isset($_SESSION['voting']) && $_SESSION['voting'] === true): ?>
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h2>
    <h3>Vote for your candidates:</h3>
    <form method="post">
        <?php foreach ($Positions as $position): ?>
            <h3><?php echo $position; ?></h3>
            <div class="candidate-list">
                <?php
                $stmt = $conn->prepare("SELECT name, picture FROM votee WHERE position = ?");
                $stmt->bind_param("s", $position);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0):
                    while ($row = $result->fetch_assoc()):
                ?>
                    <div class="candidate-card">
                        <img src="<?php echo htmlspecialchars($row['picture']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <p><?php echo htmlspecialchars($row['name']); ?></p>
                        <input type="radio" name="<?php echo str_replace(' ', '_', $position); ?>" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                    </div>
                <?php endwhile; else: ?>
                    <p>No candidates available for <?php echo $position; ?></p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        <br>
        <input type="submit" name="submit_vote" value="Submit Votes">
    </form>

<?php elseif (isset($_SESSION['voted']) && $_SESSION['voted'] === true): ?>
    <h2 style="color: darkgreen;">Vote Recorded Successfully!</h2>
    <p>You have voted for:</p>
    <div style="text-align:left; display:inline-block; font-size: 16px; font-weight: bold;">
        <ul style="list-style-type: none; padding-left: 0;">
            <?php
            $votes = [];
            $stmt = $conn->prepare("SELECT position, voted_candidate FROM voted WHERE regno = ?");
            $stmt->bind_param("s", $_SESSION['regno']);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($row = $result->fetch_assoc()) {
                $votes[$row['position']] = $row['voted_candidate'];
            }

            foreach ($Positions as $position) {
                $displayName = htmlspecialchars($position);
                $votedFor = isset($votes[$position]) ? htmlspecialchars($votes[$position]) : 'Not Voted';
                echo "<li><span style='color:black;'>$displayName:</span> <span style='color:purple;'>$votedFor</span></li>";
            }
            ?>
        </ul>
    </div>
    <br>
    <a href="demo.php" class="home-btn">Back to Home</a>
<?php endif; ?>

</div>
</body>
</html>

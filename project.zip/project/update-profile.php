<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';

$conn = new mysqli($host, $username, $password, $dbname);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch Admin Data
$sql = "SELECT name, email, profile_pic FROM pro WHERE id=1";
$result = $conn->query($sql);

// Error Handling: Check if query succeeded
if (!$result) {
    die("Error in SQL query: " . $conn->error);
}

// Fetch Data Safely
$admin = $result->fetch_assoc();

// Ensure $admin is not null
if (!$admin) {
    $admin = [
        'name' => '',
        'email' => '',
        'profile_pic' => ''
    ];
}

// Update Profile Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';

    $profile_picture = $admin['profile_pic']; // Initialize with existing value

    // Handle Profile Picture Upload
    if (!empty($_FILES['profile_picture']['name'])) {
        $target_dir = ""; // Create an 'uploads' directory in the same folder as this script
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true); // Ensure the upload directory exists
        }
        $target_file = $target_dir . basename($_FILES['profile_picture']['name']);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES['profile_picture']['tmp_name']);
        if($check === false) {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        // Check file size (adjust as needed)
        if ($_FILES['profile_picture']['size'] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $target_file)) {
                $profile_picture = $target_file; // Update profile picture path
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    // Update Query
    $sql = "UPDATE pro SET
        name = ?, email = ?, profile_pic = ?
        WHERE id = 1";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("sss", $name, $email, $profile_picture);
    $stmt->execute();

    // Refresh Data
    header("Location: profile.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Admin Profile</title>
    <style>
        body {
            background: white;
            text-align: center;
            font-family: Arial, sans-serif;
            color: white;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            width: 400px;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
            color: #4A148C;
        }
        .back-btn {
            display: inline-block;
            margin-bottom: 15px;
            padding: 10px 20px;
            background: #555;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
        }
        .back-btn:hover {
            background: #333;
        }
        h2 {
            color: #4A148C;
            margin-bottom: 20px;
        }
        .profile-pic {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #7B1FA2;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #7B1FA2;
            font-weight: bold;
            text-align: left;
        }
        input[type="text"],
        input[type="email"],
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #7B1FA2;
            border-radius: 5px;
            background: #F3E5F5;
            color: #4A148C;
            box-sizing: border-box;
        }
        .btn {
            background: #7B1FA2;
            color: white;
            padding: 12px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
            transition: 0.3s;
            text-decoration: none;
            box-sizing: border-box;
        }
        .btn:hover {
            background: #9C27B0;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="profile.php" class="back-btn">⬅ Back</a> <!-- Back Button -->

        <h2>Update Admin Profile</h2>
        <img src="<?php echo htmlspecialchars($admin['profile_pic']); ?>" alt="Profile Picture" class="profile-pic">
        
        <form method="POST" enctype="multipart/form-data">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($admin['name']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>

            <label for="profile_picture">Profile Picture:</label>
            <input type="file" id="profile_picture" name="profile_picture">

            <button type="submit" class="btn">Submit</button>
        </form>
    </div>
</body>
</html>

<?php
// Database credentials
$host = 'localhost';
$db_user = 'root';
$db_pass = 'raji';                             
$db_name = 'project';

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch top voted candidate for each position
$query = "
    SELECT c1.position, c1.name, c1.votes 
    FROM candidate c1
    WHERE c1.votes = (
        SELECT MAX(c2.votes) 
        FROM candidate c2 
        WHERE c2.position = c1.position
    )
    ORDER BY c1.position;
";

$candidates = $mysqli->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Results</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            text-align: center;
        }

        h1 {
            color: white;
            padding: 20px;
            background-color: #007bff;
            margin: 0;
        }

        /* Table Styling */
        .results-container {
            margin: 30px auto;
            width: 90%;
            max-width: 800px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        /* Button */
        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 16px;
            color: white;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .back-button:hover {
            background-color: #218838;
        }

        /* Responsive */
        @media (max-width: 600px) {
            .results-container {
                width: 95%;
            }

            table {
                font-size: 14px;
            }
        }
    </style>
</head>
<body>

    <h1>Voting Results</h1>

    <div class="results-container">
        <table>
            <tr>
                <th>Position</th>
                <th>Candidate</th>
                <th>Votes</th>
            </tr>
            <?php while ($candidate = $candidates->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($candidate['position']); ?></td>
                    <td><?php echo htmlspecialchars($candidate['name']); ?></td>
                    <td><?php echo htmlspecialchars($candidate['votes']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <a href="demo.php" class="back-button">Back to Voting</a>
    </div>

</body>
</html>

<?php
// Close database connection
$mysqli->close();
?>

<?php
$servername = "localhost"; // Change if your database server is different
$username = "root";         // Change as per your database login
$password = "";             // Change as per your database login
$dbname = "project";        // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching registered users
$sql = "SELECT username,password FROM login";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 50px;
        }
        .container {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        table {
            margin: 20px auto;
            border-collapse: collapse;
            width: 80%;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        
        
        <h3>Registered Users</h3>
        <table>
            <tr>
                
                <th>Username</th>
                <th>Password</th>
            </tr>
            <?php
            if ($result->num_rows > 0) {
                // Fetch and display user data
                while($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . htmlspecialchars($row["username"]) . "</td><td>" . htmlspecialchars($row["password"]) . "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No users found.</td></tr>";
            }
            ?>
        </table>
        
    </div>
</body>
</html>

<?php
$conn->close(); // Closing the connection
?>
<?php
// Database connection settings
$host = 'localhost';
$db = 'pro';
$user = 'root';
$pass = 'raji';

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch registration details
$sql = "SELECT regno, name, dept_name FROM register";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Registration Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            padding: 20px;
            text-align: center;
        }

        table {
            width: 60%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        h1 {
            color: #007bff;
        }
    </style>
</head>
<body>

    <h1>Registration Details</h1>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>Reg No</th>
                    <th>Name</th>
                    <th>Department</th>
                </tr>";

        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>{$row['regno']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['dept_name']}</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No registration details found.</p>";
    }

    // Close connection
    $conn->close();
    ?>

</body>
</html>

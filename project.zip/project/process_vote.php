<?php
session_start(); // Start the session

// Database connection details
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define all mandatory positions
$Positions = [
    'Chairman', 'Vice Chairman', 'Secretary', 
    'Joint Secretary', 'President', 'Vice President', 
    'Union Advisor', 'Sports Secretary'
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $voteSuccessful = true;
    $_SESSION['votes'] = []; // Initialize an array to hold votes

    // Loop through each mandatory position
    foreach ($Positions as $position) {
        if (empty(trim($_POST[$position]))) {
            echo "<p style='color: red; text-align: center;'>Error: You must select a candidate for " . htmlspecialchars($position) . ".</p>";
            $voteSuccessful = false;
            continue;
        }

        $candidateName = trim($_POST[$position]);
        // Store the vote in the session
        $_SESSION['votes'][$position] = $candidateName;

        // Sanitize input
        $sanitizedPosition = $conn->real_escape_string($position);
        $sanitizedCandidateName = $conn->real_escape_string($candidateName);

        // Retrieve candidate details (if needed)
        // You can check against your database here if the candidate exists
        $candidateDetailsSql = "SELECT year, picture FROM votee WHERE position = '$sanitizedPosition' AND name = '$sanitizedCandidateName'";
        $candidateDetailsResult = $conn->query($candidateDetailsSql);

        // Optional: You can store additional information if the candidate exists
        if ($candidateDetailsResult->num_rows == 0) {
            echo "<p style='color: red; text-align: center;'>Error: Candidate not found for " . htmlspecialchars($candidateName) . " in position " . htmlspecialchars($position) . ".</p>";
            $voteSuccessful = false;
        }
    }

    $conn->close();

    // Redirect only if all votes were successful
    if ($voteSuccessful) {
        header("Location: vote_results.php");
        exit();
    } else {
        echo '<p style="text-align: center;"><a href="javascript:history.back()">Go back to the voting form</a></p>';
    }
} else {
    // If accessed directly
    echo "<p style='color: red; text-align: center;'>Error: This page can only be accessed by submitting the voting form.</p>";
    echo '<p style="text-align: center;"><a href="vote_form.php">Go back to the voting form</a></p>';
}
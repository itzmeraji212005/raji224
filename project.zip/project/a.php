<?php
session_start();

// Database credentials
$host = 'localhost';
$db_user = 'root';
$db_pass = 'raji';                
$db_name = 'project';

// Establish database connection
$mysqli = new mysqli($host, $db_user, $db_pass, $db_name);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch candidates grouped by position
$candidates = $mysqli->query("SELECT * FROM candidate ORDER BY position");

$grouped_candidates = [];
while ($candidate = $candidates->fetch_assoc()) {
    $grouped_candidates[$candidate['position']][] = $candidate;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting System</title>
    <style>
        /* General Styling */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            text-align: center;
        }

        h1 {
            color: white;
            padding: 20px;
            margin: 0;
            background-color: #007bff;
        }

        /* Position Section */
        .position-section {
            margin: 30px auto;
            padding: 15px;
            width: 90%;
            max-width: 900px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .position-title {
            font-size: 22px;
            font-weight: bold;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 5px;
            border-bottom: 3px solid #007bff;
            text-align: left;
        }

        /* Candidate Grid */
        .candidate-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 10px;
        }

        .candidate {
            background: white;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            padding: 15px;
            width: 220px;
            text-align: center;
            transition: transform 0.2s ease-in-out;
        }

        .candidate:hover {
            transform: translateY(-5px);
        }

        .candidate-photo {
            width: 100%;
            height: 160px;
            object-fit: cover;
            border-radius: 5px;
        }

        h3 {
            margin: 10px 0 5px;
            font-size: 18px;
            color: #333;
        }

        p {
            margin: 5px 0;
            color: #666;
            font-size: 14px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        /* Form and Button */
        form {
            margin-top: 20px;
        }

        .vote-btn {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease;
            margin-top: 20px;
        }

        .vote-btn:hover {
            background-color: #218838;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .candidate-container {
                flex-direction: column;
                align-items: center;
            }

            .candidate {
                width: 80%;
            }
        }
    </style>
</head>
<body>

    <h1>Vote for Your Favorite Candidate</h1>

    <form action="b.php" method="POST">
        <?php foreach ($grouped_candidates as $position => $candidates): ?>
            <div class="position-section">
                <div class="position-title"><?php echo $position; ?></div>
                <div class="candidate-container">
                    <?php foreach ($candidates as $candidate): ?>
                        <div class="candidate">
                            <img src="<?php echo $candidate['picture']; ?>" alt="<?php echo $candidate['name']; ?>" class="candidate-photo">
                            <h3><?php echo $candidate['name']; ?></h3>
                            <p><strong>Year:</strong> <?php echo $candidate['year']; ?></p>
                            <label>
                                <input type="radio" name="<?php echo $position; ?>" value="<?php echo $candidate['name']; ?>" required>
                                Select
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
        <button type="submit" class="vote-btn">Submit Vote</button>
    </form>

</body>
</html>

<?php
// Close database connection
$mysqli->close();
?>

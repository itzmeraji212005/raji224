body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f4;
    color: #333;
}

header {
    background: #007bff;
    color: #fff;
    padding: 10px 0;
    text-align: center;
}

main {
    padding: 20px;
}

h1, h2, h3 {
    color: #333;
}

section {
    background: #fff;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

ul {
    list-style-type: disc;
    padding-left: 20px;
}

footer {
    text-align: center;
    padding: 10px 0;
    background: #007bff;
    color: #fff;
    position: relative;
    bottom: 0;
    width: 100%;
}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voters</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 20px;
        }

        h1 {
            color: #6a0dad;
            text-transform: uppercase;
        }

        .btn-view {
            display: inline-block;
            background: white;
            color: #6a0dad;
            border: 2px solid #6a0dad;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            text-decoration: none;
            font-weight: bold;
            margin-top: 20px;
        }

        .btn-view:hover {
            background: #6a0dad;
            color: white;
        }
    </style>
</head>
<body>

    <h1>View Voters</h1>

    <!-- "View Candidates" button as an anchor tag -->
    <a href="checkregister.php" class="btn-view">View Voters</a>

</body>
</html>

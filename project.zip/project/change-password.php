
<?php
session_start();
$servername = "localhost";
$username = "root"; // Change if needed
$password = "raji"; // Change if needed
$dbname = "pro"; // Change if needed

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Fetch admin password (plain text)
    $stmt = $conn->prepare("SELECT password FROM admins LIMIT 1");
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_password);
        $stmt->fetch();
        $stmt->close();

        // Check if old password matches
        if ($old_password !== $db_password) {
            echo "<script>alert('Incorrect old password!'); window.history.back();</script>";
            exit();
        }

        // Check if new passwords match
        if ($new_password !== $confirm_password) {
            echo "<script>alert('New passwords do not match!'); window.history.back();</script>";
            exit();
        }

        // Update password in database (plain text)
        $update_stmt = $conn->prepare("UPDATE admins SET password = ? LIMIT 1");
        $update_stmt->bind_param("s", $new_password);

        if ($update_stmt->execute()) {
            echo "<script>alert('Password changed successfully!'); window.location.href = 'admindashh.php';</script>";
        } else {
            echo "<script>alert('Error updating password. Try again.'); window.history.back();</script>";
        }
        $update_stmt->close();
    } else {
        echo "<script>alert('Admin user not found!'); window.history.back();</script>";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #b19cd9, #d8b9ff);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 30px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            display: flex;
            align-items: center;
            width: 600px;
        }
        .image-container img {
            width: 220px;
            height: auto;
            margin-right: 20px;
        }
        .form-container {
            flex: 1;
            text-align: center;
        }
        .form-container h2 {
            margin-bottom: 20px;
            color: #5a189a;
            font-weight: bold;
        }
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 2px solid #5a189a;
            border-radius: 6px;
            font-size: 16px;
            outline: none;
        }
        input[type="password"]:focus {
            border-color: #9d4edd;
            box-shadow: 0 0 5px rgba(157, 78, 237, 0.5);
        }
        .btn {
            width: 100%;
            background-color: #5a189a;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
            transition: background 0.3s;
        }
        .btn:hover {
            background-color: #7b2cbf;
        }
        .form-container h2, .form-container input, .form-container button[type="submit"] {
            margin-left: auto;
            margin-right: auto;
            display: block; /* Make form elements take full width of their container */
            max-width: 400px; /* Limit the width of form elements */
        }
        .form-container input[type="file"], .form-container .file-label {
            max-width: 400px;
            text-align: left; /* Align file input and label to the left */
        }
    </style>
</head>
<body>
<div class="dashboard-button-container">
        <a href="admindashh.php" class="dashboard-button">Go Back to Admin Dashboard</a>
    </div>

    <div class="container">
        <div class="image-container">
            <img src="illu.jpeg" alt="Reset Password">
        </div>
        <div class="form-container">
            <h2>Reset Password</h2>
            <form method="POST" action="">
                <input type="password" name="old_password" placeholder="Old Password" required>
                <input type="password" name="new_password" placeholder="New Password" required>
                <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                <button type="submit" class="btn">Set Password</button>
            </form>
        </div>
    </div>
</body>
</html>

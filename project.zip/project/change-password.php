<?php
session_start();
$servername = "localhost";
$username = "root"; // Change if needed
$password = "raji"; // Change if needed
$dbname = "pro"; // Change if needed

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Fetch the first admin's hashed password from the database
    $stmt = $conn->prepare("SELECT password FROM admins LIMIT 1");
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_password);
        $stmt->fetch();
        $stmt->close();

        // Verify old password with password_verify
        if (!password_verify($old_password, $db_password)) {
            echo "<script>alert('Incorrect old password!'); window.history.back();</script>";
            exit();
        }

        // Check if new passwords match
        if ($new_password !== $confirm_password) {
            echo "<script>alert('New passwords do not match!'); window.history.back();</script>";
            exit();
        }

        // Hash the new password before saving
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update_stmt = $conn->prepare("UPDATE admins SET password = ? LIMIT 1");
        $update_stmt->bind_param("s", $hashed_password);

        if ($update_stmt->execute()) {
            echo "<script>alert('Password changed successfully!'); window.location.href = 'admindashh.php';</script>";
        } else {
            echo "<script>alert('Error updating password. Try again.'); window.history.back();</script>";
        }
        $update_stmt->close();
    } else {
        echo "<script>alert('Admin user not found!'); window.history.back();</script>";
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Reset Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            display: flex;
            height: 100vh;
            background:white;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: #222;
            color: white;
            padding: 20px;
            position: fixed;
            height: 100%;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 22px;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            padding: 15px;
            border-bottom: 1px solid #444;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
        }

        .sidebar ul li a:hover {
            background: #5b1995;
            padding-left: 10px;
            transition: 0.3s;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            width: 750px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-direction: row;
        }

        h2 {
            color: #6b21a8;
            font-size: 22px;
            margin-bottom: 20px;
            font-weight: bold;
        }

        .form-container {
            width: 50%;
            padding: 20px;
        }

        .password-container {
            position: relative;
            width: 100%;
            margin-bottom: 15px;
        }

        input {
            width: 100%;
            padding: 12px;
            border: 2px solid #6b21a8;
            border-radius: 6px;
            font-size: 14px;
            outline: none;
            transition: border 0.3s ease-in-out;
        }

        input:focus {
            border-color: #5b1995;
        }

        .btn {
            width: 100%;
            padding: 12px;
            background-color: #6b21a8;
            border: none;
            border-radius: 6px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease-in-out;
        }

        .btn:hover {
            background-color: #5b1995;
        }

        .image-container {
            width: 50%;
            text-align: center;
        }

        .image-container img {
            width: 100%;
            max-width: 280px;
            border-radius: 10px;
        }

    </style>
</head>
<body>

   

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <div class="image-container">
                <img src="illu.jpeg" alt="Reset Password">
            </div>
            <div class="form-container">
                <h2>Reset Password</h2>
                <form method="POST" action="">
                    <div class="password-container">
                        <input type="password" name="old_password" placeholder="Old Password" required>
                    </div>
                    <div class="password-container">
                        <input type="password" name="new_password" placeholder="New Password" required>
                    </div>
                    <div class="password-container">
                        <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                    </div>
                    <button type="submit" class="btn">Set Password</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>

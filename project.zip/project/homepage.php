<!DOCTYPE html>
<html lang="en">
    <head>
        <meta vharset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>Student Council Election 2025</title>
        <link rel="stylesheet" href="home.css">
</head>
<body>
    <header>
<h1>St.Mary's College,Palayamkottai</h1>
<h2 style="text-align:center; color:white;">Student Council Election 2025</h2>
<nav>
    <ul>
        <li><a href="homepage.php"class="sparkle-button">HOME</a></li>
        <li><a href="candidates.php"class="sparkle-button">CANDIDATES</a></li>
        <li><a href="vote.php"class="sparkle-button">VOTE</a></li>
        <li><a href="index.php"class="sparkle-button">LOGIN</a></li>
</ul>
</nav>
</header>
</div>
</body>
</html>
        
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['picture'])) {
    $targetDir = "uploads/";
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/avif'];
    $maxFileSize = 5 * 1024 * 1024;
    $targetWidth = 250;
    $targetHeight = 250;

    if (!file_exists($targetDir) && !is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $file = $_FILES['picture'];
    $fileName = basename($file['name']);
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileType = $file['type'];
    $fileError = $file['error'];

    if ($fileError === 0) {
        if (in_array($fileType, $allowedTypes)) {
            if ($fileSize <= $maxFileSize) {
                list($width, $height) = getimagesize($fileTmpName);

                if ($width > 0 && $height > 0) {
                    $uniqueFileName = uniqid() . '_' . $fileName;
                    $targetFile = $targetDir . $uniqueFileName;

                    $resizedImage = imagecreatetruecolor($targetWidth, $targetHeight);

                    if ($fileType === 'image/jpeg' || $fileType === 'image/jpg') {
                        $sourceImage = imagecreatefromjpeg($fileTmpName);
                    } elseif ($fileType === 'image/png') {
                        $sourceImage = imagecreatefrompng($fileTmpName);
                        imagealphablending($resizedImage, false);
                        imagesavealpha($resizedImage, true);
                    } elseif ($fileType === 'image/avif') {
                        $sourceImage = imagecreatefromavif($fileTmpName);
                    } else {
                        echo "<p>Unsupported file type for resizing.</p>";
                        return;
                    }

                    imagecopyresampled($resizedImage, $sourceImage, 0, 0, 0, 0, $targetWidth, $targetHeight, $width, $height);

                    if ($fileType === 'image/jpeg' || $fileType === 'image/jpg') {
                        imagejpeg($resizedImage, $targetFile);
                    } elseif ($fileType === 'image/png') {
                        imagepng($resizedImage, $targetFile);
                    } elseif ($fileType === 'image/avif') {
                        imageavif($resizedImage, $targetFile);
                    }

                    imagedestroy($sourceImage);
                    imagedestroy($resizedImage);

                    echo "<p>File uploaded and resized successfully. File path: " . $targetFile . "</p>";

                    $imageLink = "<img src='" . $targetFile . "' alt='Uploaded Image' style='width:250px; height:250px;'>";
                    echo $imageLink;

                } else {
                    echo "<p>Invalid image dimensions.</p>";
                }
            } else {
                echo "<p>File size exceeds the allowed limit of 5MB.</p>";
            }
        } else {
            echo "<p>Invalid file type. Allowed types: JPEG, JPG, PNG, AVIF.</p>";
        }
    } else {
        echo "<p>Error during file upload. Error code: " . $fileError . "</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Voter Category</title>
    <style>
        body {
            font-family: sans-serif;
            margin: 0;
            background-image: url('dash.webp');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            display: flex;
            flex-direction: column; /* Stack elements vertically */
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        h1 {
            text-align: center;
            color: #333;
            background-color: rgba(255, 255, 255, 0.8);
            padding: 50px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        form {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        select,
        input[type="file"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        select {
            height: 40px;
        }

        button[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        button[type="submit"]:hover {
            background-color: #0056b3;
        }

        #confirmation {
            background-color: rgba(212, 237, 218, 0.9);
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            text-align: center;
            display: none;
        }

        #confirmation h2 {
            margin-top: 0;
            color: #155724;
        }

        #summary {
            margin-top: 10px;
            text-align: left;
        }

        #summary img {
            display: block;
            margin: 10px auto;
        }
    </style>
</head>
<body>
    <h1>Add New Voter Category</h1>
    <form id="voterForm" action="" method="post" enctype="multipart/form-data">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="department">Department:</label>
        <select id="department" name="department" required>
            <option value="Dept of Tamil">Dept of Tamil</option>
            <option value="Dept of English">Dept of English</option>
            <option value="Dept of Maths">Dept of Maths</option>
            <option value="Dept of Computer application">Dept of Computer application</option>
            <option value="Dept of Science">Dept of Computer Science</option>
            <option value="Dept of Physics">Dept of Physics</option>
            <option value="Dept of Chemistry">Dept of Chemistry</option>
            <option value="Dept of Zoology">Dept of Zoology</option>
            <option value="Dept of Visual Communication">Dept of Visual Communication</option>
            <option value="Dept of Data Science">Dept of Data Science</option>
        </select>
        <label for="position">Position:</label>
        <select id="position" name="position" required>
            <option value="">Select Position</option>
            <option value="Chairman">Chairman</option>
            <option value="Vice Chairman">Vice Chairman</option>
            <option value="Secretary">Secretary</option>
            <option value="Joint Secretary">Joint Secretary</option>
            <option value="President">President</option>
            <option value="Vice President">Vice President</option>
            <option value="Union Advisor">Union Advisor</option>
            <option value="Sports Secretary">Sports Secretary</option>
    </select>

    <label for="picture">Upload Picture:</label>
    <input type="file" id="picture" name="picture" accept="image/*" required>

    <button type="submit">Save</button>
</form>

<div id="confirmation" style="margin-top: 20px; display: none;">
    <h2>Voter Category Added!</h2>
    <p id="summary"></p>
</div>

<script>
    document.getElementById('voterForm').addEventListener('submit', function(event){
        event.preventDefault(); // Prevent the default form submission
        
        // Get form data
        const name = document.getElementById('name').value;
        const department = document.getElementById('department').value;
        const position = document.getElementById('position').value;

        // Fetch the uploaded file and URL (assuming you want to display this)
        const fileInput = document.getElementById('picture');
        const file = fileInput.files[0];
        const fileUrl = file ? URL.createObjectURL(file) : '';

        // Display confirmation summary
        document.getElementById('summary').innerHTML = `
            Name: ${name} <br>
            Department: ${department} <br>
            Position: ${position} <br>
            Picture: <img src="${fileUrl}" alt="Uploaded Picture" style="max-width:100px;"/>
        `;
        document.getElementById('confirmation').style.display = 'block';

        // Here you can add a function to save the data to your database or API.
        // E.g., send data to a server using fetch.
    });
</script>

</body>
</html>
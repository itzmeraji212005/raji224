<d?php
// home.php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Council Election 2025</title>
    <link rel="stylesheet" href="home1.css"> <!-- Add your CSS file if necessary -->
</head>
<body>

    <header>
        <div class="logo">
            <img src="logo.png" alt="St. Xavier's College " style="height:100px;">
        </div>
        <h1>St. Xavier's College, Palayamkottai</h1>
        <h2 style="text-align: center;">Student Council Election 2025</h2>

        <!-- Navigation Bar -->
        <nav>
            <ul>
                <li><a href="home.php">HOME</a></li>
                <li><a href="candidates.php">CANDIDATES</a></li>
                <li><a href="voterlist.php">VOTER LIST</a></li>
                <li><a href="loginhome.php">LOGIN</a></li>
            </ul>
        </nav>
        </header>
        <h2 style="text-align: center; color:black; font-size: 50px;">Student Council Election 2025</h2>
 <div class="image-container">
    
    </div>
       
        



</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username_input = $_POST['username'];
    $password_input = $_POST['password'];

    // Insert the login attempt into the table
    $stmt = $conn->prepare("INSERT INTO login (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username_input, $password_input);
    $stmt->execute();
    $stmt->close();

    // Check user credentials (Accept any credentials)
    echo '<script>
    alert("Login Successfully"); 
    window.location.href="registerform.php"; // Redirect to another page after successful login
    </script>';
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | OVS</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #f5f5f5;
        }

        .login-container {
            display: flex;
            max-width: 900px;
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .login-left {
            width: 50%;
            background: #e3f2fd;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-left img {
            width: 80%;
        }

        .login-right {
            width: 50%;
            padding: 40px;
            text-align: center;
        }

        .profile-icon {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }

        h2 {
            margin-bottom: 15px;
            color: #333;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 25px;
            outline: none;
            text-align: center;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 12px;
            background: rgb(128, 0, 128);
            border: none;
            border-radius: 25px;
            color: white;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
        }

        button:hover {
            background: white;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-left">
            <img src="login illu.avif" alt="Login Illustration">
        </div>
        <div class="login-right">
            <img src="login.png" class="profile-icon" alt="Profile Icon">
            <h2>WELCOME TO ONLINE COLLEGE VOTING SYSTEM</h2>
            <form method="POST" action="">
                <input type="text" name="username" required placeholder="Enter Username" />
                <input type="password" name="password" required placeholder="Enter Password" />
                <button type="submit">LOGIN</button>
            </form>
        </div>
    </div>
</body>
</html>
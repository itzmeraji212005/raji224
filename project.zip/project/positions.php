<?php
// Database Connection
$host = 'localhost';
$dbname = 'pro';
$username = 'root';
$password = 'raji';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// ADD New Position
$successMessage = "";
$errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_position'])) {
    $position = trim($_POST['position']);

    if (!empty($position)) {
        try {
            $sql = "INSERT INTO position (position_name) VALUES (:position)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':position' => $position]);

            $successMessage = "Position added successfully!";
        } catch (PDOException $e) {
            $errorMessage = "Error adding position: " . $e->getMessage();
        }
    } else {
        $errorMessage = "Position name cannot be empty!";
    }
}

// Fetch Positions
$sql = "SELECT position_name FROM position";
$stmt = $pdo->query($sql);
$positions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Positions</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<style>
    body{
        background:white;
    }
</style>
<body>
<div class="container mt-4">
    <h2>Positions</h2>

    <!-- Success & Error Messages -->
    <?php if (!empty($successMessage)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($successMessage) ?></div>
    <?php endif; ?>

    <?php if (!empty($errorMessage)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($errorMessage) ?></div>
    <?php endif; ?>

    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addPositionModal">+ New</button>

    <!-- Table (Only Position Name) -->
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Position Name</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($positions) > 0): ?>
                <?php foreach ($positions as $position): ?>
                    <tr>
                        <td><?= htmlspecialchars($position['position_name']) ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="1" class="text-center">No data available in table</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- Add Position Modal -->
    <div class="modal fade" id="addPositionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add Position</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Position Name</label>
                            <input type="text" name="position" class="form-control" required>
                        </div>
                        <button type="submit" name="add_position" class="btn btn-success">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

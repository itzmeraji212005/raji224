<?php
    // Start the session to manage user authentication
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online College Voting</title>
    
    <!-- Correct Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
        }
        .navbar {
            background-color:#8A2BE2;
            padding: 30px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar h1 {
            color: white;
            margin: 0;
            font-size: 30px;
            display: flex;
            align-items: center;
        }
        .navbar h1 i {
            margin-right: 18px;
        }
        .nav-links {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            margin: 0 20px;
        }
        .nav-links li a {
            text-decoration: none;
            color: white;
            font-size: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            padding: 8px 10px;
            border-radius: 7px;
            transition: background 0.5s;
        }
        .nav-links li a i {
            margin-right: 8px;
        }
        .nav-links li a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body>

    <div class="navbar">
        <h1><i class="fa-solid fa-vote-yea"></i> Online College Voting System</h1>
        <ul class="nav-links">
            <li><a href="demo.php"><i class="fa-solid fa-house"></i> Home</a></li>
            <li><a href="about.php"><i class="fa-solid fa-circle-info"></i> About</a></li>
            <li><a href="candi.php"><i class="fa-solid fa-users"></i> Candidates</a></li>
            <li><a href="voteeuh.php"><i class="fa-solid fa-check"></i> Voting</a></li>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
        </ul>
    </div>

</body>
</html>

<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle voting
if (isset($_POST['vote'])) {
    $candidateId = $_POST['candidate_id'];

    // Get candidate details using prepared statements
    $sql_candidate = "SELECT position, name, year, picture FROM candidates WHERE id = ?";
    $stmt_candidate = $conn->prepare($sql_candidate);
    $stmt_candidate->bind_param("i", $candidateId);

    if ($stmt_candidate->execute()) {
        $result_candidate = $stmt_candidate->get_result();

        if ($result_candidate->num_rows > 0) {
            $row_candidate = $result_candidate->fetch_assoc();
            $position = $row_candidate['position'];
            $name = $row_candidate['name'];
            $year = $row_candidate['year'];
            $picture = $row_candidate['picture'];

            // Insert vote into 'votes' table using prepared statements
            $sql_vote = "INSERT INTO votes (position, name, year, picture) VALUES (?, ?, ?, ?)";
            $stmt_vote = $conn->prepare($sql_vote);
            $stmt_vote->bind_param("ssss", $position, $name, $year, $picture);

            if ($stmt_vote->execute()) {
                echo "<script>alert('Vote successful!'); window.location.href = 'candidates_vote.php';</script>";
            } else {
                echo "<script>alert('Vote failed: " . $stmt_vote->error . "');</script>";
            }

            $stmt_vote->close();
        } else {
            echo "<script>alert('Candidate not found.');</script>";
        }
    } else {
        echo "<script>alert('Database error: " . $stmt_candidate->error . "');</script>";
    }
    $stmt_candidate->close();
}

// SQL to select all data, grouped by position
$sql_select = "SELECT * FROM candidates ORDER BY position";
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    // Output data in a table
    echo "<style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .candidate-group {
            margin-bottom: 30px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        .candidate-group h2 {
            background-color: #007bff;
            color: white;
            padding: 15px;
            margin: 0;
            text-align: center;
        }

        .candidate-list {
            padding: 20px;
        }

        .candidate-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .candidate-item img {
            max-width: 80px;
            max-height: 80px;
            border-radius: 50%;
            margin-right: 15px;
        }

        .candidate-item label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }
        .candidate-item input[type='radio']{
            margin-right: 10px;
        }

        .candidate-item button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-left: auto;
        }

        .candidate-item button:hover {
            background-color: #45a049;
        }
        #voteButton{
            margin-top: 20px;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
    </style>";

    echo "<form method='post'>"; // Start form outside the loop

    $currentPosition = '';
    while ($row = $result->fetch_assoc()) {
        if ($currentPosition != $row["position"]) {
            if ($currentPosition != '') {
                echo "</div></div>"; // Close previous group
            }
            $currentPosition = $row["position"];
            echo "<div class='candidate-group'>";
            echo "<h2>" . $currentPosition . "</h2>";
            echo "<div class='candidate-list'>";
        }
        echo "<div class='candidate-item'>";
        echo "<img src='" . $row["picture"] . "' alt='" . $row["name"] . "'>";
        echo "<label>";
        echo "<input type='radio' name='candidate_id' value='" . $row["id"] . "'>";
        echo "<div><h3>" . $row["name"] . "</h3>";
        echo "<p>" . $row["year"] . "</p></div>";
        echo "</label>";
        echo "</div>";
    }
    echo "<button type='submit' name='vote' id='voteButton'>Submit Vote</button>"; // Submit button outside the loop
    echo "</form></div></div>"; // Close last group and form

} else {
    echo "0 results";
}

$conn->close();
?>
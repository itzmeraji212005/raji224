<?php
// Database Configuration
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "project";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL to select candidates and their votes
$sql_select = "SELECT position, name, year, picture, COUNT(*) AS vote_count FROM votes GROUP BY name ORDER BY position";
$result = $conn->query($sql_select);

if ($result->num_rows > 0) {
    // Output data in a table
    echo "<style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        td.votes {
            text-align: center;
        }
        img {
            max-width: 50px;
            max-height: 50px;
        }
    </style>";

    echo "<table>";
    echo "<tr><th>Position</th><th>Name</th><th>Year</th><th>Picture</th><th>Votes</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["position"] . "</td>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["year"] . "</td>";
        echo "<td><img src='" . $row['picture'] . "' /></td>";
        echo "<td class='votes'>" . $row["vote_count"] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$conn->close();
?>
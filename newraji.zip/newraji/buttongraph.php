<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5e6ff;
            text-align: center;
        }
        .container {
            margin-top: 20px;
        }
        .btn {
            background-color: #4a148c;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
            margin: 10px;
        }
        .btn:hover {
            background-color: #7e57c2;
        }
        #graph-container {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1 style="color: #4a148c;">Admin Dashboard</h1>
    
    <div class="container">
        <!-- Button to load graph dynamically -->
        
        <!-- Anchor tag to open graph.php in a new tab -->
        <a href="graph.php" target="_blank" class="btn">view votes</a>
    </div>

    <div id="graph-container"></div>

    <script>
        $(document).ready(function() {
            $("#viewVotes").click(function() {
                $("#graph-container").html("<h3>Loading...</h3>"); // Show loading text
                $.ajax({
                    url: "graph.php",
                    method: "GET",
                    success: function(response) {
                        $("#graph-container").html(response); // Load graph.php content
                    },
                    error: function() {
                        $("#graph-container").html("<h3>Failed to load graphs.</h3>");
                    }
                });
            });
        });
    </script>
</body>
</html>

<?php
session_start();

// Initialize candidatesData if not set
if (!isset($_SESSION['candidatesData'])) {
    $_SESSION['candidatesData'] = [
        ['position' => 'Chairman', 'name' => 'Tamil', 'year' => '3rd Year', 'picture' => 'person1.jpg'],
        ['position' => 'Chairman', 'name' => 'Gowsi', 'year' => '2nd Year', 'picture' => 'person3.jpg'],
        ['position' => 'Chairman', 'name' => 'Abdul', 'year' => '3rd Year', 'picture' => 'person2.png'],
        ['position' => 'Vice Chairman', 'name' => 'Jeeva', 'year' => '3rd Year', 'picture' => 'person5.jpg'],
        ['position' => 'Vice Chairman', 'name' => 'Kiruba', 'year' => '3rd Year', 'picture' => 'person4.jpg'],
        ['position' => 'Secretary', 'name' => 'Kumar', 'year' => '3rd Year', 'picture' => 'person7.jpg'],
        ['position' => 'Secretary', 'name' => 'Vikas', 'year' => '2nd Year', 'picture' => 'person6.jpg'],
        ['position' => 'Joint Secretary', 'name' => 'Raji', 'year' => '3rd Year', 'picture' => 'raji.png'],
        ['position' => 'Joint Secretary', 'name' => 'Anu', 'year' => '3rd Year', 'picture' => 'person9.jfif'],
        ['position' => 'President', 'name' => 'Arun', 'year' => '3rd Year', 'picture' => 'per10.jpg'],
        ['position' => 'President', 'name' => 'Kavin', 'year' => '2nd Year', 'picture' => 'person11.jpg'],
        ['position' => 'Vice President', 'name' => 'Manju', 'year' => '2nd Year', 'picture' => 'women.avif'],
        ['position' => 'Union Advisor', 'name' => 'Saravanan', 'year' => '3rd Year', 'picture' => 'person12.jpg'],
        ['position' => 'Sports Secretary', 'name' => 'Alex', 'year' => '3rd Year', 'picture' => 'person13.avif'],
        ['position' => 'Sports Secretary', 'name' => 'Siva', 'year' => '3rd Year', 'picture' => 'person14.jpg'],
        ['position' => 'Sports Secretary', 'name' => 'Abinash', 'year' => '2nd Year', 'picture' => 'person15.avif'],
    ];
}

// Handle candidate deletion
if (isset($_GET['delete'])) {
    $index = $_GET['delete'];
    unset($_SESSION['candidatesData'][$index]);
    $_SESSION['candidatesData'] = array_values($_SESSION['candidatesData']); // Reindex the array
    header("Location: index.php");
    exit;
}

// Handle adding a new candidate
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addCandidate'])) {
    $newCandidate = [
        'position' => $_POST['position'],
        'name' => $_POST['name'],
        'year' => $_POST['year'],
        'picture' => $_POST['picture']
    ];
    $_SESSION['candidatesData'][] = $newCandidate;
    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Management</title>
</head>
<style>
   /* Reset & General Styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    background-color: #F3E5F5; /* Lavender background */
    color: #333;
    padding: 20px;
    text-align: center;
}

/* Header */
h1 {
    font-size: 2.5rem;
    color: #4A148C; /* Dark purple */
    margin-bottom: 20px;
    text-transform: uppercase;
    letter-spacing: 2px;
}

/* Candidate Table */
table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    margin-top: 20px;
}

th, td {
    padding: 15px;
    text-align: left;
}

th {
    background: #6A1B9A; /* Dark purple */
    color: white;
    font-size: 1.2rem;
}

td {
    background: #EDE7F6; /* Light lavender */
    color: #333;
    border-bottom: 1px solid #ddd;
}

td img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    border: 2px solid #6A1B9A;
}

/* Hover Effects */
tr:hover {
    background: #D1C4E9; /* Light purple hover */
}

/* Action Links */
a {
    font-size: 1rem;
    font-weight: bold;
    text-decoration: none;
    padding: 6px 12px;
    border-radius: 5px;
    transition: all 0.3s ease-in-out;
}

a[href*="edit"] {
    background: #1976D2; /* Blue */
    color: white;
}

a[href*="edit"]:hover {
    background: #0D47A1;
}

a[href*="delete"] {
    background: #D32F2F; /* Red */
    color: white;
}

a[href*="delete"]:hover {
    background: #B71C1C;
}

/* Add New Candidate Button */
.add-btn {
    display: inline-block;
    padding: 12px 18px;
    background: #6A1B9A; /* Dark Purple */
    color: white;
    font-size: 1.2rem;
    border-radius: 8px;
    margin-top: 20px;
    text-transform: uppercase;
    letter-spacing: 1px;
    transition: all 0.3s ease-in-out;
}

.add-btn:hover {
    background: #4A148C; /* Darker Purple */
}

/* Responsive Design */
@media (max-width: 768px) {
    table {
        display: block;
        overflow-x: auto;
    }

    th, td {
        font-size: 0.9rem;
        padding: 10px;
    }

    .add-btn {
        font-size: 1rem;
        padding: 10px 15px;
    }
}

</style>
<body>

    <h1>Candidate Management</h1>

    <!-- Link to Add a new Candidate -->
    <p><a href="add new voter.php">Add New Candidate</a></p>

    <!-- Display the list of candidates -->
    <h2>Candidate List</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Position</th>
                <th>Name</th>
                <th>Year</th>
                <th>Picture</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($_SESSION['candidatesData'] as $index => $candidate): ?>
                <tr>
                    <td><?= htmlspecialchars($candidate['position']); ?></td>
                    <td><?= htmlspecialchars($candidate['name']); ?></td>
                    <td><?= htmlspecialchars($candidate['year']); ?></td>
                    <td><img src="<?= htmlspecialchars($candidate['picture']); ?>" alt="Candidate Picture" width="50"></td>
                    <td>
                        <!-- Edit and Delete links -->
                        <a href="edit_candidate.php?id=<?= $index; ?>">Edit</a> | 
                        <a href="?delete=<?= $index; ?>" onclick="return confirm('Are you sure you want to delete this candidate?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>

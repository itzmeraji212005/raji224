<?php
// Database Connection
$host = 'localhost'; // Database host
$dbname = 'pro'; // Your database name
$username = 'root'; // Your database username
$password = 'raji'; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// CREATE Operation: Add a new votee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
    $name = $_POST['name'];
    $position = $_POST['position'];
    $year = $_POST['year'];

    // Handle file upload
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($_FILES["picture"]["name"]);
    move_uploaded_file($_FILES["picture"]["tmp_name"], $targetFile);

    $sql = "INSERT INTO votee (name, position, year, picture) VALUES (:name, :position, :year, :picture)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':name' => $name, ':position' => $position, ':year' => $year, ':picture' => $targetFile]);

    echo "Votee added successfully!";
}

// READ Operation: Fetch all votees
$sql = "SELECT * FROM votee";
$stmt = $pdo->query($sql);
$votees = $stmt->fetchAll();

// UPDATE Operation: Update a votee
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $position = $_POST['position'];
    $year = $_POST['year'];

    if ($_FILES["picture"]["error"] == 0) {
        // Handle file upload
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($_FILES["picture"]["name"]);
        move_uploaded_file($_FILES["picture"]["tmp_name"], $targetFile);
    } else {
        // Keep the existing picture
        $sql = "SELECT picture FROM votee WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
        $votee = $stmt->fetch();
        $targetFile = $votee['picture'];
    }

    $sql = "UPDATE votee SET name = :name, position = :position, year = :year, picture = :picture WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':name' => $name, ':position' => $position, ':year' => $year, ':picture' => $targetFile, ':id' => $id]);

    echo "Votee updated successfully!";
}

// DELETE Operation: Delete a votee
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];

    // Fetch picture to delete from the server
    $sql = "SELECT picture FROM votee WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);
    $votee = $stmt->fetch();
    ($votee['picture']); // Delete the picture file from the server

    $sql = "DELETE FROM votee WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':id' => $id]);

    echo "Votee deleted successfully!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votee CRUD Application</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        img {
            width: 50px;
            height: 50px;
        }
    </style>
</head>
<body>

    <!-- Add New Votee Form -->
    <h2>Add New Votee</h2>
    <form method="POST" enctype="multipart/form-data">
        Name: <input type="text" name="name" required><br>
        Position: <input type="text" name="position" required><br>
        Year: <input type="number" name="year" required><br>
        Picture: <input type="file" name="picture" required><br>
        <input type="submit" name="add" value="Add Votee">
    </form>

    <hr>

    <!-- Display All Votees -->
    <h2>All Votees</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Position</th>
                <th>Year</th>
                <th>Picture</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($votees as $votee): ?>
                <tr>
                    <td><?= $votee['id'] ?></td>
                    <td><?= $votee['name'] ?></td>
                    <td><?= $votee['position'] ?></td>
                    <td><?= $votee['year'] ?></td>
                    <td><img src="<?= $votee['picture'] ?>" alt="Picture"></td>
                    <td>
                        <!-- Edit Votee Form -->
                        <form method="POST" enctype="multipart/form-data" style="display:inline;">
                            <input type="hidden" name="id" value="<?= $votee['id'] ?>">
                            <input type="text" name="name" value="<?= $votee['name'] ?>" required>
                            <input type="text" name="position" value="<?= $votee['position'] ?>" required>
                            <input type="number" name="year" value="<?= $votee['year'] ?>" required>
                            <input type="file" name="picture">
                            <input type="submit" name="update" value="Update">
                        </form>
                        <!-- Delete Votee -->
                        <a href="?delete=<?= $votee['id'] ?>" onclick="return confirm('Are you sure you want to delete this votee?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>
</html>

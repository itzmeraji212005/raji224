<?php
// Database connection
$host = 'localhost';
$db = 'project'; // Your database name
$user = 'root'; // Your MySQL username
$pass = ''; // Your MySQL password (leave empty if no password)

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch candidates from the database
$sql = "SELECT name, position, votes FROM viewvotes ORDER BY position";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Candidate Votes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .candidate-box {
            width: 250px;
            margin: 10px;
            padding: 20px;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            text-align: center;
        }
        .candidate-box h3 {
            margin: 10px 0;
            color: #333;
        }
        .candidate-box p {
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>

<h1>Candidate Voting Results</h1>
<div class="container">
    <?php 
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) { ?>
            <div class="candidate-box">
                <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                <p><strong>Position:</strong> <?php echo htmlspecialchars($row['position']); ?></p>
                <p><strong>Votes:</strong> <?php echo htmlspecialchars($row['votes']); ?></p>
            </div>
    <?php }
    } else {
        echo "<p>No candidates found.</p>";
    }
    ?>
</div>

</body>
</html>

<?php
$conn->close();
?>

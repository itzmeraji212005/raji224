<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chairman Election Tally</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background: #f3e5f5; /* Lavender theme */
            color: #4A148C;
        }

        h2 {
            margin-top: 20px;
        }

        .chart-container {
            width: 50%;
            margin: auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
        }

        canvas {
            width: 100%;
            height: 400px;
        }
    </style>
</head>
<body>

    <h2>Chairman Election Tally</h2>
    
    <div class="chart-container">
        <canvas id="voteChart"></canvas>
    </div>

    <script>
        // Example vote count (Replace with dynamic data from backend)
        let voteData = {
            Abdul: 120,
            Gowsi: 150
        };

        // Chart.js to render the tally graph
        const ctx = document.getElementById('voteChart').getContext('2d');
        const voteChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(voteData), // Names: Abdul & Gowsi
                datasets: [{
                    label: 'Number of Votes',
                    data: Object.values(voteData), // Vote counts
                    backgroundColor: ['#6A1B9A', '#BA68C8'], // Lavender shades
                    borderColor: '#4A148C',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$database = "pro";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT position, name, vote_count FROM votee ORDER BY position, vote_count DESC";
$result = $conn->query($sql);

$voteData = [];

while ($row = $result->fetch_assoc()) {
    $voteData[$row['position']][] = [
        'name' => $row['name'],
        'vote_count' => $row['vote_count']
    ];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Election Tally Graphs</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5e6ff;
            text-align: center;
        }
        .chart-container {
            width: 60%;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .back-btn {
            display: inline-block;
            margin: 20px;
            padding: 10px 20px;
            background-color: #4a148c;
            color: white;
            text-decoration: none;
            font-size: 16px;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: #7e57c2;
        }
    </style>
</head>
<body>
    <h1 style="color: #4a148c;">Election Tally</h1>

    <!-- Back to Admin Dashboard Button -->
    <a href="admindashh.php" class="back-btn">← Back to Admin Dashboard</a>

    <?php foreach ($voteData as $position => $candidates): ?>
        <div class="chart-container">
            <h2 style="color: #4a148c;"><?php echo htmlspecialchars($position); ?> Election Tally</h2>
            <canvas id="chart-<?php echo md5($position); ?>"></canvas>
        </div>

        <script>
            const ctx_<?php echo md5($position); ?> = document.getElementById('chart-<?php echo md5($position); ?>').getContext('2d');
            new Chart(ctx_<?php echo md5($position); ?>, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode(array_column($candidates, 'name')); ?>,
                    datasets: [{
                        label: 'Number of Votes',
                        data: <?php echo json_encode(array_column($candidates, 'vote_count')); ?>,
                        backgroundColor: ['#4a148c', '#ba68c8', '#7e57c2', '#9575cd'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        </script>
    <?php endforeach; ?>

</body>
</html>

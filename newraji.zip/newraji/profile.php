
<?php
// Database Connection
$host = 'localhost';
$dbname = 'project';
$username = 'root';
$password = 'raji';
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Update Profile Logic
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $desc = $_POST['description'] ?? '';
    $profile_pic = '';

    if (!empty($_FILES['profile_pic']['name'])) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['profile_pic']['name']);
        move_uploaded_file($_FILES['profile_pic']['tmp_name'], $target_file);
        $profile_pic = $target_file;
    }
    
    $sql = "UPDATE pro SET name=IF(? != '', ?, name), email=IF(? != '', ?, email), description=IF(? != '', ?, description), profile_pic=IF(? != '', ?, profile_pic) WHERE id=1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssss", $name, $name, $email, $email, $desc, $desc, $profile_pic, $profile_pic);
    $stmt->execute();
}

// Fetch User Data
$sql = "SELECT name, email, description, profile_pic FROM pro WHERE id=1";
$result = $conn->query($sql);
$user = $result->fetch_assoc();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile Update</title>
    <style>
        body {
            background-color: #333;
            text-align: center;
            font-family: Arial, sans-serif;
            color: white;
        }
        .container {
            width: 350px;
            margin: 50px auto;
            padding: 20px;
            background: #444;
            border-radius: 10px;
        }
        .profile-pic {
            width: 100px;
            height: 100px;
            border-radius: 50%;
        }
        input[type=text], input[type=email], input[type=file], textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #666;
            border: none;
            color: white;
        }
        textarea {
            height: 80px;
        }
        .btn {
            background: blue;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            width: 100%;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .update-profile {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="<?php echo $user['profile_pic']; ?>" class="profile-pic">
        <form method="POST" enctype="multipart/form-data">
            <label>Email :</label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required>
            <label>Description :</label>
            <textarea name="description" required><?php echo $user['description']; ?></textarea>
            <label>Name :</label>
            <input type="text" name="name" value="<?php echo $user['name']; ?>" required>
           <a href="update-profile" class="btn">Update profile</a>
        </form>
        <div class="update-profile">
            <a href="admindashh.php" class="btn">OK</a>
        </div>
    </div>
</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "raji";
$database = "pro";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$positions_count = $conn->query("SELECT COUNT(*) as count FROM positions")->fetch_assoc()['count'];
$candidates_count = $conn->query("SELECT COUNT(*) as count FROM votee")->fetch_assoc()['count'];
$total_voters = $conn->query("SELECT COUNT(*) as count FROM login")->fetch_assoc()['count'];
$voters_voted = $conn->query("SELECT COUNT(*) as count FROM votee")->fetch_assoc()['count'];

$sql = "SELECT position, name, vote_count FROM votee ORDER BY position, vote_count DESC";
$result = $conn->query($sql);
$voteData = [];
while ($row = $result->fetch_assoc()) {
    $voteData[$row['position']][] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard & Vote Tally</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
            text-align: center;
        }
        .dashboard {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 20px;
        }
        .card {
            flex: 1;
            padding: 20px;
            margin: 10px;
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            transition: transform 0.3s, box-shadow 0.3s;
            min-width: 200px;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .positions { background-color: #666; }
        .candidates { background-color: #008000; }
        .voters { background-color: #ffa500; }
        .voted { background-color: #d9534f; }
        .number {
            font-size: 3em;
            font-weight: bold;
        }
        .text {
            font-size: 1.2em;
            font-weight: bold;
        }
        .icon {
            font-size: 4em;
            opacity: 0.2;
            position: absolute;
            right: 20px;
            bottom: 20px;
            transition: opacity 0.3s;
        }
        .card:hover .icon {
            opacity: 0.5;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin: 40px;
        }
        .tally-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            width: 280px;
            text-align: center;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }
        .tally-card:hover {
            transform: scale(1.03);
        }
        .tally-card h2 {
            font-size: 20px;
            margin-bottom: 15px;
            color: #2c3e50;
        }
        .candidate-list {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }
        .candidate {
            width: 100%;
            padding: 10px;
            background: rgba(0, 123, 255, 0.1);
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            color: #34495e;
            text-align: center;
        }
        .badge {
            background: #007bff;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 14px;
            display: block;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <div class="dashboard">
        <div class="card positions">
            <div>
                <div class="number"><?php echo $positions_count; ?></div>
                <div class="text">No. of Positions</div>
            </div>
            <i class="fas fa-list icon"></i>
        </div>
        <div class="card candidates">
            <div>
                <div class="number"><?php echo $candidates_count; ?></div>
                <div class="text">No. of Candidates</div>
            </div>
            <i class="fas fa-hourglass-half icon"></i>
        </div>
        <div class="card voters">
            <div>
                <div class="number"><?php echo $total_voters; ?></div>
                <div class="text">Total Voters</div>
            </div>
            <i class="fas fa-users icon"></i>
        </div>
        <div class="card voted">
            <div>
                <div class="number"><?php echo $voters_voted; ?></div>
                <div class="text">Voters Voted</div>
            </div>
            <i class="fas fa-edit icon"></i>
        </div>
    </div>
    <h1>Voting Results</h1>
    <div class="container">
        <?php foreach ($voteData as $position => $candidates) {
            echo "<div class='tally-card'>";
            echo "<h2>$position Vote Tally</h2>";
            echo "<div class='candidate-list'>";
            foreach ($candidates as $candidate) {
                echo "<div class='candidate'>
                        <span>{$candidate['name']}</span>
                        <span class='badge'>{$candidate['vote_count']} Votes</span>
                      </div>";
            }
            echo "</div></div>";
        } ?>
    </div>
</body>
</html>

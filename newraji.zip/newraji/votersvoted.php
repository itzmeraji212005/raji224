<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "project";

// Connect to Database
$conn = new mysqli($servername, $username, $password, $database);

// Check Connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch Data from the Database
$positions_count = $conn->query("SELECT COUNT(*) as count FROM positions")->fetch_assoc()['count'];
$candidates_count = $conn->query("SELECT COUNT(*) as count FROM candidates")->fetch_assoc()['count'];
$total_voters = $conn->query("SELECT COUNT(*) as count FROM login")->fetch_assoc()['count'];
$voters_voted = $conn->query("SELECT COUNT(*) as count FROM viewvotes")->fetch_assoc()['count'];

// Close Connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* General Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        /* Dashboard Layout */
        .dashboard {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            margin: 20px;
        }

        /* Card Styling */
        .card {
            flex: 1;
            padding: 20px;
            margin: 10px;
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            transition: transform 0.3s, box-shadow 0.3s;
            min-width: 200px;
        }

        /* Hover Effect */
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Background Colors */
        .positions { background-color: #666; } /* Gray */
        .candidates { background-color: #008000; } /* Green */
        .voters { background-color: #ffa500; } /* Orange */
        .voted { background-color: #d9534f; } /* Red */

        /* Number Styling */
        .number {
            font-size: 3em;
            font-weight: bold;
        }

        /* Info Text */
        .text {
            font-size: 1.2em;
            font-weight: bold;
        }

        /* More Info Button */
        .more-info {
            position: absolute;
            bottom: 2px;
            left: 120px;
            font-size: 0.9em;
            text-decoration: none;
            color: white;
            font-weight: bold;
        }

        .more-info:hover {
            text-decoration: underline;
        }

        /* Icons */
        .icon {
            font-size: 4em;
            opacity: 0.2;
            position: absolute;
            right: 20px;
            bottom: 20px;
            transition: opacity 0.3s;
        }

        .card:hover .icon {
            opacity: 0.5;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .dashboard {
                flex-direction: column;
                align-items: center;
            }

            .card {
                width: 90%;
            }
        }
    </style>
</head>
<body>

<div class="dashboard">
    <div class="card positions">
        <div>
            <div class="number"><?php echo $positions_count; ?></div>
            <div class="text">No. of Positions</div>
            <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        <i class="fas fa-list icon"></i>
    </div>

    <div class="card candidates">
        <div>
            <div class="number"><?php echo $candidates_count; ?></div>
            <div class="text">No. of Candidates</div>
            <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        <i class="fas fa-hourglass-half icon"></i>
    </div>

    <div class="card voters">
        <div>
            <div class="number"><?php echo $total_voters; ?></div>
            <div class="text">Total Voters</div>
            <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        <i class="fas fa-users icon"></i>
    </div>

    <div class="card voted">
        <div>
            <div class="number"><?php echo $voters_voted; ?></div>
            <div class="text">Voters Voted</div>
            <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
        <i class="fas fa-edit icon"></i>
    </div>
</div>

</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online College Voting System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: linear-gradient(to right, #6a11cb, #2575fc);
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            animation: fadeIn 1s ease-in;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
            text-align: center;
            animation: slideIn 1s forwards;
            opacity: 0;
        }

        @keyframes slideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .icon-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
            flex-wrap: wrap;
        }

        .icon {
            font-size: 3em;
            margin: 0 20px;
            opacity: 0;
            animation: bounce 1s forwards;
            animation-delay: var(--i);
            color: #fff;
        }

        @keyframes bounce {
            from {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .go-button {
            background: #ff9800;
            padding: 15px 25px;
            border: none;
            border-radius: 25px;
            font-size: 1.2em;
            color: white;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .go-button:hover {
            background: #f57c00;
            transform: translateY(-2px);
        }

        .arrow {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            animation: moveArrow 1s ease-in-out infinite;
        }

        @keyframes moveArrow {
            0%, 100% {
                transform: translateY(-50%) translateX(0);
            }
            50% {
                transform: translateY(-50%) translateX(5px);
            }
        }
    </style>
</head>
<body>

<h1>Welcome to the Online College Voting System</h1>

<div class="icon-container">
    <div class="icon" style="--i: 0s;"><i class="fas fa-vote-yea"></i></div>
    <div class="icon" style="--i: 0.2s;"><i class="fas fa-user-check"></i></div>
    <div class="icon" style="--i: 0.4s;"><i class="fas fa-balance-scale"></i></div>
    <div class="icon" style="--i: 0.6s;"><i class="fas fa-poll-h"></i></div>
</div>

<button class="go-button" onclick="goToVotingPage()">
    Go
    <span class="arrow"><i class="fas fa-arrow-right"></i></span>
</button>

<script>
    function goToVotingPage() {
        // Redirect to the voting page
        window.location.href = 'registerform.php';  // Change to your voting page URL
    }
</script>

</body>
</html>
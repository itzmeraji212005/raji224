<?php
// Database connection details
$servername = "localhost";
$username = "root";
$password = "raji";
$dbname = "pro";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Define all mandatory positions
$Positions = [
    'Chairman', 'Vice Chairman', 'Secretary', 
    'Joint Secretary', 'President', 'Vice President', 
    'Union Advisor', 'Sports Secretary'
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting Form</title>
</head>
<body>
    <h1 style="text-align: center;">Vote for Your Candidates</h1>
    <form action="voteeuh2.php" method="post" style="max-width: 600px; margin: auto;">
        <?php
        foreach ($Positions as $position) {
            echo "<h3>$position:</h3>";
            $sql = "SELECT name, picture FROM candidate WHERE position = '$position'";
            $result = $conn->query($sql);
            
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $candidateName = $row['name'];
                    $candidatePicture = $row['picture'];

                    echo "<label>";
                    echo "<input type='radio' name='$position' value='$candidateName' required> $candidateName";
                    if ($candidatePicture) {
                        echo "<img src='$candidatePicture' alt='$candidateName' style='width:50px; height:50px;'>";
                    }
                    echo "</label><br>";
                }
            } else {
                echo "<p>No candidates available for $position.</p>";
            }
        }
        ?>
        <input type="submit" value="Submit Votes">
    </form>
</body>
</html>

<?php
$conn->close(); // Close the connection
?>
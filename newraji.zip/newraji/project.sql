-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 13, 2025 at 05:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `position` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `year` varchar(10) DEFAULT NULL,
  `picture` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`position`, `name`, `year`, `picture`) VALUES
('Chairman', 'Tamil', '3rd Year', 'person1.jpg'),
('Chairman', 'Gowsi', '2nd Year', 'person3.jpg'),
('Chairman', 'Abdul', '3rd Year', 'person2.png'),
('Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg'),
('Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg'),
('Secretary', 'Kumar', '3rd Year', 'person7.jpg'),
('Secretary', 'Vikas', '2nd Year', 'person6.jpg'),
('Joint Secretary', 'Raji', '3rd Year', 'raji.png'),
('Joint Secretary', 'Anu', '3rd Year', 'person9.jfif'),
('President', 'Arun', '3rd Year', 'per10.jpg'),
('President', 'Kavin', '2nd Year', 'person11.jpg'),
('Vice President', 'Manju', '2nd Year', 'women.avif'),
('Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg'),
('Sports Secretary', 'Alex', '3rd Year', 'person13.avif'),
('Sports Secretary', 'Siva', '3rd Year', 'person14.jpg'),
('Sports Secretary', 'Abinash', '2nd Year', 'person15.avif'),
('Chairman', 'Tamil', '3rd Year', 'person1.jpg'),
('Chairman', 'Gowsi', '2nd Year', 'person3.jpg'),
('Chairman', 'Abdul', '3rd Year', 'person2.png'),
('Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg'),
('Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg'),
('Secretary', 'Kumar', '3rd Year', 'person7.jpg'),
('Secretary', 'Vikas', '2nd Year', 'person6.jpg'),
('Joint Secretary', 'Raji', '3rd Year', 'raji.png'),
('Joint Secretary', 'Anu', '3rd Year', 'person9.jfif'),
('President', 'Arun', '3rd Year', 'per10.jpg'),
('President', 'Kavin', '2nd Year', 'person11.jpg'),
('Vice President', 'Manju', '2nd Year', 'women.avif'),
('Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg'),
('Sports Secretary', 'Alex', '3rd Year', 'person13.avif'),
('Sports Secretary', 'Siva', '3rd Year', 'person14.jpg'),
('Sports Secretary', 'Abinash', '2nd Year', 'person15.avif'),
('Chairman', 'Tamil', '3rd Year', 'person1.jpg'),
('Chairman', 'Gowsi', '2nd Year', 'person3.jpg'),
('Chairman', 'Abdul', '3rd Year', 'person2.png'),
('Vice Chairman', 'Jeeva', '3rd Year', 'person5.jpg'),
('Vice Chairman', 'Kiruba', '3rd Year', 'person4.jpg'),
('Secretary', 'Kumar', '3rd Year', 'person7.jpg'),
('Secretary', 'Vikas', '2nd Year', 'person6.jpg'),
('Joint Secretary', 'Raji', '3rd Year', 'raji.png'),
('Joint Secretary', 'Anu', '3rd Year', 'person9.jfif'),
('President', 'Arun', '3rd Year', 'per10.jpg'),
('President', 'Kavin', '2nd Year', 'person11.jpg'),
('Vice President', 'Manju', '2nd Year', 'women.avif'),
('Union Advisor', 'Saravanan', '3rd Year', 'person12.jpg'),
('Sports Secretary', 'Alex', '3rd Year', 'person13.avif'),
('Sports Secretary', 'Siva', '3rd Year', 'person14.jpg'),
('Sports Secretary', 'Abinash', '2nd Year', 'person15.avif');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('raji', 'raji'),
('divya', 'divya');

-- --------------------------------------------------------

--
-- Table structure for table `positions`
--

CREATE TABLE `positions` (
  `position_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `positions`
--

INSERT INTO `positions` (`position_name`) VALUES
('Chairman'),
('Vice Chairman'),
('Secretary'),
('Joint Secretary'),
('President'),
('Vice President'),
('Union Advisor'),
('Sports Secretary');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `regno` varchar(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `dept_name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`regno`, `name`, `dept_name`) VALUES
('22UCA531', 'raji', 'Dept of Computer application'),
('22UCA531', 'raji', 'Dept of Computer application'),
('21UVCA31', 'Mariya', 'Dept of Visual Communication'),
('20UTA534', 'geetha', 'Dept of Tamil');

-- --------------------------------------------------------

--
-- Table structure for table `viewvotes`
--

CREATE TABLE `viewvotes` (
  `id` int(11) NOT NULL,
  `position` varchar(20) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `picture` varchar(20) DEFAULT NULL,
  `votes` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `votes`
--

CREATE TABLE `votes` (
  `id` int(11) NOT NULL,
  `candidate_name` varchar(100) DEFAULT NULL,
  `position` varchar(50) DEFAULT NULL,
  `vote_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewvotes`
--
ALTER TABLE `viewvotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `votes`
--
ALTER TABLE `votes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `viewvotes`
--
ALTER TABLE `viewvotes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `votes`
--
ALTER TABLE `votes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
